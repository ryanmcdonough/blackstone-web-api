﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Savills.Core.Attributes
{
    public class EntropyAttribute : ValidationAttribute
    {

        /// <summary>
        /// returns bits of entropy represented in a given string, per 
        /// http://en.wikipedia.org/wiki/Entropy_(information_theory) 
        /// </summary>
        public static int ShannonEntropy(string s)
        {
            var map = new Dictionary<char, int>();

            //add each character to map
            foreach (char c in s)
            {
                if (!map.ContainsKey(c))
                    map.Add(c, 1);
                else
                    map[c] += 1;
            }

            double result = 0.0;
            int len = s.Length;
            foreach (var item in map)
            {
                var frequency = (double)item.Value / len;
                result -= frequency * (Math.Log(frequency) / Math.Log(2));
            }

            //Need to cast to int (round up) so I can swtich on it. Not needed for JS
            return (int)Math.Ceiling(result);
        }

    }
}
