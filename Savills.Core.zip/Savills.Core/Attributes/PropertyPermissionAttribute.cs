﻿using System.ComponentModel.DataAnnotations;
using System.Web.Security;
using Umbraco.Core;

namespace Savills.Core.Attributes
{
    public class PropertyPermissionAttribute : ValidationAttribute
    {
       
        /// <summary>
        /// returns bits of entropy represented in a given string, per 
        /// http://en.wikipedia.org/wiki/Entropy_(information_theory) 
        /// </summary>
        public static bool HasAccess(int propertyId)
        {
            var service = ApplicationContext.Current.Services;
            var member = service.MemberService.GetByUsername(Membership.GetUser().UserName);

            int memberProviderId = member.GetValue<int>("providerID");
            var property = service.ContentService.GetById(propertyId);

            if (memberProviderId == property.GetValue<int>("provider"))
            {
                return true;
            }
            return false;

        }
        
    }
}
