﻿using System.Collections.Generic;
using Savills.Core.Elastic.Elastic.Model;

namespace Savills.Core.Extensions
{
    class BasketItemEqualityComparer : IEqualityComparer<BasketItem>
    {
        public bool Equals(BasketItem x, BasketItem y)
        {
            return x.PropertyId == y.PropertyId;
        }
        public int GetHashCode(BasketItem obj)
        {
            return obj.Id.GetHashCode();
        }
    }
}
