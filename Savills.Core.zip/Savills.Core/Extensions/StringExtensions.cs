﻿using System;

namespace Savills.Core.Extensions
{
    public static class StringExtensions
    {
        public static string GetTokenisedSeoString(this string item, string officeType, string placeName)
        {
            return string.IsNullOrEmpty(item) ? "" : item.Replace("{{type}}", officeType).Replace("{{place}}", placeName);
        }

        public static string FormatFileSizeInMb(this string item)
        {
            var fileSize = double.Parse(item);

            return String.Format("{0:##.##}", fileSize / 1048576.0) + " MB";
        }
    }
}
