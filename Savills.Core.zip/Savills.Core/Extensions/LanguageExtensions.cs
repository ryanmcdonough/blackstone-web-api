﻿using Umbraco.Core.Models;
using Our.Umbraco.Vorto.Extensions;
using Savills.Core.Helpers;
using Umbraco.Web;

namespace Savills.Core.Extensions
{
    /// <summary>
    /// Extension methods for multi language content
    /// </summary>
    public static class LanguageExtensions
    {
        /// <summary>
        /// Use instead of GetPropertyValue for multi-language fields, will get the property value from Vorto, with fall-back auto set to the site's default language
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="content"></param>
        /// <param name="alias"></param>
        /// <param name="cultureName"></param>
        /// <param name="recursive"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public static T GetTranslatedPropertyValue<T>(this IPublishedContent content, string alias, string cultureName = null, bool recursive = false, T defaultValue = default(T))
        {
            //TODO: for complex JSON type properties, you may need to do some additional work here. Will have to test with some complex data once we have some

            var value = content.GetVortoValue(alias, cultureName, recursive, defaultValue, LanguageHelper.DefaultLanguage);

            return value;
        }

        /// <summary>
        /// Gets a dictionary value, but falls back to the default language if the key is not present in the current language
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static string GetDictionaryValueWithFallback(this UmbracoHelper helper, string key)
        {
            var value = helper.GetDictionaryValue(key);

            if (value == key  || string.IsNullOrEmpty(value))
            {
                //not found in current language, fall back to default one
                return LanguageHelper.GetDictionaryValueForSpecificLocale(key, LanguageHelper.DefaultLanguage);
            }

            return value;
        }
    }
}
