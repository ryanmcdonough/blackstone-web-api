﻿namespace Savills.Core.Extensions
{
    using System;
    using System.Net.Mail;

    public static class ValidationExtensions
    {
        public static bool IsValidPassword(this string password)
        {
            return password?.Length >= 8;
        }

        public static bool IsNotEmpty(this string input)
        {
            return !string.IsNullOrEmpty(input) && !string.IsNullOrWhiteSpace(input);
        }

        public static bool IsAMatch(this string inputOne, string inputTwo)
        {
            return inputOne.Equals(inputTwo);
        }

        /// <summary>
        /// Determines whether the specified email address is valid. Instead of using a 
        /// regular expression to validate an email address, you can use the System.Net.Mail.MailAddress 
        /// class. To determine whether an email address is valid, pass the email address to the 
        /// MailAddress.MailAddress(String) class constructor.
        /// see: https://stackoverflow.com/a/5342460
        /// </summary>
        /// <param name="email">The email.</param>
        /// <returns>
        ///   <c>true</c> if the specified email is a valid email address otherwise, <c>false</c>.
        /// </returns>
        public static bool IsValidEmail(this string email)
        {
            if (email == null)
                return false;
            try
            {
                var m = new MailAddress(email);

                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }
    }
}