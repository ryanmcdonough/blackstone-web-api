﻿using System;
using System.Linq;
using System.Web.Security;
using Examine;
using Umbraco.Core;
using Umbraco.Core.Models;
using Umbraco.Web;
using Savills.Core.ViewModels;
using Umbraco.Core.Services;
using Member = Savills.Core.Models.Member;

namespace Savills.Core.Extensions
{
    //LOL
    public static class MemberExtensions
    {
        /// <summary>
        /// tells you if the current user is a trusted user or not
        /// </summary>
        /// <param name="member"></param>
        /// <returns></returns>
        public static bool IsTrustedProvider(this IPublishedContent member)
        {
            return member.GetPropertyValue<bool>("trustedProvider", false);
        }

        /// <summary>
        /// Tells you if the current user is a provider
        /// </summary>
        /// <param name="member"></param>
        /// <returns></returns>
        public static bool IsProvider(this IPublishedContent member)
        {
            var roles = Roles.GetRolesForUser(member.GetPropertyValue<string>("UserName"));

            if (roles == null) return false;

            return roles.Contains("Provider");
        }

        /// <summary>
        /// Tells you if the current user is an occupier
        /// </summary>
        /// <param name="member"></param>
        /// <returns></returns>
        public static bool IsOccupier(this IPublishedContent member)
        {
            var roles = Roles.GetRolesForUser(member.GetPropertyValue<string>("UserName"));

            if (roles == null) return false;

            return roles.Contains("Occupier");
        }

        /// <summary>
        /// Tells you if the current user has permission to manage a property
        /// </summary>
        /// <param name="member"></param>
        /// <param name="propertyId"></param>
        /// <returns></returns>
        public static bool CanManageProperty(this IPublishedContent member, int propertyId)
        {
            var service = ApplicationContext.Current.Services;

            var providerId = service.MemberService.GetById(member.Id);
            var memberProviderId = providerId.GetValue<int>("providerID");

            var property = service.ContentService.GetById(propertyId);

            if (Convert.ToInt32(memberProviderId) == property?.GetValue<int>("provider"))
            {
                return true;
            }

            return false;
        }

        public static ISearchResults PropertiesOwned(this IPublishedContent member)
        {
            IPublishedContent memberProviderId = member.GetPropertyValue("providerID") as IPublishedContent;

            int id = 0;

            if (memberProviderId != null)
            {
                id = memberProviderId.Id;
            }

            var searcher = ExamineManager.Instance.SearchProviderCollection["PropertySearcher"];
            var searchCriteria = searcher.CreateSearchCriteria();

            var query = searchCriteria.Field("provider", id.ToString()).Compile();

            var results = searcher.Search(query);

            return results;
        }

        public static void UpdateNewMember(this IMember newMember, string language, string currency, string firstName, string lastName, string company, string telephone, bool verified)
        {
            newMember.SetValue("hasVerifiedEmail", verified);
            newMember.SetValue("communicationsLanguage", language);
            newMember.SetValue("currency", currency);
            newMember.SetValue("firstName", firstName);
            newMember.SetValue("lastName", lastName);
            newMember.SetValue("company", company);
            newMember.SetValue("telphone", telephone);
            var media = ApplicationContext.Current.Services.MediaService.GetById(2393);
            newMember.SetValue("photo", media.Id);
        }

        private static readonly UmbracoHelper Helper = new UmbracoHelper(UmbracoContext.Current);

        public static string GetFallbackImage(int imageNodeId)
        {
            return Helper.TypedMedia(imageNodeId)?.Url ?? "";
        }

        public static string GetFallbackImage()
        {
            // TODO: Get this id from application settings
            var imageNodeId = 2393;
            return GetFallbackImage(imageNodeId);
        }

        public static ProviderDetailsViewModel GetProviderDetailsViewModel(this Member member, IContentService contentService)
        {
            var providerContent = member.ProviderContent;

            var providerDetailsViewModel = new ProviderDetailsViewModel();

            if (providerContent != null)
            {
                var logo = UmbracoContext.Current.MediaCache.GetById(providerContent.GetValue<int>("logo"));

                providerDetailsViewModel.Id = providerContent.Id;
                providerDetailsViewModel.Name = providerContent.GetValue<string>("displayName");
                providerDetailsViewModel.CurrentLogo = logo?.Url ?? GetFallbackImage();
                providerDetailsViewModel.IsPendingApproval = !member.TrustedProvider;
            }
            else
            {
                providerDetailsViewModel.Id = 0;
                providerDetailsViewModel.IsPendingApproval = true;
            }

            return providerDetailsViewModel;
        }
    }
}
