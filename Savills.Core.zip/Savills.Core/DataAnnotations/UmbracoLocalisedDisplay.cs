﻿using System.ComponentModel;
using System.Globalization;
using Savills.Core.Helpers;

namespace Savills.Core.DataAnnotations
{
    public class UmbracoLocalisedDisplay : DisplayNameAttribute
    {
        private string DisplayNameKey { get; set; }
        private string ResourceSetName { get; set; }

        public UmbracoLocalisedDisplay(string displayNameKey)
            : base(displayNameKey)
        {
            this.DisplayNameKey = displayNameKey;
        }


        public UmbracoLocalisedDisplay(string displayNameKey, string resourceSetName)
            : base(displayNameKey)
        {
            this.DisplayNameKey = displayNameKey;
            this.ResourceSetName = resourceSetName;
        }

        public override string DisplayName => LanguageHelper.GetDictionaryValueForSpecificLocale(this.DisplayNameKey, CultureInfo.CurrentCulture.ToString());
    }
}
