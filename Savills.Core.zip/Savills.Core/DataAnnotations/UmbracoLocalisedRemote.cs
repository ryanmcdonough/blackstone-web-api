﻿using System.Collections.Generic;
using System.Globalization;
using System.Web.Mvc;
using Savills.Core.Helpers;

namespace Savills.Core.DataAnnotations
{
    public class UmbracoLocalisedRemote : RemoteAttribute
    {
        public UmbracoLocalisedRemote(string action, string controller, string umbracoDictionaryKey)
        {
            this.ErrorMessage = LanguageHelper.GetDictionaryValueForSpecificLocale(umbracoDictionaryKey, CultureInfo.CurrentCulture.ToString());
        }

        public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            yield return new ModelClientValidationRule
            {
                ErrorMessage = this.ErrorMessage,
                ValidationType = "required"
            };
        }
    }
}
