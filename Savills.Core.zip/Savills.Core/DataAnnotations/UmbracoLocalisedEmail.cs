﻿using System.Collections.Generic;
using System.Globalization;
using System.Web.Mvc;
using DataAnnotationsExtensions;
using Savills.Core.Helpers;

namespace Savills.Core.DataAnnotations
{
    public class UmbracoLocalisedEmail : EmailAttribute
    {
        public UmbracoLocalisedEmail(string umbracoDictionaryKey)
        {
            this.ErrorMessage = LanguageHelper.GetDictionaryValueForSpecificLocale(umbracoDictionaryKey, CultureInfo.CurrentCulture.ToString());
        }

        public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            yield return new ModelClientValidationRule
            {
                ErrorMessage = this.ErrorMessage,
                ValidationType = "required"
            };
        }
    }
}
