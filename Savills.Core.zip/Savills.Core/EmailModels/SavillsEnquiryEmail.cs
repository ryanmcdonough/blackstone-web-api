﻿using Savills.Core.Api.Models;
using Savills.Core.Elastic.Elastic.Model;
using System.Collections.Generic;

namespace Savills.Core.EmailModels
{
    public class SavillsEnquiryEmail : BaseEmail
    {
        public Enquiry Enquiry { get; set; }
        public List<Property> Properties { get; set; }
    }
}
