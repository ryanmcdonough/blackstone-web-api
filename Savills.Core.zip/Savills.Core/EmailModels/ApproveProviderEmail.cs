﻿namespace Savills.Core.EmailModels
{
    public class ApproveProviderEmail : BaseEmail
    {

    }
}
