﻿using System;

namespace Savills.Core.EmailModels
{
    public class RejectPropertyEmail : BaseEmail
    {
        public string PropertyName { get; set; }
        public String Reason { get; set; }
    }
}
