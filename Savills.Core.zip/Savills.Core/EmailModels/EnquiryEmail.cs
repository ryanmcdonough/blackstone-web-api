﻿using System.Collections.Generic;
using Savills.Core.Api.Models;
using Savills.Core.Elastic.Elastic.Model;

namespace Savills.Core.EmailModels
{
    public class EnquiryEmail : BaseEmail
    {
        public Enquiry Enquiry { get; set; }
        public List<Property> Properties { get; set; }
    }
}
