﻿namespace Savills.Core.EmailModels
{
    public class RejectProviderEmail : BaseEmail
    {
        public string Reason { get; set; }
    }
}
