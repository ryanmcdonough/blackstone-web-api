﻿namespace Savills.Core.EmailModels
{
    public class ApprovePropertyEmail : BaseEmail
    {
        public string PropertyName { get; set; }
    }
}
