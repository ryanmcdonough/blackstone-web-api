﻿using System.Collections.Generic;
using Savills.Core.Elastic.Elastic.Model;

namespace Savills.Core.EmailModels
{
    public class PropertyAlertEmail : BaseEmail
    {
        public string AlertName { get; set; }
        public List<Property> Properties { get; set; } = new List<Property>();
    }
}
