﻿namespace Savills.Core.EmailModels
{
    public class ContactFormEmail : BaseEmail
    {
        public string Enquiry { get; set; }
        public string EmailAddress { get; set; }
        public string FirstName { get; set; }
        public string LastName { get;set; }
        public string PhoneNumber { get; set; }
        public string Company { get; set; }
    }
}