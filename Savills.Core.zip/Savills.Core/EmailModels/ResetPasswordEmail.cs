﻿namespace Savills.Core.EmailModels
{
    public class ResetPassword: BaseEmail
    {
        public string Link { get; set; }
    }
}
