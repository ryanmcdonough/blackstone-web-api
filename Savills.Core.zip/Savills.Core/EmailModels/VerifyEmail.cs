﻿namespace Savills.Core.EmailModels
{
    public class VerifyEmail: BaseEmail
    {
        public string Link { get; set; }
    }
}
