﻿using Postal;
using Savills.Core.Helpers;
using System.Configuration;
using Umbraco.Web;

namespace Savills.Core.EmailModels
{
    /// <summary>
    /// The base email class that can be used for all Postal emmails
    /// </summary>
    public class BaseEmail : Email
    {
        public string To { get; set; }
        public string From { get; set; }
        public string ToName { get; set; }
        public string LanguageCode { get; set; }
        public string Cc { get; set; }
        public string Bcc { get; set; }

        /// <summary>
        /// Method to puplate the basic fields for the email
        /// </summary>
        /// <param name="memberId"></param>
        public void PopulatMemberInfo(int memberId)
        {
            //get basic member information
            var member = UmbracoContext.Current.Application.Services.MemberService.GetById(memberId);

            if (member != null)
            {
                ToName = string.Format("{0} {1}", member.GetValue("firstName"), member.GetValue("lastName"));
                To = member.Email;
                LanguageCode = member.GetValue<string>("communicationsLanguage");
            }

            //if no language set, use default
            if (string.IsNullOrEmpty(LanguageCode))
            {
                LanguageCode = LanguageHelper.DefaultLanguage;
            }

            //get from address
            From = ConfigurationManager.AppSettings["Savills.AlertsFrom"];
        }
    }
}
