﻿using Savills.Core.DataModels;
using Savills.Core.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using Umbraco.Web;

namespace Savills.Core.Repositories
{
    public class PendingItemRepository
    {
        public const string ReviewDocType = "review";
        public const string PropertyDocType = "propertySpace";
        public const string ProviderDocType = "providerDetail";

        /// <summary>
        /// gets all of the pending reviews
        /// </summary>
        /// <param name="page"></param>
        /// <param name="itemsPerPage"></param>
        /// <returns></returns>
        public PagedPendingReviews GetPendingReviews(int page, int itemsPerPage)
        {
            var pagedReviews = new PagedPendingReviews();

            pagedReviews.CurrentPage = page;
            pagedReviews.ItemsPerPage = itemsPerPage;

            var reviews = new List<PendingReview>();

            var pendingItems = GetPendingItems(TaskHelper.TaskUser, ReviewDocType, page, itemsPerPage);

            var buildingMap = new Dictionary<int, string>();

            if (pendingItems != null && pendingItems.Any())
            {
                pagedReviews.TotalItems = pendingItems.First().TotalRecords;

                foreach (var item in pendingItems)
                {
                    var contentItem = UmbracoContext.Current.Application.Services.ContentService.GetById(item.NodeId);

                    var pendingReview = new PendingReview(contentItem);

                    if (buildingMap.ContainsKey(contentItem.ParentId))
                    {
                        pendingReview.PropertyName = buildingMap[contentItem.ParentId];
                    }
                    else
                    {
                        var property = UmbracoContext.Current.Application.Services.ContentService.GetById(contentItem.ParentId);

                        pendingReview.PropertyName = property.Name;

                        buildingMap.Add(property.Id, property.Name);
                    }

                    reviews.Add(pendingReview);
                }

                pagedReviews.TotalPages = (long)Math.Ceiling((double)pagedReviews.TotalItems / (double)pagedReviews.ItemsPerPage);
            }
            else
            {
                pagedReviews.TotalItems = 0;
                pagedReviews.TotalPages = 0;
            }

            pagedReviews.Reviews = reviews;

            return pagedReviews;
        }

        /// <summary>
        /// Gets all of the pending property adds/edits
        /// </summary>
        /// <param name="page"></param>
        /// <param name="itemsPerPage"></param>
        /// <returns></returns>
        public PagedPendingProperties GetPendingProperties(int page, int itemsPerPage)
        {
            var pagedProperties = new PagedPendingProperties();

            pagedProperties.CurrentPage = page;
            pagedProperties.ItemsPerPage = itemsPerPage;

            var properties = new List<PendingProperty>();

            var pendingItems = GetPendingItems(TaskHelper.TaskUser, PropertyDocType, page, itemsPerPage);

            var providerMap = new Dictionary<int, string>();

            if (pendingItems != null && pendingItems.Any())
            {
                pagedProperties.TotalItems = pendingItems.First().TotalRecords;

                foreach (var item in pendingItems)
                {
                    var pendingProperty = new PendingProperty();

                    var contentItem = UmbracoContext.Current.Application.Services.ContentService.GetById(item.NodeId);

                    pendingProperty.Id = contentItem.Id;
                    pendingProperty.DateUpdated = contentItem.UpdateDate;
                    pendingProperty.PropertyName = contentItem.Name;

                    
                    var providerDetails = UmbracoContext.Current.Application.Services.ContentService.GetById(contentItem.GetValue<int>("provider"));
                    var providerId = providerDetails.GetValue<int>("provider");


                    if (providerMap.ContainsKey(providerId))
                    {
                        pendingProperty.ProviderName = providerMap[providerId];
                    }
                    else
                    {
                        var member = UmbracoContext.Current.Application.Services.MemberService.GetById(providerId);

                        pendingProperty.ProviderName = member.Name;

                        providerMap.Add(providerId, member.Name);
                    }

                    properties.Add(pendingProperty);
                }

                pagedProperties.TotalPages = (long)Math.Ceiling((double)pagedProperties.TotalItems / (double)pagedProperties.ItemsPerPage);
            }
            else
            {
                pagedProperties.TotalItems = 0;
                pagedProperties.TotalPages = 0;
            }

            pagedProperties.Properties = properties;

            return pagedProperties;
        }

        /// <summary>
        /// Gets all of the pending provider adds/edits
        /// </summary>
        /// <param name="page"></param>
        /// <param name="itemsPerPage"></param>
        /// <returns></returns>
        public PagedPendingProviders GetPendingProviders(int page, int itemsPerPage)
        {
            var pagedProviders = new PagedPendingProviders();

            pagedProviders.CurrentPage = page;
            pagedProviders.ItemsPerPage = itemsPerPage;

            var providers = new List<PendingProvider>();

            var pendingItems = GetPendingItems(TaskHelper.TaskUser, ProviderDocType, page, itemsPerPage);

            if (pendingItems != null && pendingItems.Any())
            {
                pagedProviders.TotalItems = pendingItems.First().TotalRecords;

                foreach (var item in pendingItems)
                {
                    var pendingProvider = new PendingProvider();

                    var contentItem = UmbracoContext.Current.Application.Services.ContentService.GetById(item.NodeId);

                    pendingProvider.Id = contentItem.Id;
                    pendingProvider.DateUpdated = contentItem.UpdateDate;
                    pendingProvider.ProviderName = contentItem.Name;

                    providers.Add(pendingProvider);
                }

                pagedProviders.TotalPages = (long)Math.Ceiling((double)pagedProviders.TotalItems / (double)pagedProviders.ItemsPerPage);
            }
            else
            {
                pagedProviders.TotalItems = 0;
                pagedProviders.TotalPages = 0;
            }

            pagedProviders.Providers = providers;

            return pagedProviders;
        }

        /// <summary>
        /// underlying method to get a paged list of content IDs that we can use in the approval dashboards
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="documentTypeAlias"></param>
        /// <param name="page"></param>
        /// <param name="itemsPerPage"></param>
        /// <returns></returns>
        private IEnumerable<PendingItem> GetPendingItems(int userId, string documentTypeAlias, int page, int itemsPerPage)
        {
            var pendingFromDb = UmbracoContext.Current.Application.DatabaseContext.Database.Fetch<PendingItem>(";exec spGetPendingContent @userId, @docTypeAlias, @page, @recordsPerPage", new { userId = userId, docTypeAlias = documentTypeAlias, page = page, recordsPerPage = itemsPerPage });

            return pendingFromDb;
        }
    }
}
