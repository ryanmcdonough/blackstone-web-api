﻿using Savills.Core.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using Umbraco.Web;

namespace Savills.Core.Repositories
{
    /// <summary>
    /// Repository for deling with LeaseInfo data frm the custom table
    /// </summary>
    public class LeaseInfoRepository
    {
        /// <summary>
        /// Gets all of the LeaseINfo items for a specific member
        /// </summary>
        /// <param name="memberId"></param>
        /// <returns></returns>
        public List<LeaseInfo> GetLeaseInfoForMember(int memberId)
        {
            var db = UmbracoContext.Current.Application.DatabaseContext.Database;

            return db.Query<LeaseInfo>("SELECT * FROM wtLease WHERE MemberID = @0 ORDER BY DateTo DESC", memberId).ToList();
        }

        /// <summary>
        /// Gets a specific LeaseInfo item
        /// </summary>
        /// <param name="leaseId"></param>
        /// <returns></returns>
        public LeaseInfo GetLeaseInfoById(Guid leaseId)
        {
            var db = UmbracoContext.Current.Application.DatabaseContext.Database;

            return db.SingleOrDefault<LeaseInfo>(leaseId);
        }

        /// <summary>
        /// Saves an updated LeaseInfo instance
        /// </summary>
        /// <param name="item"></param>
        public void UpdateLeaseInfo(LeaseInfo item)
        {
            var db = UmbracoContext.Current.Application.DatabaseContext.Database;

            db.Update(item);
        }
    }
}
