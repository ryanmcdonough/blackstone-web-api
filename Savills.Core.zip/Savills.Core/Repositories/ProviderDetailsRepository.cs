﻿using Umbraco.Core;
using Umbraco.Core.Models;

namespace Savills.Core.Repositories
{
    public class ProviderDetailsRepository
    {
        /// <summary>
        /// Gets the provider details page for the specified member (if it exists)
        /// </summary>
        /// <param name="memberId"></param>
        /// <returns></returns>
        public IContent GetProviderDetailsPage(int memberId)
        {
            //annoyingly, can't use the built in query provider, due to the lack of support, so having to do this via quick and dirty SQL query
            var id = ApplicationContext.Current.DatabaseContext.Database.FirstOrDefault<int>(@"SELECT cmsContent.nodeId FROM cmsDocument
                INNER JOIN cmsContent ON cmsContent.nodeId = cmsDocument.nodeId
                INNER JOIN cmsContentType ON cmsContent.contentType = cmsContentType.nodeId
                INNER JOIN cmsPropertyData ON cmsPropertyData.versionId = cmsDocument.versionId
                INNER JOIN cmsPropertyType ON cmsPropertyData.propertytypeid = cmsPropertyType.id
                WHERE cmsContentType.alias = 'providerDetail'
                AND cmsPropertyType.Alias = 'provider'
                AND cmsDocument.newest = 1
                AND dataInt = @0", memberId);

            if (id == 0) return null;

            return ApplicationContext.Current.Services.ContentService.GetById(id);
        }
    }
}
