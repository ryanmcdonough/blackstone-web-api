﻿using System;
using System.Configuration;
using System.Linq;
using Umbraco.Web.Models.Trees;
using Umbraco.Web.Trees;

namespace Savills.Core.Events
{
    public class TreeEvents
    {
        private static readonly string[] SettingsTrees = new string[]
        {
            "documentTypes", 
            "templates",
            "partialViews",
            "stylesheets",
            "scripts",
            "languages",
            "mediaTypes" 
        };

        private static readonly string[] SettingsUsers = ConfigurationManager.AppSettings["Savills.DictionaryAccess"].Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

        /// <summary>
        /// Event to check the trees aliases and hide the settings sections for specific users
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public static void HideSettings(TreeControllerBase sender, TreeNodeRenderingEventArgs e)
        {
            if (SettingsTrees.Contains(sender.TreeAlias) && SettingsUsers.Contains(sender.Security.CurrentUser.UserType.Name))
            {
                e.Node.CssClasses.Add("hideTheTree");
            }
        }
    }
}
