﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Savills.Core.Api.Repositories;
using Umbraco.Core;
using Umbraco.Core.Models;

namespace Savills.Core.Events
{
    public class PlaceEvents
    {
        /// <summary>
        /// Method to loop through a collection of items and update the property when it has been published
        /// </summary>
        /// <param name="contentItems"></param>
        public static void UpdateGeoArea(IEnumerable<IContent> contentItems)
        {
            //upload any saved properties to Elastic
            var service = new ElasticRepository();

            foreach (var page in contentItems.Where(a => a.ContentType.Alias == "pagePlace"))
            {

                var place = page.Name;

                var currentGuid = page.GetValue<string>("geoLocationId");

                if (currentGuid.IsNullOrWhiteSpace())
                {
                    currentGuid = Guid.NewGuid().ToString();
                }

                var path = HttpContext.Current.Server.MapPath(page.GetValue<string>("geofile"));

                string readText = System.IO.File.ReadAllText(path);

                var guid = service.AddGeoArea(readText,currentGuid, place);

                page.SetValue("geoLocationID", guid);

            }
        }
    }
}
