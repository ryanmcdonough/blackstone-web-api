﻿using Savills.Core.Api.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using Umbraco.Core.Models;

namespace Savills.Core.Events
{
    public class ReviewEvents
    {
        /// <summary>
        /// Method to loop through a collection of items and update the review scores for proerties where a review has been published
        /// </summary>
        /// <param name="contentItems"></param>
        public static void UpdateReviewScores(IEnumerable<IContent> contentItems)
        {
            //NOTE: this currently uses the content API, as that's ,ore likely to be accurate than relying on the cache 
            //(also, some items might not be in the cache yet at the point these events are fired)
            foreach (var review in contentItems.Where(a => a.ContentType.Alias == "review"))
            {
                //get the parent, only continue if the parent is a property
                var property = review.Parent();

                if (property != null && property.ContentType.Alias == "propertySpace")
                {
                    var reviews = property
                        .Children()
                        .Where(a => a.Published);

                    double totalScore = 0;
                    double numberOfReviews = 0;
                    double finalScore = 0;

                    foreach (var reviewItem in reviews)
                    {
                        var score = reviewItem.GetValue<int>("overallRating");

                        //only proceed if score is greater than 0, as must be at least 1
                        if (score > 0)
                        {
                            totalScore += score;
                            numberOfReviews++;
                        }
                    }

                    //calulate the final score (as long as there are some reviews)
                    if (numberOfReviews > 0)
                    {
                        finalScore = totalScore / numberOfReviews;
                        finalScore = Math.Round(finalScore * 2) / 2;
                    }

                    //update the property
                    ElasticRepository elasticRepo = new ElasticRepository();

                    elasticRepo.UpdatePropertyReviewScore(property.Id, finalScore);
                }
            }
        }
    }
}
