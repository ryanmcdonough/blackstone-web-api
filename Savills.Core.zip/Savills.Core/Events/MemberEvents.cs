﻿using Savills.Core.Crm;
using Savills.Core.Helpers;
using Umbraco.Core.Events;
using Umbraco.Core.Models;

namespace Savills.Core.Events
{
    public class MemberEvents
    {
        public static void UpdateMembers(SaveEventArgs<IMember> e)
        {
            foreach (var member in e.SavedEntities)
            {
                var crm = new CrmService();
                AsyncHelpers.RunSync(() => crm.Member(member));
            }
        }
    }
}