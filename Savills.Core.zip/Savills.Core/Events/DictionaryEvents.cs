﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Umbraco.Core.Logging;
using Umbraco.Core.Services;
using Umbraco.Web;

namespace Savills.Core.Events
{
    using System.Web.WebPages;
    using Helpers;
    using Umbraco.Core.Models;

    public class DictionaryEvents
    {
        internal static void DoSavedDictionaryItem(ILocalizationService sender, Umbraco.Core.Events.SaveEventArgs<IDictionaryItem> e)
        {
            BuildDictionaryFiles();
        }

        internal static void DoDeletedDictionaryItem(ILocalizationService sender, Umbraco.Core.Events.DeleteEventArgs<IDictionaryItem> e)
        {
            BuildDictionaryFiles();
        }

        internal static void BuildDictionaryFiles()
        {
            //get all languages
            var service = UmbracoContext.Current.Application.Services.LocalizationService;

            var languages = service.GetAllLanguages();

            var dictionaries = new Dictionary<string, Dictionary<string, string>>();

            foreach (var language in languages)
            {
                dictionaries.Add(language.CultureInfo.Name.ToLower(), new Dictionary<string, string>());
            }

            //get all dictionary items and add them to the relevant countries
            var dictionaryItems = service.GetDictionaryItemDescendants(null);

            foreach (var item in dictionaryItems)
            {
                foreach (var translation in item.Translations)
                {
                    var translationDictionary = dictionaries[translation.Language.CultureInfo.Name.ToLower()];
                    translationDictionary[item.ItemKey] = GetTranslatedValue(translation, item);
                }
            }

            //write the dictionary files
            foreach (var language in dictionaries)
            {
                try
                {
                    var filePath = HttpContext.Current.Server.MapPath("/data/dictionary-" + language.Key + ".json");

                    System.IO.File.WriteAllText(string.Format(filePath, language.Key),
                        JsonConvert.SerializeObject(language.Value.OrderBy(a => a.Key), Formatting.Indented));

                    var text = System.IO.File.ReadAllText(filePath);

                    text = text.Replace("\"Key\": ", "");
                    text = text.Replace("\"Value\": ", "");
                    text = text.Replace("\",", "\":");
                    text = text.Replace("{", "");
                    text = text.Replace("}", "");
                    text = text.Replace("[", "[ {");
                    text = text.Replace("]", "} ]");

                    System.IO.File.WriteAllText(filePath, text);
                }
                catch (Exception ex)
                {
                    LogHelper.Error(typeof(DictionaryEvents), "Error saving dictionary to file", ex);
                }
            }
        }

        private static string GetTranslatedValue(IDictionaryTranslation translation, IDictionaryItem item)
        {
            return translation.Value.IsEmpty() 
                ? GetFallbackValue(item)
                : translation.Value;
        }

        private static string GetFallbackValue(IDictionaryItem item)
        {
            var fallbackValue = item.Translations
                .FirstOrDefault(translation => translation.Language.IsoCode.Equals(LanguageHelper.DefaultLanguage))?.Value;

            if (fallbackValue == null)
            {
                var message = $"Couldn't find default value for item ID:\"{item.Id}\", key: \"{item.ItemKey}\"";
                LogHelper.Warn(typeof(DictionaryEvents), message);
            }

            return fallbackValue;
        }
    }
}
