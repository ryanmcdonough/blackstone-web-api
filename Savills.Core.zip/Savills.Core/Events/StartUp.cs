﻿using Savills.Core.ContentFinders;
using Savills.Core.UrlProviders;
using Umbraco.Core;
using Umbraco.Core.Services;
using Umbraco.Web.Routing;
using Umbraco.Web.Trees;

namespace Savills.Core.Events
{
    /// <summary>
    /// Wires in the event handlers for the items in the core project
    /// </summary>
    public class StartUp : IApplicationEventHandler
    {
        public void OnApplicationInitialized(UmbracoApplicationBase umbracoApplication, ApplicationContext applicationContext)
        {
            //register custom URL provider for languages
            UrlProviderResolver.Current.InsertTypeBefore<DefaultUrlProvider, MultiLanguageUrlProvider>();

            //register custom content finder for languages
            ContentFinderResolver.Current.InsertTypeBefore<ContentFinderByNotFoundHandlers, MultiLanguageContentFinder>();

            //register custom content finder for SEO pages
            ContentFinderResolver.Current.InsertTypeBefore<ContentFinderByNotFoundHandlers, SeoLandingContentFinder>();
        }

        public void OnApplicationStarted(UmbracoApplicationBase umbracoApplication, ApplicationContext applicationContext)
        {
            //register build dictionary files events
            LocalizationService.DeletedDictionaryItem += DictionaryEvents.DoDeletedDictionaryItem;
            LocalizationService.SavedDictionaryItem += DictionaryEvents.DoSavedDictionaryItem;

            //do initial dictionary build
            DictionaryEvents.BuildDictionaryFiles();

            //wire in the events to clear the multilangugae URL cache for the pages.
            ContentService.Copied += LanguageEvents.ContentService_Copied;
            ContentService.Moved += LanguageEvents.ContentService_Moved;
            ContentService.Published += LanguageEvents.ContentService_Published;
            ContentService.Deleted += LanguageEvents.ContentService_Deleted;
            ContentService.RolledBack += LanguageEvents.ContentService_RolledBack;
            ContentService.UnPublished += LanguageEvents.ContentService_UnPublished;

            //wire in the custom tree events to hide everything apart from transaltion from the settings section for certain users
            
            TreeControllerBase.RootNodeRendering += TreeEvents.HideSettings;
        }

        public void OnApplicationStarting(UmbracoApplicationBase umbracoApplication, ApplicationContext applicationContext)
        {
            
        }
    }
}
