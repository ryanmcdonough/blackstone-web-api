﻿using Hangfire;
using Owin;
using Savills.Core.Filters;
using Savills.Core.Jobs;
using Umbraco.Web;

namespace Savills.Core.Events
{

    public class Start : UmbracoDefaultOwinStartup
    {

        public override void Configuration(IAppBuilder app)
        {
            base.Configuration(app);

            // Configure the database where Hangfire is going 
            // to create its tables
            var cs = Umbraco.Core.ApplicationContext.Current
                .DatabaseContext.ConnectionString;
            GlobalConfiguration.Configuration
                .UseSqlServerStorage(cs);

            var dashboardOptions = new DashboardOptions
            {
                Authorization = new[]
            {
                new UmbracoUserAuthorizationFilter()
            }
            };

            app.UseHangfireDashboard("/hangfire", dashboardOptions);

            // Create a default Hangfire server
            app.UseHangfireServer();

            RecurringJob.AddOrUpdate(() => DataJobs.DownloadCurrency(), Cron.Daily);
            RecurringJob.AddOrUpdate(() => AlertJobs.SendAlerts(), Cron.Daily);
        }

    }

}
