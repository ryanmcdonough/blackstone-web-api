﻿using Savills.Core.Helpers;
using Umbraco.Core;
using Umbraco.Core.Services;

namespace Savills.Core.Events
{
    public class LanguageEvents
    {
        internal static void ContentService_UnPublished(Umbraco.Core.Publishing.IPublishingStrategy sender, Umbraco.Core.Events.PublishEventArgs<Umbraco.Core.Models.IContent> e)
        {
            ClearLanguageUrlCache();
        }

        internal static void ContentService_RolledBack(IContentService sender, Umbraco.Core.Events.RollbackEventArgs<Umbraco.Core.Models.IContent> e)
        {
            ClearLanguageUrlCache();
        }

        internal static void ContentService_Deleted(IContentService sender, Umbraco.Core.Events.DeleteEventArgs<Umbraco.Core.Models.IContent> e)
        {
            ClearLanguageUrlCache();
        }

        internal static void ContentService_Published(Umbraco.Core.Publishing.IPublishingStrategy sender, Umbraco.Core.Events.PublishEventArgs<Umbraco.Core.Models.IContent> e)
        {
            ClearLanguageUrlCache();
        }

        internal static void ContentService_Moved(IContentService sender, Umbraco.Core.Events.MoveEventArgs<Umbraco.Core.Models.IContent> e)
        {
            ClearLanguageUrlCache();
        }

        internal static void ContentService_Copied(IContentService sender, Umbraco.Core.Events.CopyEventArgs<Umbraco.Core.Models.IContent> e)
        {
            ClearLanguageUrlCache();
        }

        /// <summary>
        /// Clears the cached URLS for the multi-language URL finder
        /// </summary>
        internal static void ClearLanguageUrlCache()
        {
            ApplicationContext.Current.ApplicationCache.RuntimeCache.ClearCacheItem(LanguageHelper.LanguageUrlsCache);
        }
    }
}
