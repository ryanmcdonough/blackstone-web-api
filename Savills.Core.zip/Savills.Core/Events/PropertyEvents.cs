﻿using System;
using System.Collections.Generic;
using System.Linq;
using AngularGoogleMaps;
using Archetype.Models;
using Nest;
using Newtonsoft.Json;
using Savills.Core.Api.Repositories;
using Savills.Core.Api.Services;
using Savills.Core.Crm;
using Savills.Core.DataModels;
using Savills.Core.Helpers;
using Savills.Core.Models;
using Umbraco.Core;
using Umbraco.Core.Models;
using Umbraco.Core.Persistence;
using Umbraco.Web;
using Umbraco.Web.Routing;
using Property = Savills.Core.Elastic.Elastic.Model.Property;
using Space = Savills.Core.PropertyEditors.SpaceEditor.Space;

namespace Savills.Core.Events
{
    using RollbarSharp;

    public class PropertyEvents
    {
        private static readonly ElasticService ElasticService = new ElasticService();
        private static readonly UmbracoHelper Helper = new UmbracoHelper(UmbracoContext.Current);

        private static readonly ElasticClient BuildingsElasticClient =
            ElasticService.NewClient("buildings");

        private static readonly ElasticClient BuildingsAllElasticClient =
            ElasticService.NewClient("buildings-all");

        private static readonly UmbracoDatabase UmbracoDatabase =
            ApplicationContext.Current.DatabaseContext.Database;

        /// <summary>
        ///     Method to loop through a collection of items and update the property when it has been published
        /// </summary>
        /// <param name="contentItems"></param>
        public static void UpdateProperties(IEnumerable<IContent> contentItems)
        {
            //upload any saved properties to Elastic
            foreach (var page in contentItems.Where(a => a.ContentType.Alias == "propertySpace"))
            {
                var geoPoint =
                    JsonConvert.DeserializeObject<Model>(page.GetValue<string>("location"));

                // TODO: get property from Elastic, no need to bind everything again?
                var prop = MakeElasticProperty(page, geoPoint);

                prop.Status = "Approved";

                var response = BuildingsElasticClient.Update(
                    DocumentPath<Property>
                        .Id(prop.Id),
                    u => u.Doc(prop).DocAsUpsert());

                var responseAll = BuildingsAllElasticClient.Update(
                    DocumentPath<Property>
                        .Id(prop.Id),
                    u => u.Doc(prop).DocAsUpsert());

                SaveRecentPropertyToDatabase(prop, geoPoint);
            }
        }

        private static void SaveRecentPropertyToDatabase(Property prop, Model geoPoint)
        {
            //Finally insert into new property table for mailing
            var property = new RecentProperty
            {
                PropertyId = prop.Id,
                Longitude = geoPoint.Longitude,
                Latitude = geoPoint.Latitude
            };

            //Delete old records of property
            UmbracoDatabase.Execute("DELETE FROM wtRecentProperty where PropertyId = " + prop.Id);
            UmbracoDatabase.Insert(property);
        }


        public static void SetSpaceGuid(IEnumerable<IContent> contentItems)
        {
            foreach (var page in contentItems.Where(a => a.ContentType.Alias == "propertySpace"))
            {
                //Get desks
                var desks =
                    JsonConvert.DeserializeObject<ArchetypeModel>(
                        page.GetValue<string>("spaceList"));

                var list = new List<Space>();

                if (desks != null)
                {
                    foreach (var fieldset in desks)
                    {
                        try
                        {
                            var desk =
                                JsonConvert.DeserializeObject<Space>(
                                    fieldset.Properties.FirstOrDefault().Value.ToString());

                            if (desk.SpaceId == Guid.Empty)
                            {
                                desk.SpaceId = Guid.NewGuid();
                            }

                            list.Add(desk);
                        }
                        catch (Exception)
                        {
                        }
                    }
                }

                var archetypeModel = new ArchetypeModel();

                var currentFieldsets = new List<ArchetypeFieldsetModel>();

                foreach (var space in list)
                {
                    currentFieldsets.Add(
                        new ArchetypeFieldsetModel
                        {
                            Alias = "Space Selection",
                            Properties = new List<ArchetypePropertyModel>
                            {
                                new ArchetypePropertyModel
                                {
                                    Alias = "space",
                                    Value =
                                        "{ 'type': '" + space.Type + "', 'availablefrom': '" +
                                        space.AvailableFrom.ToString("yyyy-MM-dd") + "', 'price': "
                                        + space.Price +
                                        ", 'minimum': " + space.Minimum + ", 'maximum': "
                                        + space.Maximum +
                                        ", 'spaceId': '" + space.SpaceId + "', 'contract' : '"
                                        + space.Contract +
                                        "', 'crmGuid' : '" + space.CrmGuid + "', 'poa' : "
                                        + space.Poa.ToString().ToLower() + " }"
                                }
                            },
                            Disabled = false
                        });
                }

                archetypeModel.Fieldsets = currentFieldsets;

                var deskList = archetypeModel.SerializeForPersistence();

                page.SetValue(
                    PropertySpace.GetModelPropertyType(x => x.SpaceList).PropertyTypeAlias,
                    deskList);
            }
        }

        public static void SendToCrm(IEnumerable<IContent> contentItems)
        {
            var crm = new CrmService();
            foreach (var page in contentItems.Where(a => a.ContentType.Alias == "propertySpace"))
            {
                AsyncHelpers.RunSync(() => crm.Property(page));
            }
        }

        /// <summary>
        ///     Method to loop through a collection of items and update the property when it has been published
        /// </summary>
        /// <param name="contentItems"></param>
        public static void SavedProperties(IEnumerable<IContent> contentItems)
        {
            //upload any saved properties to Elastic
            foreach (var page in contentItems.Where(a => a.ContentType.Alias == "propertySpace"))
            {
                var geoPoint =
                    JsonConvert.DeserializeObject<Model>(page.GetValue<string>("location"));

                var prop = MakeElasticProperty(page, geoPoint);

                prop.Status = page.Properties["status"].Value as string;

                var response = BuildingsAllElasticClient.Update(
                    DocumentPath<Property>
                        .Id(prop.Id),
                    u => u.Doc(prop).DocAsUpsert());

                SaveRecentPropertyToDatabase(prop, geoPoint);
            }
        }

        /// <summary>
        ///     Method to loop through a collection of items and update the property when it has been published
        /// </summary>
        /// <param name="contentItems"></param>
        public static void SavingProperties(IEnumerable<IContent> contentItems)
        {
            foreach (var page in contentItems.Where(a => a.ContentType.Alias == "propertySpace"))
            {
                if (page.Properties["status"].Value != null)
                {
                    // If saving property set the status back to AwaitingApproval, unless it was
                    // being rejected.
                    if (page.Properties["status"].Value.ToString() == "Rejected")
                    {
                        var propertyStatus = page.HasPublishedVersion
                            ? "RejectedChanges"
                            : "RejectedProperty";

                        page.SetValue("status", propertyStatus);
                    }
                    else if (page.Properties["status"].Value.ToString() == "Unlisted")
                    {

                    }
                    else
                    {
                        page.SetValue("status", "AwaitingApproval");
                    }
                }
                else
                {
                    page.SetValue("status", "AwaitingApproval");
                }

            }
        }


        private static Property MakeElasticProperty(IContent page, Model geoPoint)
        {
            var prop = new Property
            {
                Id = page.Id,
                RelativeLink = Helper.Url(page.Id, UrlProviderMode.Relative),
                GeoLocation =
                    new PointGeoShape(
                        new GeoCoordinate((double) geoPoint.Latitude, (double) geoPoint.Longitude))
            };

            return PropertyService.GenerateElasticProperty(page, prop);
        }


        /// <summary>
        ///     Method to loop through a collection of items and update the property when it has been published
        /// </summary>
        /// <param name="contentItems"></param>
        public static void SetApproved(IEnumerable<IContent> contentItems)
        {
            foreach (var page in contentItems.Where(a => a.ContentType.Alias == "propertySpace"))
            {
                page.SetValue("status", "Approved");
            }
        }


        /// <summary>
        ///     Method to loop through a collection of items and delete the property when it has been deleted
        /// </summary>
        /// <param name="contentItems"></param>
        public static void UnlistProperties(IEnumerable<IContent> contentItems)
        {
            var service = ApplicationContext.Current.Services;

            //if a property was deleted, remove that property from Elastc
            foreach (var page in contentItems.Where(a => a.ContentType.Alias == "propertySpace"))
            {
                page.SetValue("status", "Unlisted");

               var geoPoint = JsonConvert.DeserializeObject<Model>(page.GetValue<string>("location"));

                // TODO: get property from Elastic, no need to bind everything again?
                var prop = MakeElasticProperty(page, geoPoint);

                service.ContentService.Save(page, TaskHelper.TaskUser, false);

                var responseAll = BuildingsAllElasticClient.Update(
                    DocumentPath<Property>
                        .Id(prop.Id),
                    u => u.Doc(prop).DocAsUpsert());


                var response = BuildingsElasticClient.Delete(
                    DocumentPath<Property>
                        .Id(prop.Id));


                var db = UmbracoDatabase;
                db.Execute("DELETE FROM wtRecentProperty where PropertyId = " + prop.Id);
            }
        }


        /// <summary>
        ///     Method to loop through a collection of items and delete the property when it has been deleted
        /// </summary>
        /// <param name="contentItems"></param>
        public static void DeleteProperties(IEnumerable<IContent> contentItems)
        {
            var service = ApplicationContext.Current.Services;

            //if a property was deleted, remove that property from Elastc
            foreach (var page in contentItems.Where(a => a.ContentType.Alias == "propertySpace"))
            {

                service.ContentService.Save(page,TaskHelper.TaskUser);

                var response = BuildingsElasticClient.Delete(
                    DocumentPath<Property>
                        .Id(page.Id));

                var responseAll = BuildingsAllElasticClient.Delete(
                    DocumentPath<Property>
                        .Id(page.Id));


                var db = UmbracoDatabase;
                db.Execute("DELETE FROM wtRecentProperty where PropertyId = " + page.Id);
            }
        }

        /// <summary>
        ///     Method to loop through a collection of items and delete the property when it has been deleted
        /// </summary>
        /// <param name="contentItems"></param>
        public static void UnpublishProperties(IEnumerable<IContent> contentItems)
        {
            var service = ApplicationContext.Current.Services;


            //if a property was deleted, remove that property from Elastc
            foreach (var page in contentItems.Where(a => a.ContentType.Alias == "propertySpace"))
            {
                page.SetValue("status", "Unlisted");

                service.ContentService.Save(page, TaskHelper.TaskUser);

                //Default stuff
                var prop = new Property
                {
                    Id = page.Id
                };


                var responseAll = BuildingsAllElasticClient.Update(
                    DocumentPath<Property>
                        .Id(prop.Id),
                    u => u.Doc(prop).DocAsUpsert());


                var response = BuildingsElasticClient.Delete(
                    DocumentPath<Property>
                        .Id(prop.Id));

                //Delete old records of property
                var db = UmbracoDatabase;

                db.Execute("DELETE FROM wtRecentProperty where PropertyId = " + prop.Id);
            }
        }

        /// <summary>
        ///     Method to remove properties from baskets when they are deleted/unpublished
        /// </summary>
        /// <param name="contentItems"></param>
        public static void RemoveFromBaskets(IEnumerable<IContent> contentItems)
        {
            var repo = new BasketRepository();

            foreach (var item in contentItems)
            {
                repo.RemoveAllItemsForProperty(item.Id);
            }
        }
    }
}