﻿using Savills.Core.Api.Services;

namespace Savills.Core.Jobs
{
    public static class AlertJobs
    {

        public static void SendAlerts()
        {
            var alertService = new AlertService();

#pragma warning disable 4014
            alertService.SendAlerts();
#pragma warning restore 4014
        }

    }
}
