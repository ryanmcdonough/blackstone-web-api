﻿using Savills.Core.Helpers;
using System.Configuration;
using System.Net;

namespace Savills.Core.Jobs
{
    public static class DataJobs
    {
        public static void DownloadCurrency()
        {
            WebClient webClient = new WebClient();
            var filePath = System.Web.Hosting.HostingEnvironment.MapPath("/data/currency.json");

            var currencies = CurrencyHelper.DefaultCurrency + "," + ConfigurationManager.AppSettings[CurrencyHelper.AllowedCurrencyConfigKey];

            webClient.DownloadFile("http://apilayer.net/api/live?access_key=ebe8e97833edde3cc225bdac61283c85&currencies=" + currencies + "&format=1", filePath);
        }
    }
}
