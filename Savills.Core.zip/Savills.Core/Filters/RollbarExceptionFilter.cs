﻿namespace Savills.Core.Filters
{
    using System.Web.Mvc;
    using RollbarSharp;

    public class RollbarExceptionFilter : IExceptionFilter
    {
        public void OnException(ExceptionContext filterContext)
        {
            if (filterContext.ExceptionHandled)
                return;

            new RollbarClient().SendException(filterContext.Exception);
        }
    }
}
