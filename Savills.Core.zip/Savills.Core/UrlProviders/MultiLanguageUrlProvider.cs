﻿using Savills.Core.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using Umbraco.Core.Cache;
using Umbraco.Core.Configuration;
using Umbraco.Web;
using Umbraco.Web.Routing;

namespace Savills.Core.UrlProviders
{
    public class MultiLanguageUrlProvider : DefaultUrlProvider
    {
        public MultiLanguageUrlProvider() : base(UmbracoConfig.For.UmbracoSettings().RequestHandler)
        {

        }

        public override string GetUrl(UmbracoContext umbracoContext, int id, Uri current, UrlProviderMode mode)
        {
            if (UmbracoContext.Current.PublishedContentRequest != null && LanguageHelper.GetAllowedLanguageCodes().Any(a => a.Equals(UmbracoContext.Current.PublishedContentRequest.Culture.Name, StringComparison.OrdinalIgnoreCase)))
            {
                var url = base.GetUrl(umbracoContext, id, current, mode);

                if (url != null)
                {
                    //no domain, can do simple string format
                    if (!url.StartsWith("http"))
                    {
                        return string.Format("/{0}{1}", UmbracoContext.Current.PublishedContentRequest.Culture.Name.ToLower(), url);
                    }

                    //has domain, so need to do more complex parsing
                    var builder = new UriBuilder(url);

                    builder.Path = string.Format("/{0}{1}", UmbracoContext.Current.PublishedContentRequest.Culture.Name.ToLower(), builder.Path);

                    return builder.ToString();
                }
            }

            return null;
        }

        //return all of the different language URLs so that they can be viewed from the back office
        public override IEnumerable<string> GetOtherUrls(UmbracoContext umbracoContext, int id, Uri current)
        {
            return UmbracoContext.Current.Application.ApplicationCache.RequestCache.GetCacheItem<IEnumerable<string>>(
                "MultiLanguageUrlProvider-OtherUrls-" + id.ToString(),
                () =>
                {
                    var content = umbracoContext.ContentCache.GetById(id);

                    if (content != null)
                    {
                        var urls = new List<string>();

                        var baseUrl = content.Url();

                        foreach (var languageCode in LanguageHelper.GetAllowedLanguageCodes())
                        {
                            urls.Add(LanguageHelper.GetAlternateUrl(baseUrl, languageCode));
                        }

                        return urls;
                    }

                    return Enumerable.Empty<string>();
                });
        }
    }
}
