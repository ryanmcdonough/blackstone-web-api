﻿namespace Savills.Core.Elastic.Models
{
    public class TransportSearch
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public int Distance { get; set; }
        public string[] Types { get; set; }
    }
}
