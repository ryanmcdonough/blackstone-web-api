﻿using Nest;

namespace Savills.Core.Elastic.Elastic.Model
{
    public class Provider
    {
        [String(Analyzer = "keyword")]
        public string Id { get; set; }

        [String]
        public string Name { get; set; }

        [String]
        public string Logo { get; set; }

    }
}
