﻿using Nest;

namespace Savills.Core.Elastic.Elastic.Model
{
    public class Transport
    {
        [String]
        public string Name { get; set; }

        [GeoPoint]
        public GeoLocation GeoLocation { get; set; }

        [String]
        public string Type { get; set; }

        [Number]
        public double Distance { get; set; }
    }
}
