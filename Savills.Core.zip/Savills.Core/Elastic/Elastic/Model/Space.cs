﻿using System;
using Nest;

namespace Savills.Core.Elastic.Elastic.Model
{
    public class Space
    {
        public Guid SpaceId { get; set; }

        [String]
        public string Type { get; set; }

        [Number]
        public int MinimumPeople { get; set; }

        [Number]
        public int MaximumPeople { get; set; }

        [Number]
        public decimal Price { get; set; }

        [Number]
        public decimal SqFt { get; set; }

        [Date]
        public DateTime AvailableFrom { get; set; }

        [String]
        public string Contract { get; set; }

        [String]
        public string Show { get; set; }

        [String]
        public string CrmGuid { get; set; }

        [Boolean]
        public bool Poa { get; set; }

    }
}
