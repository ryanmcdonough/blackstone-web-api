﻿using System.Collections.Generic;
using Nest;
using Savills.Core.PropertyEditors.Facilties;

namespace Savills.Core.Elastic.Elastic.Model
{
    public class Property
    {
        [Number]
        public int Id { get; set; }

        [Number]
        public double Rating { get; set; }

        [Nested]
        public List<Title> Name { get; set; } = new List<Title>();

        [Nested]
        public List<Description> Description { get; set; } = new List<Description>();

        [String]
        public List<string> Photos { get; set; } = new List<string>();

        [GeoShape]
        public PointGeoShape GeoLocation { get; set; }

        [String]
        public string RelativeLink { get; set; }

        [Nested]
        public List<Space> Spaces { get; set; } = new List<Space>();

        [Nested]
        public Location Location { get; set; }

        [Nested]
        public Provider Provider { get; set; }

        [Nested]
        public Facilities Facilities { get; set; } = new Facilities();

        public string Status { get; set; }

        public string Currency { get; set; }
    }

    public class Description
    {
        public string LanguageCode { get; set; }
        public string Content { get; set; }
    }

    public class Title
    {
        public string LanguageCode { get; set; }
        public string Content { get; set; }
    }
}
