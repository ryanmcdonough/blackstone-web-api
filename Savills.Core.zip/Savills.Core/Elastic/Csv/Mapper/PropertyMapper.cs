﻿using Savills.Core.Elastic.Csv.Model;
using TinyCsvParser.Mapping;

namespace Savills.Core.Elastic.Csv.Mapper
{
    public class PropertyMapper : CsvMapping<PropertyImport>
    {
        public PropertyMapper()
        {
            MapProperty(0, x => x.Id);
            MapProperty(1, x => x.Name);
            MapProperty(2, x => x.Desks);
            MapProperty(3, x => x.Latitude);
            MapProperty(4, x => x.Longitude);
            MapProperty(5, x => x.Landlord);
        }
    }
}
