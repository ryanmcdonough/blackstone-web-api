﻿using System;
using Savills.Core.Models;
using Umbraco.Core;
using Umbraco.Web.Routing;

namespace Savills.Core.ContentFinders
{
    public class SeoLandingContentFinder : IContentFinder
    {
        public bool TryFindContent(PublishedContentRequest contentRequest)
        {
            // Don't have a request? Can't give you a content!
            if (contentRequest == null)
            {
                return false;
            }

            // We have already set the language in the previous finder,
            // so if the language is not the default here, we can safely assume that 
            // we can strip the language from the start of the URL.
            var requestedUrl = contentRequest.Uri.GetAbsolutePathDecoded();

            if (requestedUrl.Length > 6
                && requestedUrl.Substring(1, 5).InvariantEquals(contentRequest.Culture.Name))
            {
                requestedUrl = requestedUrl.Substring(6);
            }

            // After stripping the language from the url, do we have any URL left 
            // to work with?
            if (string.IsNullOrEmpty(requestedUrl))
            {
                return false;
            }

            var stopAt = requestedUrl.IndexOf("/", 1, StringComparison.Ordinal);

            if (stopAt <= 0)
            {
                return false;
            }

            //Check if the first part of the URL is an SEO landing page. Ideally we'd query the second part here as well, 
            //but as the models are in the web project, we'll do the second query in the custom controller
            var landingUrl = requestedUrl.Substring(0, stopAt);

            var landingPage =
                contentRequest.RoutingContext.UmbracoContext.ContentCache.GetByRoute(landingUrl);

            if (!(landingPage is PageSeolanding))
            {
                return false;
            }

            // Now look for the bit after the landing page in the URL in places,
            // if it's found, we can set up the 
            // custom model for the page and assign it to the request.
            var page = landingPage as PageSeolanding;

            var placeUrl = requestedUrl.Substring(stopAt);

            var place =
                contentRequest.RoutingContext.UmbracoContext.ContentCache.GetByRoute(placeUrl);

            if (!(place is PagePlace))
            {
                return false;
            }

            page.IsVirtualLandingPage = true;

            page.VirtualUrl = contentRequest.Uri.GetAbsolutePathDecoded();

            if (!page.VirtualUrl.EndsWith("/"))
            {
                page.VirtualUrl += "/";
            }

            page.Place = place as PagePlace;

            contentRequest.PublishedContent = page;
            return true;
        }
    }
}