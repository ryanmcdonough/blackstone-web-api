﻿using Savills.Core.Helpers;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Umbraco.Core;
using Umbraco.Core.Cache;
using Umbraco.Core.Models;
using Umbraco.Web.Routing;

namespace Savills.Core.ContentFinders
{
    public class MultiLanguageContentFinder : IContentFinder
    {
        public bool TryFindContent(PublishedContentRequest contentRequest)
        {
            if (contentRequest != null)
            {
                //check for language in the URL
                var requestedUrl = contentRequest.Uri.GetAbsolutePathDecoded();

                var languageCode = requestedUrl.Split("/".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).First().ToLower();

                //only look for the content and set the culture if it's a langugae that we actively support
                if (LanguageHelper.GetAllowedLanguageCodes().Any(a => a.Equals(languageCode, StringComparison.OrdinalIgnoreCase)))
                {
                    //check if the url is cached first, so we don't have to do anything
                    var cachedUrls = ApplicationContext.Current.ApplicationCache.RuntimeCache.GetCacheItem<Dictionary<string, IPublishedContent>>(LanguageHelper.LanguageUrlsCache, () => new Dictionary<string, IPublishedContent>());

                    IPublishedContent page;

                    //set the language, even if we don't find the page, so we can have multi-lingual 404 pages etc
                    contentRequest.Culture = new CultureInfo(languageCode);

                    if (cachedUrls.ContainsKey(requestedUrl))
                    {
                        page = cachedUrls[requestedUrl];
                    }
                    else
                    {
                        //strip the first five characters
                        var realUrl = requestedUrl.Substring(6);

                        if (string.IsNullOrEmpty(realUrl))
                        {
                            realUrl = "/";
                        }

                        page = contentRequest.RoutingContext.UmbracoContext.ContentCache.GetByRoute(realUrl);
                    }

                    if (page != null)
                    {
                        //set item in cache
                        cachedUrls[requestedUrl] = page;

                        //set the page for the request
                        contentRequest.PublishedContent = page;
                    }
                }
            }

            return contentRequest.PublishedContent != null;
        }
    }
}