﻿using System;
using System.Collections.Generic;
using System.Web;
using Umbraco.Core.Cache;

namespace Savills.Core.CacheProvider
{
    /// <summary>
    /// This is a stub cache provider to allow us to have custom dictionaries that don't share the same cached language
    /// </summary>
    /// <remarks>Only the method we need is implemented, DO NOT use this cache provider for anything else</remarks>
    public class LanguageCacheProvider : ICacheProvider
    {
        private readonly string _cachePrefix;

        public LanguageCacheProvider(string cachePrefix)
        {
            _cachePrefix = cachePrefix;
        }

        public object GetCacheItem(string cacheKey, Func<object> getCacheItem)
        {
            cacheKey = _cachePrefix + cacheKey;

            var result = HttpContext.Current.Items[cacheKey] as Lazy<object>;

            if (result == null)
            {
                result = new Lazy<object>(getCacheItem);

                HttpContext.Current.Items[cacheKey] = result;
            }

            return result.Value;
        }

        #region methods we don't care about

        public void ClearAllCache()
        {
            throw new NotImplementedException();
        }

        public void ClearCacheByKeyExpression(string regexString)
        {
            throw new NotImplementedException();
        }

        public void ClearCacheByKeySearch(string keyStartsWith)
        {
            throw new NotImplementedException();
        }

        public void ClearCacheItem(string key)
        {
            throw new NotImplementedException();
        }

        public void ClearCacheObjectTypes(string typeName)
        {
            throw new NotImplementedException();
        }

        public void ClearCacheObjectTypes<T>()
        {
            throw new NotImplementedException();
        }

        public void ClearCacheObjectTypes<T>(Func<string, T, bool> predicate)
        {
            throw new NotImplementedException();
        }

        public object GetCacheItem(string cacheKey)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<object> GetCacheItemsByKeyExpression(string regexString)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<object> GetCacheItemsByKeySearch(string keyStartsWith)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
