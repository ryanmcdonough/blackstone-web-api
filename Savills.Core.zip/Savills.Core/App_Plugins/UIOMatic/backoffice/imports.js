﻿var app = angular.module("umbraco");

//These are my Angular modules that I want to inject/require

app.requires.push('relativeDate');