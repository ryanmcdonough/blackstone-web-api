﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.WebPages;
using AngularGoogleMaps;
using Archetype.Models;
using Nest;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Savills.Core.Api.Models;
using Savills.Core.Api.Repositories;
using Savills.Core.Api.Services;
using Savills.Core.CRMModels;
using Savills.Core.Elastic.Elastic.Model;
using Savills.Core.Helpers;
using Savills.Core.Models;
using Umbraco.Core;
using Umbraco.Core.Models;
using Umbraco.Core.Persistence;
using Umbraco.Web;
using Umbraco.Web.Routing;
using Property = Savills.Core.Elastic.Elastic.Model.Property;
using Space = Savills.Core.PropertyEditors.SpaceEditor.Space;
using Task = System.Threading.Tasks.Task;
using Umbraco.Core.Logging;

namespace Savills.Core.Crm
{
    public class CrmService
    {
        private static readonly ElasticService ElasticService = new ElasticService();
        private static readonly UmbracoHelper Helper = new UmbracoHelper(ContextHelper.EnsureUmbracoContext());

        private static readonly ElasticClient BuildingsElasticClient =
            ElasticService.NewClient("buildings");

        private static readonly ElasticClient BuildingsAllElasticClient =
            ElasticService.NewClient("buildings-all");

        private static readonly UmbracoDatabase UmbracoDatabase =
            ApplicationContext.Current.DatabaseContext.Database;

        public static readonly bool Enabled = ConfigurationManager.AppSettings["Crm.Enable"]
            .TryConvertTo<bool>()
            .Result;

        public static readonly bool LoggingEnabled = ConfigurationManager.AppSettings["Crm.Logging.Enable"]
           .TryConvertTo<bool>()
           .Result;

        private string _contactUri;
        //Provides a persistent client-to-CRM server communication channel.

        private static async Task<string> Token(string userName, string password)
        {
            if(userName == "")
            {
                userName = ConfigurationManager.AppSettings["Crm.Username.Master"];
            }

            if(password == "")
            {
                password = ConfigurationManager.AppSettings["Crm.Password.Master"];
            }

            // Once you've created your Native Client in Azure AD, you can get the clientID for it
            var azureTenantGuid = ConfigurationManager.AppSettings["Crm.AzureTenant"];
            var clientId = ConfigurationManager.AppSettings["Crm.AzureClient"];
            var tokenRequestUrl =
                string.Format(
                    @"https://login.microsoftonline.com/{0}/oauth2/token",
                    azureTenantGuid);
            // The credentials for the CRM *user* that you are accessing CRM on behalf of
            var crmUrl = ConfigurationManager.AppSettings["Crm.Url"];

            // Connect to the authentication server
            var request = (HttpWebRequest) WebRequest.Create(tokenRequestUrl);
            request.Method = "POST";

            // Write our request to the request body
            using (var reqStream = await request.GetRequestStreamAsync())
            {
                var postData =
                    string.Format(
                        @"client_id={0}&resource={1}&username={2}&password={3}&grant_type=password",
                        clientId,
                        crmUrl,
                        userName,
                        password);
                var postBytes = new ASCIIEncoding().GetBytes(postData);
                reqStream.Write(postBytes, 0, postBytes.Length);
                reqStream.Close();
            }

            // Call the authentication server and parse out the response
            var accessToken = "";

            using (var response = (HttpWebResponse)request.GetResponse())
            {
                // Proceed interpreting result
                var dataStream = response.GetResponseStream();
                if (dataStream != null)
                {
                    var reader = new StreamReader(dataStream);

                    // The response is returned as JSON, these lines just conver it to a C# object. The format includes our access token:
                    // Example format: {access_Token: "abc...", scope: "public"}
                    var json = reader.ReadToEnd();

                    var tokenSummary = JsonConvert.DeserializeObject<TokenSummary>(json);
                    accessToken = tokenSummary.access_token;
                }
            }

            return accessToken;
        }

        public async Task Member(IMember member)
        {
            if (!Enabled)
            {
                return;
            }

            // Call the authentication server and parse out the response
            var accessToken = await Token("","");

            try
            {
                var memberObject = new JObject();

                var memberService = ApplicationContext.Current.Services.MemberService;
                var contentService = ApplicationContext.Current.Services.ContentService;

                var provider = contentService.GetById(member.GetValue<int>("providerID"));

                LogInfo(string.Format("Begin CRM Update For Member: {0} {1} ({2})", member.GetValue<string>("firstName"), member.GetValue<string>("lastName"), member.Id));

                memberObject.Add("wt_firstname", member.GetValue<string>("firstName"));
                memberObject.Add("wt_name", member.GetValue<string>("lastName"));
                memberObject.Add("wt_email", member.Email);
                memberObject.Add("wt_id", member.Id);
                memberObject.Add("wt_receiveemail", member.GetValue<bool>("receiveEMails"));
                memberObject.Add(
                    "wt_receivemarketing",
                    member.GetValue<bool>("receiveMarketingEMails"));
                memberObject.Add("wt_company", member.GetValue<string>("company"));

                if (provider != null)
                {
                    memberObject.Add("wt_isprovider", true);
                    memberObject.Add("wt_providertrusted", true);
                    memberObject.Add(
                        "wt_providername",
                        provider.GetValue("displayName").ToString());
                    memberObject.Add("wt_providerid", provider.Id);
                    memberObject.Add("wt_providerdescription", "");

                    LogInfo(string.Format("Provider ID: {0}", provider.Id));
                }
                else
                {
                    memberObject.Add("wt_isprovider", false);

                    LogInfo("Not a Provider");
                }

                var method = HttpMethod.Post;
                var table = "wt_members";

                //If there's a guid then put and append the guid to the request.
                if (!string.IsNullOrEmpty(member.GetValue<string>("crmGuid")))
                {
                    method = new HttpMethod("PATCH");
                    table = "wt_members(" + member.GetValue<string>("crmGuid") + ")";
                }

                LogInfo(string.Format("CRM Details: Method:{0}, CRM Table:{1}", method.ToString(), table));

                // Now make a request to Dynamics CRM, passing in the toekn
                var apiBaseUrl = ConfigurationManager.AppSettings["Crm.BaseUrl"];
                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", accessToken);

                var createRequest1 = new HttpRequestMessage(method, apiBaseUrl + table);
                createRequest1.Content = new StringContent(
                    memberObject.ToString(),
                    Encoding.UTF8,
                    "application/json");
                var createResponse1 = await httpClient.SendAsync(createRequest1);

                if (createResponse1.StatusCode == HttpStatusCode.NoContent) //204
                {
                    _contactUri = createResponse1.Headers.GetValues("OData-EntityId")
                        .FirstOrDefault();
                    createResponse1.Headers.GetValues("OData-EntityId").FirstOrDefault();

                    var guid = _contactUri.Split('(', ')')[1];
                    member.SetValue("crmGuid", guid);
                    memberService.Save(member, false);

                    LogInfo(string.Format("Member {0} Updated with CRM GUID: {1}", member.Id, guid));
                }

                LogInfo(string.Format("CRM Update Finished For Member: {0}", member.Id));
            }
            catch (Exception ex)
            {
                // ignored

                LogInfo(string.Format("An Error Occured Updating Member: {0}, Error Was: {1}", member.Id, ex.Message));
            }
        }

        public async Task Property(IContent building)
        {
            if (!Enabled)
            {
                return;
            }

            var propertyUrl = string.Empty;

            // Call the authentication server and parse out the response
            var accessToken = await Token("", "");
            try
            {
                var memberObject = new JObject();

                var memberService = ApplicationContext.Current.Services.MemberService;
                var contentService = ApplicationContext.Current.Services.ContentService;

                var provider = contentService.GetById(building.GetValue<int>("provider"));

                var providerDetail = memberService.GetById(provider.GetValue<int>("provider"));


                memberObject.Add("wt_id", building.Id);
                memberObject.Add("wt_name", building.Name);
                //facilities
                memberObject.Add(
                    "wt_adminsupport",
                    building.GetValue<bool>("facilityAdminSupport"));
                memberObject.Add("wt_aircon", building.GetValue<bool>("facilityAirCon"));
                memberObject.Add(
                    "wt_access24hour",
                    building.GetValue<bool>("facility24HourAccess"));
                memberObject.Add("wt_bar", building.GetValue<bool>("facilityBar"));
                memberObject.Add("wt_bikeparking", building.GetValue<bool>("facilityBikeParking"));
                memberObject.Add(
                    "wt_businessadvice",
                    building.GetValue<bool>("facilityBusinessAdvice"));
                memberObject.Add(
                    "wt_breakoutarea",
                    building.GetValue<bool>("facilityBreakoutArea"));
                memberObject.Add("wt_cleaning", building.GetValue<bool>("facilityCleaning"));
                memberObject.Add("wt_concierge", building.GetValue<bool>("facilityConcierge"));
                memberObject.Add("wt_courtyard", building.GetValue<bool>("facilityCourtyard"));
                memberObject.Add(
                    "wt_disabledaccess",
                    building.GetValue<bool>("facilityDisabledAccess"));
                memberObject.Add("wt_eventspace", building.GetValue<bool>("facilityEventSpace"));
                memberObject.Add("wt_foodservice", building.GetValue<bool>("facilityFoodService"));
                memberObject.Add("wt_furnished", building.GetValue<bool>("facilityFurnished"));
                memberObject.Add("wt_gym", building.GetValue<bool>("facilityGym"));
                memberObject.Add("wt_kitchen", building.GetValue<bool>("facilityKitchen"));
                memberObject.Add("wt_lifts", building.GetValue<bool>("facilityLifts"));
                memberObject.Add("wt_lockers", building.GetValue<bool>("facilityLockers"));
                memberObject.Add(
                    "wt_meetingrooms",
                    building.GetValue<bool>("facilityMeetingRooms"));
                memberObject.Add(
                    "wt_networkingevents",
                    building.GetValue<bool>("facilityNetworkingEvents"));
                memberObject.Add("wt_parking", building.GetValue<bool>("facilityParking"));
                memberObject.Add("wt_petsallowed", building.GetValue<bool>("facilityPetsAllowed"));
                memberObject.Add("wt_pingpong", building.GetValue<bool>("facilityPingPong"));
                memberObject.Add("wt_reception", building.GetValue<bool>("facilityReception"));
                memberObject.Add(
                    "wt_rooftopterrace",
                    building.GetValue<bool>("facilityRooftopTerrace"));
                memberObject.Add(
                    "wt_rurallocation",
                    building.GetValue<bool>("facilityRuralLocation"));
                memberObject.Add("wt_showers", building.GetValue<bool>("facilityShowers"));
                memberObject.Add("wt_teaandcoffee", building.GetValue<bool>("facilityTea"));
                memberObject.Add("wt_unfurnished", building.GetValue<bool>("facilityUnfurnished"));
                memberObject.Add(
                    "wt_universitylink",
                    building.GetValue<bool>("facilityUniversityLink"));
                memberObject.Add("wt_wifi", building.GetValue<bool>("facilityWifi"));

                memberObject.Add("wt_addressline1", building.GetValue<string>("addressLine1"));
                memberObject.Add("wt_addressline2", building.GetValue<string>("addressLine2"));
                memberObject.Add("wt_addressline3", building.GetValue<string>("addressLine3"));
                memberObject.Add("wt_addresscity", building.GetValue<string>("addressCity"));
                memberObject.Add("wt_addresscounty", building.GetValue<string>("addressCounty"));
                memberObject.Add("wt_addresscountry", building.GetValue<string>("addressCountry"));
                memberObject.Add(
                    "wt_addresspostcode",
                    building.GetValue<string>("addressPostcode"));

                var geoPoint =
                    JsonConvert.DeserializeObject<Model>(building.GetValue<string>("location"));

                memberObject.Add("wt_addresslatitude", decimal.Round(geoPoint.Latitude, 5));
                memberObject.Add("wt_addresslongitude", decimal.Round(geoPoint.Longitude, 5));

                var descriptions =
                    JsonConvert.DeserializeObject<VortoValue>(
                        building.GetValue<string>("description"));

                foreach (var item in descriptions.Values)
                {
                    if (item.Key == "en-US")
                    {
                        memberObject.Add("wt_description", item.Value.ToString());
                    }
                }

                var umbracoContext = ContextHelper.EnsureUmbracoContext();
                var helper = new UmbracoHelper(umbracoContext);

                var content = helper.TypedContent(building.Id);

                memberObject.Add("wt_relativelink", content != null ? content.Url : "");

                memberObject.Add("wt_currency", building.GetValue<string>("currency") ?? "");
                memberObject.Add("wt_memberproviderid", building.GetValue<int>("provider"));
                memberObject.Add("wt_providername", provider.GetValue<string>("displayName"));
                memberObject.Add("wt_status", building.GetValue<string>("status"));
                memberObject.Add("wt_approved", building.HasPublishedVersion);

                var guidUrl = "/wt_members(" + providerDetail.GetValue<string>("crmGuid") + ")";
                memberObject.Add("wt_Member@odata.bind", guidUrl);

                var method = HttpMethod.Post;
                var table = "wt_properties";

                ////If there's a guid then put and append the guid to the request.
                if (!string.IsNullOrEmpty(building.GetValue<string>("crmGuid")))
                {
                    method = new HttpMethod("PATCH");
                    table = "wt_properties(" + building.GetValue<string>("crmGuid") + ")";
                }

                // Now make a request to Dynamics CRM, passing in the toekn
                var apiBaseUrl = ConfigurationManager.AppSettings["Crm.BaseUrl"];
                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", accessToken);

                var createRequest1 = new HttpRequestMessage(method, apiBaseUrl + table);
                createRequest1.Content = new StringContent(
                    memberObject.ToString(),
                    Encoding.UTF8,
                    "application/json");
                var createResponse1 = await httpClient.SendAsync(createRequest1);


                if (createResponse1.StatusCode == HttpStatusCode.NoContent) //204
                {
                    propertyUrl =
                        createResponse1.Headers.GetValues("OData-EntityId").FirstOrDefault();
                    var guid = propertyUrl.Split('(', ')')[1];

                    building.SetValue("crmGuid", guid);
                }

                //Jesus now save the spaces.

                var desks =
                    JsonConvert.DeserializeObject<ArchetypeModel>(
                        building.GetValue<string>("spaceList"));
                var spaces = new List<Space>();


                if (desks != null)
                {
                    foreach (var fieldset in desks)
                    {
                        var desk =
                            JsonConvert.DeserializeObject<Space>(
                                fieldset.Properties.FirstOrDefault().Value.ToString());


                        if (!string.IsNullOrEmpty(desk.CrmGuid))
                        {
                            method = new HttpMethod("PATCH");
                            table = "wt_spaces(" + desk.CrmGuid + ")";
                        }
                        else
                        {
                            method = new HttpMethod("POST");
                            table = "wt_spaces";
                        }

                        var deskObject = SpaceToken(desk, propertyUrl);

                        var createRequest = new HttpRequestMessage(method, apiBaseUrl + table);
                        createRequest.Content = new StringContent(
                            deskObject.ToString(),
                            Encoding.UTF8,
                            "application/json");
                        var createResponse = await httpClient.SendAsync(createRequest);


                        if (createResponse.StatusCode == HttpStatusCode.NoContent)
                        {
                            _contactUri =
                                createResponse.Headers.GetValues("OData-EntityId").FirstOrDefault();
                            desk.CrmGuid = _contactUri.Split('(', ')')[1];
                        }

                        spaces.Add(desk);
                    }
                }

                if (spaces.Count != 0)
                {
                    //Now save the property with the spaces.
                    var deskModel = new ArchetypeModel();

                    var currentFieldsets = new List<ArchetypeFieldsetModel>();


                    foreach (var space in spaces)
                    {
                        currentFieldsets.Add(
                            new ArchetypeFieldsetModel
                            {
                                Alias = "Space Selection",
                                Properties = new List<ArchetypePropertyModel>
                                {
                                    new ArchetypePropertyModel
                                    {
                                        Alias = "space",
                                        Value =
                                            "{ 'type': '" + space.Type + "', 'availablefrom': '" +
                                            space.AvailableFrom.ToString("yyyy-MM-dd")
                                            + "', 'price': " + space.Price +
                                            ", 'minimum': " + space.Minimum + ", 'maximum': "
                                            + space.Maximum +
                                            ", 'spaceId': '" + space.SpaceId + "', 'contract' : '"
                                            + space.Contract +
                                            "', 'crmGuid' : '" + space.CrmGuid + "', 'poa' : "
                                            + space.Poa.ToString().ToLower() + " }"
                                    },
                                },
                                Disabled = false,
                            });
                    }

                    deskModel.Fieldsets = currentFieldsets;

                    var deskList = deskModel.SerializeForPersistence();

                    building.SetValue("spaceList", deskList);
                }


                HttpContext.Current = new HttpContext(
                    new HttpRequest(null, "https://www.google.com", null),
                    new HttpResponse(null));
                var contentServicer = ApplicationContext.Current.Services.ContentService;

                if (UmbracoContext.Current == null)
                {
                    UmbracoContext.EnsureContext(
                        new HttpContextWrapper(HttpContext.Current),
                        ApplicationContext.Current);
                }

                var prop = GetElasticProperty(building, geoPoint);

                if (prop.Id != 0)
                {
                    //If it's already published then save and publish, otherwise just save.
                    if (!building.Published)
                    {
                        var responseAll = BuildingsAllElasticClient.Update(
                            DocumentPath<Property>
                                .Id(building.Id),
                            u => u.Doc(prop).DocAsUpsert());

                        //contentServicer.Save(building, TaskHelper.TaskUser, false);
                    }
                    else
                    {
                        var responseAll = BuildingsAllElasticClient.Update(
                            DocumentPath<Property>
                                .Id(building.Id),
                            u => u.Doc(prop).DocAsUpsert());

                        var response = BuildingsElasticClient.Update(
                            DocumentPath<Property>
                                .Id(building.Id),
                            u => u.Doc(prop).DocAsUpsert());
                    }
                }
            }
            catch(Exception e)
            {
                // ignored
            }
        }

        private static Property GetElasticProperty(IContent page, Model geoPoint)
        {
            var prop = new Property
            {
                Id = page.Id,
                RelativeLink = Helper.Url(page.Id, UrlProviderMode.Relative),
                GeoLocation =
                    new PointGeoShape(
                        new GeoCoordinate((double) geoPoint.Latitude, (double) geoPoint.Longitude))
            };

            try
            {
                var desks =
                    JsonConvert.DeserializeObject<ArchetypeModel>(
                        page.GetValue<string>("spaceList"));

                if (desks != null)
                {
                    foreach (var fieldset in desks)
                    {
                        var desk =
                            JsonConvert.DeserializeObject<Space>(
                                fieldset.Properties.FirstOrDefault().Value.ToString());

                        prop.Spaces.Add(
                            PropertyService.GenerateSpace(desk)
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                var test = ex.Data;
            }

            //Get desks
            PropertyService.SetPropertyNames(page, prop);

            PropertyService.SetPropertyDescriptions(page, prop);

            PropertyService.SetFacilities(page, prop);

            var provider = PropertyService.GetLandlord(page);

            PropertyService.GetPhotos(page, prop);

            var location = PropertyService.GetExactAddressLocation(page);

            prop.Provider = provider;
            prop.Location = location;

            prop.Currency = page.GetValue<string>("currency");
            return prop;
        }

        public async Task<string> Enquiry(Enquiry enq)
        {
            if (!Enabled)
            {
                return string.Empty;
            }

            var userDetails = GetCrmUsernamePasswordKeys(enq);

            var elasticRepo = new ElasticRepository();
            // Call the authentication server and parse out the response
            var accessToken = await Token(userDetails.Item1, userDetails.Item2);
            try
            {
                // Now make a request to Dynamics CRM, passing in the toekn
                var apiBaseUrl = ConfigurationManager.AppSettings["Crm.BaseUrl"];

                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Authorization
                    = new AuthenticationHeaderValue("Bearer", accessToken);

                var enquiryToken = EnquiryToken(enq);

                var createEnquiryRequest = new HttpRequestMessage(
                    HttpMethod.Post,
                    apiBaseUrl + "wt_enquiries")
                {
                    Content = new StringContent(
                        enquiryToken.ToString(),
                        Encoding.UTF8,
                        "application/json")
                };

                var createEnquiryResponse = await httpClient.SendAsync(createEnquiryRequest);

                if (createEnquiryResponse.StatusCode == HttpStatusCode.NoContent) //204
                {
                    var enquiryUrl = createEnquiryResponse.Headers.GetValues("OData-EntityId").First();
                    var enquiryGuid = enquiryUrl.Split('(', ')')[1];

                    if (enq.Basket.Any())
                    {
                        if (!string.IsNullOrEmpty(enq.OnlyEnquireAbout))
                        {
                            enq.Basket = enq.Basket
                                .Where(x => x.PropertyId == Convert.ToInt32(enq.OnlyEnquireAbout))
                                .ToList();
                        }
                    }

                    foreach (var item in enq.Basket)
                    {
                        var property = elasticRepo.GetPropertyById(item.PropertyId.ToString());
                        var justEnquire = !item.SpacesInterestedIn.Any();

                        IEnumerable<JToken> tokens = null;

                        if (justEnquire)
                        {
                            var propertyGuid = UmbracoContext.Current.ContentCache
                                .GetById(Convert.ToInt32(property.Id))
                                .GetPropertyValue<string>("crmGuid");

                            // Explicitly only send first space when "Just Enquire" selected.
                            var spacesToEnquireAbout = property.Source.Spaces.Take(1).ToList();

                            tokens = spacesToEnquireAbout
                                .Select(space => EnquirySpaceJustEnquireToken(enquiryGuid, propertyGuid));
                        }
                        else
                        {
                            var spacesToEnquireAbout = item.SpacesInterestedIn;

                            foreach (var spaceToEnquireAbout in spacesToEnquireAbout)
                            {
                                // Find the matching space in the repo and get the CrmGuid 
                                // since it's not passed by front end.
                                var elasticSpace = property.Source.Spaces
                                    .Find(s => s.SpaceId == spaceToEnquireAbout.SpaceId);
                                spaceToEnquireAbout.CrmGuid = elasticSpace.CrmGuid;
                            }

                            tokens = spacesToEnquireAbout
                                .Select(space => EnquirySpaceToken(
                                    enquiryGuid,
                                    space.CrmGuid,
                                    item.DateInterestedIn,
                                    item.TimeInterestedIn));
                        }

                        foreach (var token in tokens)
                        {
                            var createRequest = new HttpRequestMessage(
                                HttpMethod.Post,
                                apiBaseUrl + "wt_enquiryspaces")
                            {
                                Content = new StringContent(
                                    token.ToString(),
                                    Encoding.UTF8,
                                    "application/json")
                            };
                            var createResponse = await httpClient.SendAsync(createRequest);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                // ignored
            }


            return string.Empty;
        }

        public Tuple<string, string> GetCrmUsernamePasswordKeys(Enquiry enq)
        {
            var elasticRepo = new ElasticRepository();


            if(enq.Basket != null)
            {
                if (enq.Basket.Any())
                {

                    HashSet<string> countries = new HashSet<string>();

                    foreach (var item in enq.Basket)
                    {
                        var property = elasticRepo.GetPropertyById(item.PropertyId.ToString());
                        countries.Add(property.Source.Location.AddressCountry);
                    }

                    if (countries.Count == 1)
                    {
                        var countryCode = countries.FirstOrDefault<string>();

                        //if there is only 1 country see if there is a user for that and user that.
                        var usernameKey = "Crm.Username." + countryCode;
                        var passwordKey = "Crm.Password." + countryCode;

                        if (ConfigurationManager.AppSettings[usernameKey] != null)
                        {
                            return Tuple.Create(ConfigurationManager.AppSettings[usernameKey], ConfigurationManager.AppSettings[passwordKey]);
                        }
                    }

                }
            }
            

            //Return GB if there is more than 1 country selected for properties inside the enquiry.
            //All else fails use GB
            return Tuple.Create(ConfigurationManager.AppSettings["Crm.Username.GB"], ConfigurationManager.AppSettings["Crm.Password.GB"]);
        }
       
        public async Task<string> AlertCreation(Alert enq)
        {
            if (!Enabled)
            {
                return string.Empty;
            }

            var elasticRepo = new ElasticRepository();

            // Call the authentication server and parse out the response
            var accessToken = await Token("", "");
            try
            {
                var method = HttpMethod.Post;
                const string table = "wt_alerts";

                // Now make a request to Dynamics CRM, passing in the toekn
                var apiBaseUrl = ConfigurationManager.AppSettings["Crm.BaseUrl"];
                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", accessToken);

                var content = AlertToken(enq, 0);
                var createRequest1 = new HttpRequestMessage(method, apiBaseUrl + table);
                createRequest1.Content = new StringContent(
                    content.ToString(),
                    Encoding.UTF8,
                    "application/json");
                var createResponse1 = await httpClient.SendAsync(createRequest1);

                if (createResponse1.StatusCode == HttpStatusCode.NoContent) //204
                {
                    var enquiryUrl = createResponse1.Headers.GetValues("OData-EntityId")
                        .FirstOrDefault();
                    var enquiryGuid = enquiryUrl.Split('(', ')')[1];
                    enq.CrmGuid = enquiryGuid;
                    elasticRepo.CreateAlert(enq);
                }
            }
            catch
            {
                // ignored
            }

            return string.Empty;
        }

        public async Task<string> AlertSent(AlertMail enq, PropertySpace property)
        {
            if (!Enabled)
            {
                return string.Empty;
            }

            // Call the authentication server and parse out the response
            var accessToken = await Token("", "");
            try
            {
                var method = HttpMethod.Post;
                const string table = "wt_alertspaces";

                // Now make a request to Dynamics CRM, passing in the toekn
                var apiBaseUrl = ConfigurationManager.AppSettings["Crm.BaseUrl"];
                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", accessToken);

                var content = AlertSentToken(enq, property);

                var createRequest = new HttpRequestMessage(method, apiBaseUrl + table);
                createRequest.Content = new StringContent(
                    content.ToString(),
                    Encoding.UTF8,
                    "application/json");
                var createResponse = await httpClient.SendAsync(createRequest);
            }
            catch
            {
                // ignored
            }

            return string.Empty;
        }

        public async Task<string> AlertDeletion(Alert enq)
        {
            if (!Enabled)
            {
                return string.Empty;
            }

            // Call the authentication server and parse out the response
            var accessToken = await Token("", "");
            try
            {
                var method = new HttpMethod("PATCH");
                var table = "wt_alerts(" + enq.CrmGuid + ")";

                // Now make a request to Dynamics CRM, passing in the toekn
                var apiBaseUrl = ConfigurationManager.AppSettings["Crm.BaseUrl"];
                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", accessToken);

                var content = AlertToken(enq, 1);
                var createRequest = new HttpRequestMessage(method, apiBaseUrl + table);
                createRequest.Content = new StringContent(
                    content.ToString(),
                    Encoding.UTF8,
                    "application/json");
                var createResponse = await httpClient.SendAsync(createRequest);
            }
            catch
            {
                // ignored
            }

            return string.Empty;
        }


        public async Task<string> SendEnquiry(Enquiry enquiry)
        {
            if (!Enabled)
            {
                return string.Empty;
            }

            try
            {
                var task = await Enquiry(enquiry);
            }
            catch(Exception ex)
            {
                var w = ex;
                
                // ignored
            }

            return string.Empty;
        }

        public JToken SpaceToken(Space desk, string buildingGuid)
        {
            var deskObject = new JObject
            {
                {"wt_id", desk.SpaceId.ToString()},
                {"wt_availablefrom", desk.AvailableFrom.ToString("yyyy-MM-dd")},
                {"wt_contract", desk.Contract},
                {"wt_maximumpeople", desk.Maximum},
                {"wt_minimumpeople", desk.Minimum},
                {"wt_price", desk.Price},
                {"wt_poa", desk.Poa},
                {"wt_show", "N/A"},
                {"wt_sqft", desk.SqFt},
                {"wt_type", desk.Type},
                {"wt_name", $"{desk.Type} - {desk.Minimum} - {desk.Maximum}"},
                {"wt_Property@odata.bind", buildingGuid}
            };


            return deskObject;
        }

        private static JToken EnquiryToken(Enquiry enq)
        {
            var deskObject = new JObject();

            if (enq.MemberId != 0)
            {
                var memberService = ApplicationContext.Current.Services.MemberService;
                var member = memberService.GetById(enq.MemberId);

                deskObject.Add(
                    "wt_Member@odata.bind",
                    "/wt_members(" + member.GetValue<string>("crmGuid") + ")");
                deskObject.Add("wt_basketid", enq.MemberId.ToString());
            }
            else
            {
                if (enq.BasketUserId != null)
                {
                    deskObject.Add("wt_basketid", enq.BasketUserId);
                }
            }

            deskObject.Add("wt_name", enq.LastName);
            deskObject.Add("wt_firstname", enq.FirstName);
            deskObject.Add("wt_id", Guid.NewGuid().ToString());
            deskObject.Add("wt_company", enq.Company ?? "");
            deskObject.Add("wt_email", enq.EMail);
            deskObject.Add("wt_message", enq.Message ?? "");

            deskObject.Add("wt_phonenumber", enq.PhoneNumber ?? "N/A");
            deskObject.Add("wt_priority", 1);
            deskObject.Add("statuscode", 1);
            return deskObject;
        }


        private static JToken AlertToken(Alert enq, int status)
        {
            var deskObject = new JObject();

            if (enq.MemberId != 0)
            {
                var memberService = ApplicationContext.Current.Services.MemberService;
                var member = memberService.GetById(enq.MemberId);

                deskObject.Add(
                    "wt_Member@odata.bind",
                    "/wt_members(" + member.GetValue<string>("crmGuid") + ")");
            }

            deskObject.Add("wt_name", enq.Description);
            deskObject.Add("wt_distance", enq.Distance);
            deskObject.Add("wt_id", enq.Id);
            deskObject.Add("wt_latitude", enq.GeoLocation.Coordinates.Latitude);
            deskObject.Add("wt_longitude", enq.GeoLocation.Coordinates.Longitude);
            deskObject.Add("statecode", status);
            return deskObject;
        }

        private static JToken AlertSentToken(AlertMail enq, PropertySpace property)
        {
            var deskObject = new JObject();

            if (enq.MemberId != 0)
            {
                var memberService = ApplicationContext.Current.Services.MemberService;
                var member = memberService.GetById(enq.MemberId);

                deskObject.Add(
                    "wt_Member@odata.bind",
                    "/wt_members(" + member.GetValue<string>("crmGuid") + ")");
            }

            deskObject.Add("wt_Property@odata.bind", "/wt_properties(" + property.CrmGuid + ")");
            deskObject.Add("wt_Alert@odata.bind", "/wt_alerts(" + enq.CrmGuid + ")");

            return deskObject;
        }

        private static JToken EnquirySpaceToken(
            string enquiryGuid,
            string spaceGuid,
            string viewingDate,
            string viewingTime)
        {

            //Done with this rubbish.
            if (viewingDate != null)
            {
                var enteredDate = DateTime.Parse(viewingDate);

                var deskObject = new JObject
                {
                    {"wt_Enquiry@odata.bind", "/wt_enquiries(" + enquiryGuid + ")"},
                    {"wt_id", Guid.NewGuid()},
                    {"statuscode", 1},
                    {"wt_Space@odata.bind", "/wt_spaces(" + spaceGuid + ")"},
                    {"wt_viewingdate", enteredDate.ToString("yyyy-MM-dd")},
                    {"wt_viewingtime", viewingTime}
                };

                return deskObject;
            }
            else
            {
                var deskObject = new JObject
                {
                    {"wt_Enquiry@odata.bind", "/wt_enquiries(" + enquiryGuid + ")"},
                    {"wt_id", Guid.NewGuid()},
                    {"statuscode", 1},
                    {"wt_Space@odata.bind", "/wt_spaces(" + spaceGuid + ")"},
                    {"wt_viewingdate", null},
                    {"wt_viewingtime", null}
                };

                return deskObject;
            }


        }

        private static JToken EnquirySpaceJustEnquireToken(
            string enquiryGuid,
            string propertyGuid)
        {
            var deskObject = new JObject
            {
                {"wt_Enquiry@odata.bind", "/wt_enquiries(" + enquiryGuid + ")"},
                {"wt_id", Guid.NewGuid()},
                {"statuscode", 1},
                {"wt_Property@odata.bind", "/wt_properties(" + propertyGuid + ")"}
            };

            return deskObject;
        }

        private void LogInfo(string message)
        {
            if (LoggingEnabled)
            {
                LogHelper.Info(typeof(CrmService), message);
            }
        }
    }
}