﻿using System;
// ReSharper disable InconsistentNaming

namespace Savills.Core.Crm
{
    public class TokenSummary
    {
        public string token_type { get; set; }
        public string scope { get; set; }
        public int expires_in { get; set; }
        public int ext_expires_in { get; set; }
        public Int64 expires_on { get; set; }
        public Int64 not_before { get; set; }
        public string resource { get; set; }
        public string access_token { get; set; }
    }
}
