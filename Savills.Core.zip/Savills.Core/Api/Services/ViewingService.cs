﻿using System;
using System.Linq;
using Savills.Core.DataModels;
using Umbraco.Core;

namespace Savills.Core.Api.Services
{
    public class ViewingService
    {
        public Guid Insert(ViewingReview data)
        {
            var db = ApplicationContext.Current.DatabaseContext.Database;

            data.Id = Guid.NewGuid();
            data.Complete = false;
            data.Rating = 0;

            db.Insert(data);

            return data.Id;
        }

        public ViewingReview Get(Guid data)
        {
            var db = ApplicationContext.Current.DatabaseContext.Database;

            var result = db.Query<ViewingReview>("SELECT * FROM wtViewingReview where Id = '" + data + "'");

            return result.FirstOrDefault();
        }

        public bool Complete(ViewingReview data)
        {
            var db = ApplicationContext.Current.DatabaseContext.Database;
            data.Complete = true;

            db.Update(data);

            return true;
        }

    }
}
