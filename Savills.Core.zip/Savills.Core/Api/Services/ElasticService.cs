﻿using System;
using System.Configuration;
using Nest;

namespace Savills.Core.Api.Services
{
    public class ElasticService
    {
        private readonly string _appSetting = ConfigurationManager.AppSettings["Savills.Elastic.Location"];
        private readonly string _elasticPassword = ConfigurationManager.AppSettings["Savills.Elastic.Password"];
        private readonly string _elasticUserName = ConfigurationManager.AppSettings["Savills.Elastic.Username"];

        public ElasticClient NewClient(string index)
        {
            var node = new Uri(_appSetting);

            var settings = new ConnectionSettings(node);
            settings.DisableDirectStreaming();
            settings.BasicAuthentication(_elasticUserName, _elasticPassword);

            settings.DefaultIndex(index);

            return new ElasticClient(settings);
        }
    }
}