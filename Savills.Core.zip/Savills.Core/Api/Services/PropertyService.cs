﻿using System;
using System.Linq;
using AngularGoogleMaps;
using Archetype.Models;
using Nest;
using Newtonsoft.Json;
using Savills.Core.Elastic.Elastic.Model;
using Savills.Core.Extensions;
using Savills.Core.Helpers;
using Savills.Core.Models;
using Umbraco.Core;
using Umbraco.Core.Models;
using Umbraco.Core.Persistence;
using Umbraco.Web;
using Umbraco.Web.Routing;

namespace Savills.Core.Api.Services
{
    using Property = Elastic.Elastic.Model.Property;
    using ElasticSpace = Elastic.Elastic.Model.Space;
    using UmbracoSpace = Savills.Core.PropertyEditors.SpaceEditor.Space;
    using MemberExtensions = Extensions.MemberExtensions;


    public class PropertyService
    {
        private static readonly ElasticService ElasticService = new ElasticService();
        private static readonly UmbracoHelper Helper = new UmbracoHelper(UmbracoContext.Current);

        private static readonly ElasticClient BuildingsElasticClient =
            ElasticService.NewClient("buildings");

        private static readonly ElasticClient BuildingsAllElasticClient =
            ElasticService.NewClient("buildings-all");

        private static readonly UmbracoDatabase UmbracoDatabase =
            ApplicationContext.Current.DatabaseContext.Database;

        public bool UnlistProperty(int id, IPublishedContent currentMember)
        {
            var helper = new UmbracoHelper(UmbracoContext.Current);

            var isAllowedToEdit = currentMember.CanManageProperty(id);

            if (isAllowedToEdit)
            {

                var service = ApplicationContext.Current.Services;
                var property = service.ContentService.GetById(id);
                property.SetValue("status", "Unlisted");

                var geoPoint = JsonConvert.DeserializeObject<Model>(property.GetValue<string>("location"));

                // TODO: get property from Elastic, no need to bind everything again?
                var prop = MakeElasticProperty(property, geoPoint);

                service.ContentService.Save(property, TaskHelper.TaskUser);

                var responseAll = BuildingsAllElasticClient.Update(
                    DocumentPath<Property>
                        .Id(prop.Id),
                    u => u.Doc(prop).DocAsUpsert());


                var response = BuildingsElasticClient.Delete(
                    DocumentPath<Property>
                        .Id(prop.Id));

                //Delete old records of property
                var db = UmbracoDatabase;

                db.Execute("DELETE FROM wtRecentProperty where PropertyId = " + prop.Id);

                service.ContentService.UnPublish(property,TaskHelper.TaskUser);
            }

            return true;
        }

        public bool RelistProperty(int id, IPublishedContent currentMember)
        {
            var helper = new UmbracoHelper(UmbracoContext.Current);

            var isAllowedToEdit = currentMember.CanManageProperty(id);
            var isTrustedProvider = currentMember.IsTrustedProvider();


            if (isAllowedToEdit)
            {
                var service = ApplicationContext.Current.Services;
                var property = service.ContentService.GetById(id);

                var geoPoint = JsonConvert.DeserializeObject<Model>(property.GetValue<string>("location"));

                // TODO: get property from Elastic, no need to bind everything again?
                var prop = MakeElasticProperty(property, geoPoint);

                var responseAll = BuildingsAllElasticClient.Update(
                    DocumentPath<Property>
                        .Id(prop.Id),
                    u => u.Doc(prop).DocAsUpsert());


                var response = BuildingsElasticClient.Update(
                    DocumentPath<Property>
                        .Id(prop.Id),
                    u => u.Doc(prop).DocAsUpsert());


                if (isTrustedProvider)
                {
                    property.SetValue("status", "Approved");
                    service.ContentService.SaveAndPublishWithStatus(property);
                }
                else
                {
                    property.SetValue("status", "AwaitingApproval");
                    service.ContentService.Save(property);
                }
               
            }

            return true;
        }

        private static Property MakeElasticProperty(IContent page, Model geoPoint)
        {
            var prop = new Property
            {
                Id = page.Id,
                RelativeLink = Helper.Url(page.Id, UrlProviderMode.Relative),
                GeoLocation =
                    new PointGeoShape(
                        new GeoCoordinate((double)geoPoint.Latitude, (double)geoPoint.Longitude))
            };

            return GenerateElasticProperty(page, prop);
        }

        public static Property GenerateElasticProperty(IContent page, Property prop)
        {
            try
            {
                var desks =
                    JsonConvert.DeserializeObject<ArchetypeModel>(
                        page.GetValue<string>("spaceList"));

                if (desks != null)
                {
                    foreach (var fieldset in desks)
                    {
                        var desk =
                            JsonConvert.DeserializeObject<UmbracoSpace>(
                                fieldset.Properties.FirstOrDefault().Value.ToString());

                        var space = GenerateSpace(desk);

                        prop.Spaces.Add(space);
                    }
                }
            }
            catch (Exception ex)
            {
                var test = ex.Data;
            }

            SetPropertyNames(page, prop);

            SetPropertyDescriptions(page, prop);

            SetFacilities(page, prop);
            
            var provider = GetLandlord(page);

            GetPhotos(page, prop);

            var location = GetExactAddressLocation(page);

            prop.Provider = provider;
            prop.Location = location;

            prop.Currency = page.GetValue<string>("currency");
            return prop;
        }

        public static ElasticSpace GenerateSpace(UmbracoSpace desk)
        {
            if (desk.SpaceId == Guid.Empty)
            {
                desk.SpaceId = Guid.NewGuid();
            }

            var deskSpace = new ElasticSpace
            {
                AvailableFrom = desk.AvailableFrom,
                Contract = desk.Contract,
                CrmGuid = desk.CrmGuid,
                MaximumPeople = desk.Maximum,
                MinimumPeople = desk.Minimum,
                Price = desk.Price,
                Show = "",
                SpaceId = desk.SpaceId,
                SqFt = desk.SqFt,
                Type = desk.Type,
                Poa = desk.Poa
            };
            return deskSpace;
        }

        public static Location GetExactAddressLocation(IContent page)
        {
            var location = new Location
            {
                AddressLine1 = page.GetValue<string>("addressLine1"),
                AddressLine2 = page.GetValue<string>("addressLine2"),
                AddressLine3 = page.GetValue<string>("addressLine3"),
                AddressLineCity = page.GetValue<string>("addressCity"),
                AddressCounty = page.GetValue<string>("addressCounty"),
                AddressCountry = page.GetValue<string>("addressCountry"),
                AddressLinePostcode = page.GetValue<string>("addressPostcode")
            };
            return location;
        }

        public static void GetPhotos(IContent page, Property prop)
        {
            var photoImageList =
                page.GetValue<string>("photos")
                    ?
                    .Split(new[] {","}, StringSplitOptions.RemoveEmptyEntries)
                    .Select(int.Parse);
            if (photoImageList != null)
            {
                var photoCollection = Helper.TypedMedia(photoImageList);
                foreach (var image in photoCollection)
                {
                    prop.Photos.Add(image.Url);
                }
            }
        }

        public static Provider GetLandlord(IContent page)
        {
            var providerId = page.GetValue<int>("provider");

            var providerContent =
                UmbracoContext.Current.Application.Services.ContentService.GetById(providerId);

            var logo = providerContent.GetValue<int>("logo");

            var actualLogo = Helper.TypedMedia(logo);

            var provider = new Provider
            {
                Id = providerContent.Id.ToString(),
                Name = providerContent.GetValue<string>("displayName"),
                Logo = actualLogo?.Url ?? MemberExtensions.GetFallbackImage()
            };
            return provider;
        }

        public static void SetFacilities(IContent page, Property prop)
        {
            prop.Facilities.Wifi = page.GetValue<bool>("facilityWifi");
            prop.Facilities.Access24Hour = page.GetValue<bool>("facility24HourAccess");
            prop.Facilities.Kitchen = page.GetValue<bool>("facilityKitchen");
            prop.Facilities.Furnished = page.GetValue<bool>("facilityFurnished");
            prop.Facilities.AirCon = page.GetValue<bool>("facilityAirCon");
            prop.Facilities.Reception = page.GetValue<bool>("facilityReception");
            prop.Facilities.MeetingRooms = page.GetValue<bool>("facilityMeetingRooms");
            prop.Facilities.Parking = page.GetValue<bool>("facilityParking");
            prop.Facilities.Showers = page.GetValue<bool>("facilityShowers");
            prop.Facilities.FoodService = page.GetValue<bool>("facilityFoodService");
            prop.Facilities.BikeParking = page.GetValue<bool>("facilityBikeParking");
            prop.Facilities.BreakoutArea = page.GetValue<bool>("facilityBreakoutArea");
            prop.Facilities.Lifts = page.GetValue<bool>("facilityLifts");
            prop.Facilities.Cleaning = page.GetValue<bool>("facilityCleaning");
            prop.Facilities.AdminSupport = page.GetValue<bool>("facilityAdminSupport");
            prop.Facilities.DisabledAccess = page.GetValue<bool>("facilityDisabledAccess");
            prop.Facilities.PetsAllowed = page.GetValue<bool>("facilityPetsAllowed");
            prop.Facilities.EventSpace = page.GetValue<bool>("facilityEventSpace");
            prop.Facilities.Lockers = page.GetValue<bool>("facilityLockers");
            prop.Facilities.PingPong = page.GetValue<bool>("facilityPingPong");
            prop.Facilities.Concierge = page.GetValue<bool>("facilityConcierge");
            prop.Facilities.RoofTopTerrace = page.GetValue<bool>("facilityRooftopTerrace");
            prop.Facilities.CourtYard = page.GetValue<bool>("facilityCourtyard");
            prop.Facilities.TeaAndCoffee = page.GetValue<bool>("facilityTea");
            prop.Facilities.Gym = page.GetValue<bool>("facilityGym");
            prop.Facilities.Unfurnished = page.GetValue<bool>("facilityUnfurnished");
            prop.Facilities.UniversityLink = page.GetValue<bool>("facilityUniversityLink");
            prop.Facilities.RuralLocation = page.GetValue<bool>("facilityRuralLocation");
            prop.Facilities.Bar = page.GetValue<bool>("facilityBar");
            prop.Facilities.NetworkingEvents = page.GetValue<bool>("facilityNetworkingEvents");
            prop.Facilities.BusinessAdvice = page.GetValue<bool>("facilityBusinessAdvice");
        }

        public static void SetPropertyDescriptions(IContent page, Property prop)
        {
            var descriptions =
                JsonConvert.DeserializeObject<VortoValue>(page.GetValue<string>("description"));

            foreach (var item in descriptions.Values)
            {
                prop.Description.Add(
                    new Description
                    {
                        LanguageCode = item.Key,
                        Content = item.Value?.ToString()
                    });
            }
        }

        public static void SetPropertyNames(IContent page, Property prop)
        {
            var titles = JsonConvert.DeserializeObject<VortoValue>(page.GetValue<string>("title"));

            foreach (var item in titles.Values)
            {
                prop.Name.Add(
                    new Title
                    {
                        LanguageCode = item.Key,
                        Content = item.Value.ToString()
                    });
            }
        }
    }
}
