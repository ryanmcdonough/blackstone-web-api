﻿using System;
using System.Collections.Generic;
using System.Linq;
using Savills.Core.Api.Models;
using Savills.Core.Api.Repositories;
using Savills.Core.DataModels;
using Umbraco.Core;

namespace Savills.Core.Api.Services
{
    public class LeaseService
    {

        private readonly ElasticRepository _elasticRepo = new ElasticRepository();

        public Guid Insert(LeaseInfo data)
        {
            var db = ApplicationContext.Current.DatabaseContext.Database;

            data.Id = Guid.NewGuid();

            db.Insert(data);

            return data.Id;
        }

        public LeaseInfo Get(Guid data)
        {
            var db = ApplicationContext.Current.DatabaseContext.Database;

            var result = db.Query<LeaseInfo>("SELECT * FROM wtLease where Id = '" + data + "'");

            return result.FirstOrDefault();
        }

        public bool Update(LeaseInfo data)
        {
            var db = ApplicationContext.Current.DatabaseContext.Database;

            db.Update(data);

            return true;
        }


        public List<Lease> LeasesForMember(int memberId)
        {
            List<Lease> leases = new List<Lease>();

            var db = ApplicationContext.Current.DatabaseContext.Database;

            var leaseList = db.Query<LeaseInfo>("SELECT * FROM wtLease where MemberID = " + memberId);

            if (leaseList.ToList().Count() != 0)
            {
                foreach (var item in leaseList)
                {
                    var lease = new Lease {Details = item};
                    lease.Details.ReviewOn = item.DateFrom.AddDays(14);
                    lease.Property = _elasticRepo.GetPropertyById(item.PropertyId.ToString()).Source;
                }
            }

               

            return leases;

        }

    }
}
