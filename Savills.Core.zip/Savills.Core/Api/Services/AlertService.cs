﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Archetype.Models;
using Nest;
using Newtonsoft.Json;
using Savills.Core.Crm;
using Savills.Core.CRMModels;
using Savills.Core.DataModels;
using Savills.Core.Elastic.Elastic.Model;
using Savills.Core.EmailModels;
using Savills.Core.Models;
using Umbraco.Core;
using Umbraco.Core.Models;
using Umbraco.Web;
using Umbraco.Web.Routing;
using Property = Savills.Core.Elastic.Elastic.Model.Property;

namespace Savills.Core.Api.Services
{
    public class AlertService
    {
        public async Task<bool> SendAlerts()
        {
            //Method just for testing, we will move it somewhere else.
            var service = new ElasticService();

            var client = service.NewClient("alert");
            var propertyClient = service.NewClient("buildings");

            var response = client.Search<Alert>(s => s.From(0).Size(10000));

            var db = ApplicationContext.Current.DatabaseContext.Database;

            var propertyList = db.Query<RecentProperty>("SELECT * FROM wtRecentProperty");

            if (propertyList.ToList().Count() != 0)
            {
                foreach (var data in response.Documents)
                {
                    var geoResult = propertyClient.Search<Property>(s => s.From(0).Size(10000)
                                   .Query(query => query
                                       .Bool(b => b.Filter(filter => filter
                                          .GeoShapeCircle(geo => geo
                                          .Field(f => f.GeoLocation)
                                          .Radius(data.Distance + "km")
                                          .Coordinates(new GeoCoordinate(data.GeoLocation.Coordinates.Latitude, data.GeoLocation.Coordinates.Longitude)))
                                           ))
                                       )
                                    );

                    using (var enumer = propertyList.GetEnumerator())
                    {
                        while (enumer.MoveNext())
                        {
                            foreach (var res in geoResult.Documents)
                            {
                                if (enumer.Current.PropertyId == res.Id)
                                {

                                    var alert = new AlertToSend();

                                    alert.PropertyId = res.Id;
                                    alert.AlertId = data.Id;
                                    alert.UserId = Convert.ToInt32(data.MemberId);
                                    alert.AlertName = data.Description;

                                    SendToDatabase(alert);
                                }
                            }
                        }
                    }

                }

                db.Delete<RecentProperty>("DELETE from wtRecentProperty");

                SendEmail();
            }

            return true;
        }

        public async Task<bool> SendToCrm(AlertMail alert)
        {
            CrmService crm = new CrmService();
            var helper = new UmbracoHelper(UmbracoContext.Current);

            foreach (var property in alert.Properties)
            {
                PropertySpace post = (PropertySpace)helper.TypedContent(property);

                await crm.AlertSent(alert, post);
            }

            return true;
        }

        public bool SendToDatabase(AlertToSend alert)
        {
            var db = ApplicationContext.Current.DatabaseContext.Database;

            db.Insert(alert);

            return true;
        }

        public bool SendEmail()
        {
            var helper = new UmbracoHelper(UmbracoContext.Current);
            var db = ApplicationContext.Current.DatabaseContext.Database;

            var alertList = db.Query<AlertToSend>("SELECT * FROM wtAlertMail");

            if (!alertList.Any()) return true;
            var groupedAlertList = alertList
                .GroupBy(u => u.AlertId)
                .Select(grp => grp.ToList())
                .ToList();


            foreach (var list in groupedAlertList)
            {

                var member = helper.MembershipHelper.GetById(list.FirstOrDefault().UserId);

                var emailToSend = new PropertyAlertEmail();

                emailToSend.To = member.GetPropertyValue("Email").ToString();
                emailToSend.From = "no-reply@sitemail.workthere.com";
                emailToSend.LanguageCode = member.GetPropertyValue("communicationsLanguage").ToString();
                emailToSend.ToName = member.GetPropertyValue("firstName").ToString();

                //Create mail to send to CRM.
                AlertMail crmMail = new AlertMail();

                crmMail.MemberId = member.Id;
                crmMail.AlertId = list.FirstOrDefault().AlertId;
                crmMail.EmailDate = DateTime.Now;
                crmMail.EmailId = Guid.NewGuid();

                foreach (var item in list)
                {
                    //Add properties to CRM alert.
                    crmMail.Properties.Add(item.PropertyId);

                    IPublishedContent property = helper.Content(item.PropertyId);

                    var prop = new Property
                    {
                        Id = property.Id,
                        RelativeLink = helper.Url(property.Id, UrlProviderMode.Relative),
                    };

                    var titless = property.GetProperty("title").DataValue.ToString();

                    var titles = JsonConvert.DeserializeObject<VortoValue>(titless);

                    foreach (var title in titles.Values)
                    {
                        prop.Name.Add(new Title
                        {
                            LanguageCode = title.Key,
                            Content = title.Value.ToString(),
                        });
                    }

                    //Get desks
                    var desks = JsonConvert.DeserializeObject<ArchetypeModel>(property.GetProperty("spaceList").DataValue.ToString());

                    if (desks != null)
                    {
                        foreach (var fieldset in desks)
                        {
                            var desk =
                                JsonConvert.DeserializeObject<Space>(fieldset.Properties.FirstOrDefault().Value.ToString());

                            if (desk.SpaceId == Guid.Empty)
                            {
                                desk.SpaceId = Guid.NewGuid();
                            }

                            prop.Spaces.Add(desk);
                        }
                    }

                    var photoImageList = property.GetProperty("photos").DataValue.ToString().Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse);
                    var photoCollection = helper.TypedMedia(photoImageList);
                    foreach (var image in photoCollection)
                    {
                        prop.Photos.Add(image.Url);
                    }

                    Location location = new Location
                    {
                        AddressLine1 = property.GetProperty("addressLine1").DataValue.ToString(),
                        AddressLine2 = property.GetProperty("addressLine2").DataValue.ToString(),
                        AddressLine3 = property.GetProperty("addressLine3").DataValue.ToString(),
                        AddressLineCity = property.GetProperty("addressCity").DataValue.ToString(),
                        AddressLinePostcode = property.GetProperty("addressPostcode").DataValue.ToString(),
                    };

                    prop.Location = location;

                    emailToSend.AlertName = item.AlertName;
                    emailToSend.Properties.Add(prop);
                }

                //Email the user
                emailToSend.Send();

                //Add record to CRM
#pragma warning disable 4014
                SendToCrm(crmMail);
#pragma warning restore 4014
            }


            db.Delete<AlertMail>("DELETE * from wtAlertMail");

            return true;
        }
    }
}