﻿using Savills.Core.Crm;
using Umbraco.Core;

namespace Savills.Core.Api.Services
{
    public class MembersService
    {
        public void InsertAllMembersCrm()
        {
            Umbraco.Core.Services.IMemberService service = ApplicationContext.Current.Services.MemberService;

            CrmService crmService = new CrmService();

            var members = service.GetAllMembers();

            foreach (var member in members)
            {
#pragma warning disable 4014
                crmService.Member(member);
#pragma warning restore 4014
            }
        }

    }
}
