﻿namespace Savills.Core.Api.Models
{
    public class GuidResponse
    {
        public string Guid { get; set; }
    }
}
