using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Savills.Core.Api.Models.Property
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum GeoSearchType
    {
        GeoShape,
        Bounds,
    }
}