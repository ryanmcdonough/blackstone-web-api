using System.Collections.Generic;
using GeoJSON.Net.Geometry;

namespace Savills.Core.Api.Models.Property
{
    public class GeoShapeSearchType : PropertySearchType
    {
        public GeoShapeSearchType(List<IGeometryObject> geoShapes)
            : base(GeoSearchType.GeoShape)
        {
            GeoShapes = geoShapes;
        }

        public List<IGeometryObject> GeoShapes { get; set; }
    }
}