namespace Savills.Core.Api.Models.Property
{
    public abstract class PropertySearchType
    {
        protected PropertySearchType(GeoSearchType geoSearchType)
        {
            GeoSearchType = geoSearchType;
        }

        public GeoSearchType GeoSearchType { get; protected set; }
    }
}