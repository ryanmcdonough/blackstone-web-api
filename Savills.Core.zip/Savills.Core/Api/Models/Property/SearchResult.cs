using System.Collections.Generic;

namespace Savills.Core.Api.Models.Property
{
    public class SearchResult
    {
        public IEnumerable<Elastic.Elastic.Model.Property> Results { get; set; }

        // The radius to expand the search bounds by, in miles.
        public float? Radius { get; set; }

        public PropertySearchType PropertySearchType { get; set; }
    }
}