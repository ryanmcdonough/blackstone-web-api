using Savills.Core.Models.GoogleMaps.Geocoding;

namespace Savills.Core.Api.Models.Property
{
    public class BoundsSearchType : PropertySearchType
    {
        public BoundsSearchType(GeoRectangle bounds)
            : base(GeoSearchType.Bounds)
        {
            Bounds = bounds;
        }

        public GeoRectangle Bounds { get; set; }
    }
}