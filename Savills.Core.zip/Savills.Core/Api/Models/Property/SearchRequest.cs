using Savills.Core.Models.GoogleMaps.Geocoding;

namespace Savills.Core.Api.Models.Property
{
    public class SearchRequest
    {
        public float? Radius { get; set; }
        public Result GoogleMapsGeocodingResult { get; set; }
    }
}