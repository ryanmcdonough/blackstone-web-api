﻿using System;

namespace Savills.Core.Api.Models
{
    public class AlertRequest
    {
        public Guid Id { get; set; }
        public int MemberId { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public int Distance { get; set; }
        public string Description { get; set; }
    }
}