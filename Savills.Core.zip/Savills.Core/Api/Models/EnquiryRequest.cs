﻿namespace Savills.Core.Api.Models
{
    public class EnquiryRequest
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EMail { get; set; }
        public string PhoneNumber { get; set; }
        public string Company { get; set; }
        public string Message { get; set; }
        public string BasketUserId { get; set; }
        public int MemberId { get; set; }
        public string CrmGuid { get; set; }
        public string OnlyEnquireAbout { get; set; }
        public string LanguageCode { get; set; }
        public bool JustEnquire { get; set; }
    }

}
