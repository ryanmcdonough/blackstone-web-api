﻿using System;
using System.Collections.Generic;
using Savills.Core.Elastic.Elastic.Model;

namespace Savills.Core.Api.Models
{
    public class Enquiry
    {
        public Guid Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EMail { get; set; }
        public string PhoneNumber { get; set; }
        public string Company { get; set; }
        public string BasketUserId { get; set; }
        public IEnumerable<BasketItem> Basket { get; set; }
        public string Message { get; set; }
        public int MemberId { get; set; }
        public string OnlyEnquireAbout { get; set; }
        public bool JustEnquire { get; set; }
    }

}
