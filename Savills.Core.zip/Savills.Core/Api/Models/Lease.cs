﻿using Savills.Core.DataModels;

namespace Savills.Core.Api.Models
{
    public class Lease
    {
        public LeaseInfo Details { get; set; }
        public Elastic.Elastic.Model.Property Property { get; set; }
    }
}
