﻿namespace Savills.Core.Api.ViewModels
{
    public class Transfer
    {
        public string OldUserId { get; set; }
        public string NewUserId { get; set; }
    }
}
