﻿using System.Net;
using System.Net.Http;
using System.Web.Mvc;
using Savills.Core.DataModels;
using Savills.Core.Api.Services;
using Umbraco.Web.WebApi;

namespace Savills.Core.Api.Controllers
{
    public class ViewingController : UmbracoApiController
    {
        private readonly ViewingService  _viewingService = new ViewingService();

        [HttpPost, HttpOptions]
        public object Create(ViewingReview request)
        {
            var response = _viewingService.Insert(request);

            return Request.CreateResponse<object>(HttpStatusCode.OK, response);
        }

    }
}