using System;
using Savills.Core.Helpers;
using Savills.Core.Models.GoogleMaps.Geocoding;

namespace Savills.Core.Api.Controllers
{
    public sealed class TopologyHelper
    {
        private const float EarthRadiusInMiles = 3963;

        /// <summary>
        /// Create a new bound and increase the size of it by the radius in miles.
        /// </summary>
        public static GeoRectangle IncreaseBoundByRadius(GeoRectangle bounds, float? radiusMiles)
        {
            var newBounds = new GeoRectangle
            {
                east = bounds.east,
                north = bounds.north,
                south = bounds.south,
                west = bounds.west,
            };

            if (radiusMiles.HasValue
                // ReSharper disable once CompareOfFloatsByEqualityOperator
                && radiusMiles != 0)
            {
                // Latitude is uniform. The bounds changes by the same amount
                // towards east and west.
                var latitudeDifference = MilesToLatitude(radiusMiles.Value);
                var longitudeNorthDifference = MilesToLongitude(
                    radiusMiles.Value,
                    bounds.north);
                var longitudeSouthDifference = MilesToLongitude(
                    radiusMiles.Value,
                    bounds.south);

                newBounds.north += latitudeDifference;
                newBounds.east += longitudeNorthDifference;
                newBounds.south -= latitudeDifference;
                newBounds.west -= longitudeSouthDifference;

                // Ensure the bounds are still within valid coordinates and wraps
                // the longitude. I hate longitudes.
                newBounds.north = MathHelper.Clamp(newBounds.north, -90, 90);
                newBounds.south = MathHelper.Clamp(newBounds.south, -90, 90);
                 
                newBounds.east = MathHelper.Wrap(newBounds.east, -180, 180);
                newBounds.west = MathHelper.Wrap(newBounds.west, -180, 180);
            }

            return newBounds;
        }

        private static double MilesToLongitude(float miles, double latitude)
        {
            var milesToLongitude = (miles / EarthRadiusInMiles) * (180 / Math.PI) / Math.Cos(latitude * Math.PI/180);

            return milesToLongitude;
        }

        private static double MilesToLatitude(float miles)
        {
            var milesToLatitude = (miles / EarthRadiusInMiles) * (180 / Math.PI);

            return milesToLatitude;
        }
    }
}