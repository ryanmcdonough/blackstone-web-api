﻿using System;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Savills.Core.Elastic.Elastic.Model;
using Umbraco.Web.WebApi;
using Savills.Core.Api.Repositories;
using Savills.Core.Api.ViewModels;
using Savills.Core.Helpers;

namespace Savills.Core.Api.Controllers
{
    public class BasketController : UmbracoApiController
    {
        private readonly BasketRepository _elasticRepo = new BasketRepository();

        [HttpPost, HttpOptions]
        public object Create(BasketItem request)
        {
            if (request == null)
            {
                return Request.CreateResponse<object>(HttpStatusCode.OK);
            }

            if (request.UserId == null)
            {
                request.UserId = BasketHelper.GetBasketUserId();
            }

            var response = _elasticRepo.AddBasketItem(request);
            var responseBasket = _elasticRepo.GetBasketItems(request.UserId);

            return Request.CreateResponse<object>(HttpStatusCode.OK, responseBasket);
        }

        [HttpDelete, HttpOptions]
        public object Delete(BasketItem request)
        {
            if (request == null)
            {
                return Request.CreateResponse<object>(HttpStatusCode.OK);
            }

            var response = _elasticRepo.RemoveBasketItem(request.Id);
            var responseBasket = _elasticRepo.GetBasketItems(request.UserId);

            return Request.CreateResponse<object>(HttpStatusCode.OK, responseBasket);
        }

        [HttpDelete, HttpOptions]
        public object DeleteAll(BasketItem request)
        {
            if (request == null)
            {
                return Request.CreateResponse<object>(HttpStatusCode.OK);
            }

            _elasticRepo.EmptyBasket(request.UserId);

            return Request.CreateResponse<object>(HttpStatusCode.OK);
        }

        [HttpGet, HttpOptions]
        public object Get()
        {
            var basketUser = HttpContext.Current.Request.QueryString["id"];

            if (!String.IsNullOrEmpty(basketUser))
            {
                var response = _elasticRepo.GetBasketItems(basketUser);

                return Request.CreateResponse<object>(HttpStatusCode.OK, response);
            }
            else
            {
                return Request.CreateResponse<object>(HttpStatusCode.BadRequest);
            }

         
        }

        [HttpPatch, HttpOptions]
        public object Patch([FromBody] Transfer transfer)
        {
            if (transfer == null)
            {
                return Request.CreateResponse<object>(HttpStatusCode.OK);
            }

            _elasticRepo.TransferBasketToMember(transfer.OldUserId, transfer.NewUserId);

            return Request.CreateResponse<object>(HttpStatusCode.OK);
        }



    }
}