﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using Savills.Core.Elastic.Elastic.Model;
using Savills.Core.Api.Models;
using Umbraco.Web.WebApi;
using Savills.Core.Api.Repositories;
using Savills.Core.Crm;
using Savills.Core.EmailModels;
using Savills.Core.Helpers;
using Umbraco.Web;

namespace Savills.Core.Api.Controllers
{
    public class EnquiryController : UmbracoApiController
    {
        private readonly BasketRepository _basketRepository = new BasketRepository();
        private readonly ElasticRepository _elasticRepository = new ElasticRepository();

        [HttpPost, HttpOptions]
        public async Task<object> Create(EnquiryRequest request)
        {
            var crm = new CrmService();

            if (request == null)
            {
                return Request.CreateResponse<object>(HttpStatusCode.OK);
            }

            var helper = new UmbracoHelper(UmbracoContext.Current);

            var mem = helper.MembershipHelper.GetCurrentMember();

            var enquiry = new Enquiry();

            if (mem == null)
            {

                    enquiry.Id = Guid.NewGuid();
                    enquiry.Basket = _basketRepository.GetBasketItems(request.BasketUserId);
                    enquiry.FirstName = request.FirstName;
                    enquiry.LastName = request.LastName;
                    enquiry.Company = request.Company ?? "";
                    enquiry.EMail = request.EMail;
                    enquiry.PhoneNumber = request.PhoneNumber;
                    enquiry.Message = request.Message;
                    enquiry.BasketUserId = request.BasketUserId;
                    enquiry.OnlyEnquireAbout = request.OnlyEnquireAbout;
                    enquiry.JustEnquire = request.JustEnquire;
            }
            else
            {
                    enquiry.Id = Guid.NewGuid();
                    enquiry.MemberId = helper.MembershipHelper.GetCurrentMemberId();
                    enquiry.FirstName = mem.GetPropertyValue<string>("firstName");
                    enquiry.LastName = mem.GetPropertyValue<string>("lastName");
                    enquiry.Company = mem.GetPropertyValue<string>("company") ?? "";
                    enquiry.EMail = mem.GetPropertyValue<string>("Email");
                    enquiry.PhoneNumber = mem.GetPropertyValue<string>("telphone");
                    enquiry.Basket = _basketRepository.GetBasketItems(request.BasketUserId);
                    enquiry.Message = request.Message;
                    enquiry.OnlyEnquireAbout = request.OnlyEnquireAbout;
                    enquiry.JustEnquire = request.JustEnquire;
            }

            //filter basket items if they're only interested in one thing
            if (!String.IsNullOrEmpty(enquiry.OnlyEnquireAbout))
            {
                enquiry.Basket = enquiry.Basket.Where(x => x.PropertyId == Convert.ToInt32(enquiry.OnlyEnquireAbout)).ToList();
            }

            //Send to CRM

            var test = AsyncHelpers.RunSync(() => crm.SendEnquiry(enquiry));

            //await Task.Run(() => crm.SendEnquiry(enquiry));

            //Send to DB

            var emailToSend = new EnquiryEmail();

            emailToSend.To = enquiry.EMail;
            emailToSend.ToName = enquiry.FirstName;
            emailToSend.LanguageCode = request.LanguageCode;
            emailToSend.From = "no-reply@sitemail.workthere.com";

            emailToSend.Enquiry = enquiry;
            emailToSend.Properties = new List<Property>();
            foreach (var item in enquiry.Basket)
            {
                var prop = _elasticRepository.GetPropertyById(item.PropertyId.ToString());
                emailToSend.Properties.Add(prop.Source);
            }

            emailToSend.Send();

            //Send to Savills (only until CRM is up and running)

            //var savillsEmail = new SavillsEnquiryEmail();

            //savillsEmail.To = ConfigurationManager.AppSettings["Savills.EnquiryTo"];
            //savillsEmail.ToName = "Workthere";
            //savillsEmail.LanguageCode = LanguageHelper.DefaultLanguage;
            //savillsEmail.From = "no-reply@sitemail.workthere.com";

            //savillsEmail.Enquiry = enquiry;
            //savillsEmail.Properties = emailToSend.Properties;

            //savillsEmail.Send();


            ElasticRepository repo = new ElasticRepository();

            repo.CreateEnquiry(enquiry);

            var response = new GuidResponse
            {
                Guid = enquiry.Id.ToString()
            };            

            return Request.CreateResponse<object>(HttpStatusCode.OK, response);
        }
    }
}