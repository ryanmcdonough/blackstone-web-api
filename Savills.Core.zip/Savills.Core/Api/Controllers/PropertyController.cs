﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Nest;
using Savills.Core.Api.Models.Property;
using Savills.Core.Api.Services;
using Umbraco.Web.WebApi;
using Savills.Core.Api.Repositories;
using Savills.Core.Elastic.Models;
using Savills.Core.Helpers;
using Savills.Core.Models;
using Savills.Core.Models.GoogleMaps.Geocoding;
using Umbraco.Core;
using SearchRequest = Savills.Core.Api.Models.Property.SearchRequest;

namespace Savills.Core.Api.Controllers
{
    using RollbarSharp;
    using Umbraco.Core.Models;
    using Property = Elastic.Elastic.Model.Property;
    using Result = Core.Models.GoogleMaps.Geocoding.Result;

    public sealed class PropertyController : UmbracoApiController
    {
        private readonly ElasticRepository _elasticRepo = new ElasticRepository();
        private readonly BasketRepository _basketRepo = new BasketRepository();
        private readonly PropertyService _propertyService = new PropertyService();

        [HttpGet, HttpOptions]
        public object Search()
        {
            var data = new PropertySearch
            {
                Latitude = !string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["lat"]) ? Convert.ToDouble(HttpContext.Current.Request.QueryString["lat"]) : 0,
                Longitude = !string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["lng"]) ? Convert.ToDouble(HttpContext.Current.Request.QueryString["lng"]) : 0,
                Distance = !string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["distance"]) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["distance"]) : 0,
                Area = !string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["area"]) ? HttpContext.Current.Request.QueryString["area"] : "",
            };

            //If distance, lat or lng is missing then throw an error.
            if (data.Latitude == 0 || data.Longitude == 0 || data.Distance == 0)
            {
                return Request.CreateResponse<object>(HttpStatusCode.BadRequest, "URL Parameters missing");
            }

            if (data.Area != "")
            {
                var geoResult = _elasticRepo.SearchAreaForProperties(data);

                return Request.CreateResponse<object>(HttpStatusCode.OK, geoResult.Documents);
            }
            else
            {
                var geoResult = _elasticRepo.SearchProperties(data);

                return Request.CreateResponse<object>(HttpStatusCode.OK, geoResult.Documents);
            }
        }

        [HttpGet, HttpOptions]
        public object Random()
        {
            double amount = !string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["amount"])? Convert.ToDouble(HttpContext.Current.Request.QueryString["amount"]): 4;

            var data = new PropertySearch
            {
                Area = !string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["area"]) ? HttpContext.Current.Request.QueryString["area"] : "",
            };

            //If distance, lat or lng is missing then throw an error.
            if (data.Area != "")
            {
                var geoResulty = _elasticRepo.SearchAreaForPropertiesRandom(data,Convert.ToInt32(amount));
                return Request.CreateResponse<object>(HttpStatusCode.OK, geoResulty.Documents);
            }
            else
            {
                var geoResult = _elasticRepo.RandomProperties(amount);
                return Request.CreateResponse<object>(HttpStatusCode.OK, geoResult.Documents);
            }
        }

        [MemberAuthorize]
        public object List()
        {
            var propertyId = HttpContext.Current.Request.QueryString["id"];

            //If distance, lat or lng is missing then throw an error.
            if (propertyId == "")
            {
                return Request.CreateResponse<object>(HttpStatusCode.BadRequest, "URL Parameters missing");
            }

            var response = _elasticRepo.GetPropertyById(propertyId);

            return Request.CreateResponse<object>(HttpStatusCode.OK, response.Source);
        }


        [HttpGet, HttpOptions]
        public object Single()
        {
            var propertyId = HttpContext.Current.Request.QueryString["id"];

            //If distance, lat or lng is missing then throw an error.
            if (propertyId == "")
            {
                return Request.CreateResponse<object>(HttpStatusCode.BadRequest, "URL Parameters missing");
            }

            var response = _elasticRepo.GetPropertyById(propertyId);

            return Request.CreateResponse<object>(HttpStatusCode.OK, response.Source);
        }

        [HttpGet, HttpOptions]
        public object Multiple()
        {
            var propertyIds = HttpContext.Current.Request.QueryString["id"].Split(',');

            var response = _elasticRepo.GetPropertiesById(propertyIds);

            return Request.CreateResponse<object>(HttpStatusCode.OK, response.Documents);
        }

        [HttpGet, HttpOptions]
        public object SearchGeoArea()
        {
            var data = new PropertySearch
            {
                Area = !string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["area"])
                ? HttpContext.Current.Request.QueryString["area"]
                : "",
            };

            //If distance, lat or lng is missing then throw an error.
            if (data.Area == "")
            {
                return Request.CreateResponse<object>(HttpStatusCode.BadRequest, "URL Parameters missing");
            }

            var geoResult = _elasticRepo.SearchAreaForProperties(data);

            return Request.CreateResponse<object>(HttpStatusCode.OK, geoResult.Documents);
        }

        [HttpGet, HttpOptions]
        [MemberAuthorize]
        public object Member()
        {
            var currentMember = Members.GetCurrentMember();

            var geoResult = _elasticRepo.GetMemberProperties(currentMember);

            return Request.CreateResponse<object>(HttpStatusCode.OK, geoResult.Documents);
        }

        [HttpPost, HttpOptions]
        [MemberAuthorize]
        public object Unlist([FromUri] int id)
        {
            var currentMember = Members.GetCurrentMember();

            var geoResult = _propertyService.UnlistProperty(id,currentMember);

            return Request.CreateResponse<object>(HttpStatusCode.OK);
        }

        [HttpPost, HttpOptions]
        [MemberAuthorize]
        public object Relist([FromUri] int id)
        {
            var currentMember = Members.GetCurrentMember();

            var geoResult = _propertyService.RelistProperty(id, currentMember);

            return Request.CreateResponse<object>(HttpStatusCode.OK);
        }

        [HttpGet, HttpOptions]
        public object MapEverything()
        {
            _elasticRepo.GeoMapping();
            _elasticRepo.AlertMapping();
            _elasticRepo.PropertyMapping();
            _elasticRepo.PropertyMappingAll();
            _elasticRepo.EnquiryMapping();
            _basketRepo.TestMapping();

            return Request.CreateResponse<object>(HttpStatusCode.OK);
        }

        /// <summary>
        /// Search Properties with a Google Maps geocoding result.
        /// If no radius is passed (null) in the searchRequest we'll try to get
        /// a radius from Umbraco. A radius will be then passed back in the response
        /// (this is to pre-select a potential dropdown in the frontend).
        /// </summary>
        /// <param name="searchRequest">A Google Map API Geocoding result wrapped with a radius (which can be null if not specified).</param>
        /// <returns>Proprieties and a radius.</returns>
        /// <example>
        /// curl --request POST --url http://localhost:60098/umbraco/api/property/search --header 'cache-control: no-cache' --header 'content-type: application/json' --data '{"Radius":10,"GoogleMapsGeocodingResult":{"address_components":[{"long_name":"London","short_name":"London","types":["locality","political"]},{"long_name":"London","short_name":"London","types":["postal_town"]},{"long_name":"Greater London","short_name":"Greater London","types":["administrative_area_level_2","political"]},{"long_name":"England","short_name":"England","types":["administrative_area_level_1","political"]},{"long_name":"United Kingdom","short_name":"GB","types":["country","political"]}],"formatted_address":"London, UK","geometry":{"bounds":{"south":51.38494009999999,"west":-0.351468299999965,"north":51.6723432,"east":0.14827100000002247},"location":{"lat":51.5073509,"lng":-0.12775829999998223},"location_type":"APPROXIMATE","viewport":{"south":51.38494009999999,"west":-0.351468299999965,"north":51.6723432,"east":0.1482319000000416}},"place_id":"ChIJdd4hrwug2EcRmSrV3Vo6llI","types":["locality","political"]}}'
        /// </example>
        [HttpPost]
        [HttpOptions]
        public HttpResponseMessage Search(SearchRequest searchRequest)
        {
            if (searchRequest?.GoogleMapsGeocodingResult == null)
            {
                const string errorMessage = "Invalid Request";
                return Request.CreateValidationErrorResponse(errorMessage);
            }

            var geoShapeIds = GetGeoShapeIdsForGoogleMapsPlaceId(searchRequest.GoogleMapsGeocodingResult.place_id);
            SearchResult searchResult;

            // If one of more PagePlace was found and radius is not specified,
            // search by geoshape(s) on the PagePlace(s)
            if (geoShapeIds != null
                && geoShapeIds.Any()
                && searchRequest.Radius == null)
            {
                var properties = SearchByGoogleMapsPlaceId(geoShapeIds);
                var geoJsonAreas = _elasticRepo.GetGeoJsonAreas(geoShapeIds);
                var areasCoordinates = geoJsonAreas
                    .Select(gja => gja.Source)
                    .Select(gja => gja.Coordinates)
                    .ToList();

                searchResult = new SearchResult
                {
                    Results = properties,
                    // In searches by geoshape the radius is unset.
                    Radius = null,
                    PropertySearchType = new GeoShapeSearchType(areasCoordinates),
                };
            }
            // Search within the bounds.
            else
            {
                var placeTypes = searchRequest.GoogleMapsGeocodingResult.types;
                // Order types by most precise, inverse of Google's default.
                placeTypes.Reverse();
                var radius = searchRequest.Radius
                    ?? GetDefaultSearchRadiusForPlaceTypes(placeTypes)
                    ?? 0;
                Result searchRequestGoogleMapsGeocodingResult = searchRequest.GoogleMapsGeocodingResult;
                var geometryBounds = GetBoundsOrFallback(searchRequestGoogleMapsGeocodingResult.geometry);
                var bounds = TopologyHelper.IncreaseBoundByRadius(
                        geometryBounds,
                        radius);
                var geoResultProperties = _elasticRepo.SearchBoundsForProperties(
                    bounds.north,
                    bounds.east,
                    bounds.south,
                    bounds.west);

                searchResult = new SearchResult
                {
                    Results = geoResultProperties.Documents,
                    Radius = radius,
                    PropertySearchType = new BoundsSearchType(bounds),
                };
            }

            return Request.CreateResponse(searchResult);
        }

        /// <param name="geometry">
        /// A geometry object as present in a Google Places Geocoding response
        /// </param>
        /// <returns>
        /// The bounds, or fall back to the viewport or make up a new bound from the geolocation.
        /// </returns>
        private static GeoRectangle GetBoundsOrFallback(Geometry geometry)
        {
            var bounds = geometry.bounds
                ?? geometry.viewport
                ?? new GeoRectangle
                {
                    north = geometry.location.lat,
                    east = geometry.location.lng,
                    south = geometry.location.lat,
                    west = geometry.location.lng,
                };

            return bounds;
        }

        /// <summary>
        /// Returns the first, if any, default radius for these placeTypes.
        /// </summary>
        private static float? GetDefaultSearchRadiusForPlaceTypes(IEnumerable<string> placeTypes)
        {
            var placeTypeDefaultRadiuses = SearchDefaultRadiusCacheHelper.Instance.PlaceTypeDefaultRadiuses;
            var defaultRadius = placeTypes?
                .Select(pt => placeTypeDefaultRadiuses
                        .FirstOrDefault(x => x.Key.InvariantEquals(pt)))
                .FirstOrDefault(r => r.Value != null);

            return defaultRadius?.Value;
        }

        private IEnumerable<Property> SearchByGoogleMapsPlaceId(IEnumerable<string> geoPlaceIds)
        {
            var propertySearches = geoPlaceIds
                .Select(g => new PropertySearch {Area = g})
                .ToArray();

            var searchResponses = _elasticRepo.SearchAreasForProperties(propertySearches);

            return searchResponses.Documents;
        }

        /// <param name="googleMapsPlaceId">
        ///     The Place ID from the Google Maps search.
        ///     Ref. https://developers.google.com/places/place-id
        /// </param>
        private static List<string> GetGeoShapeIdsForGoogleMapsPlaceId(string googleMapsPlaceId)
        {
            var pagePlacesForPlaceId = PlaceIdCacheHelper.Instance
                .GeoShapeIdToPlaceId
                .Where(d => d.Value.Contains(googleMapsPlaceId))
                .Select(d => d.Key)
                .ToList();

            return pagePlacesForPlaceId;
        }

    }
}