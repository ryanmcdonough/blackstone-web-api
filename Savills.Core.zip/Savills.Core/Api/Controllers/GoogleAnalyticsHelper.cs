﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Google.Apis.Analytics.v3;
using Google.Apis.Analytics.v3.Data;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Savills.Core.Properties;

namespace Savills.Core.Api.Controllers
{
    public static class GoogleAnalyticsHelper
    {
        private const string DateTimeFormat = "yyyy-MM-dd";

        private static readonly string ViewId = ConfigurationManager.AppSettings["Savills.Google.Analytics.ViewId"];

        private static readonly AnalyticsService AnalyticsService;

        static GoogleAnalyticsHelper()
        {
            var googleAnalyticsCert = Resources.GoogleAnalyticsCert;
            var emailAddress =
                ConfigurationManager.AppSettings["Savills.Google.Analytics.EmailAddress"];
            var certificate =
                new X509Certificate2(googleAnalyticsCert, "notasecret", X509KeyStorageFlags.Exportable);

            var credential = new ServiceAccountCredential(
                new ServiceAccountCredential.Initializer(emailAddress)
                {
                    Scopes = new[] {AnalyticsService.Scope.Analytics}
                }.FromCertificate(certificate));

            AnalyticsService = new AnalyticsService(new BaseClientService.Initializer
            {
                HttpClientInitializer = credential,
                ApplicationName = "Savills"
            });
        }

        public static Task<GaData> GaData(DateTime startDate, DateTime endDate, string filters, string dimensions,
            string metrics)
        {
            var request = AnalyticsService.Data.Ga.Get($"ga:{ViewId}", startDate.ToString(DateTimeFormat),
                endDate.ToString(DateTimeFormat), metrics);

            request.Dimensions = dimensions;
            request.Filters = filters;

            var data = request.ExecuteAsync();

            return data;
        }

        /// <summary>
        /// Gets the all time users for the <param name="pageUrls">page URLs</param>.
        /// </summary>
        /// <param name="pageUrls">Relative path.</param>
        /// <returns>Google Analytics Data.</returns>
        public static async Task<GaData> GetPagesUsers(IEnumerable<string> pageUrls)
        {
            var pageFiltes = string.Join(",", pageUrls.Select(p => "ga:pagePath==" + p));

            // G Analytics min date time is 2005 (launch date)
            return await GaData(new DateTime(2005, 1, 1), DateTime.Now, pageFiltes, "ga:pagePath", "ga:users");
        }


        /// <summary>
        /// Gets the users for the <param name="pageUrls">page URLs</param>.
        /// </summary>
        /// <param name="pageUrls">Relative path.</param>
        /// <returns>Google Analytics Data.</returns>
        public static async Task<GaData> GetPagesUsers(IEnumerable<string> pageUrls, DateTime startDate, DateTime endDate)
        {
            var pageFiltes = string.Join(",", pageUrls.Select(p => "ga:pagePath==" + p));

            return await GaData(startDate, endDate, pageFiltes, "ga:pagePath", "ga:users");
        }
    }
}