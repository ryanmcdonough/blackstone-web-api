﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Mvc;
using Savills.Core.Api.Repositories;
using Savills.Core.Extensions;
using Savills.Core.Helpers;
using Umbraco.Web.WebApi;

namespace Savills.Core.Api.Controllers
{
    public class GoogleAnalyticsController : UmbracoApiController
    {
        private const string GaUsers = "ga:users";
        private readonly ElasticRepository _elasticRepo = new ElasticRepository();

        [MemberAuthorize]
        [HttpGet]
        public async Task<object> GetMemberSpacesUsersView(DateTime startDate, DateTime endDate)
        {
  
            var spaceIdNameRelativeLinks = GetCurrentMemberSpacesIdNameRelativeLinks();
            var spaceIdNameUserViews = new List<SpaceIdNameUserViews>();

            foreach (var spaceIdNameRelativeLink in spaceIdNameRelativeLinks)
            {
                var allSpaceUrls = LanguageHelper.GetAllAllowedLanguagesUrl(spaceIdNameRelativeLink.RelativeLink);
                var data = await GoogleAnalyticsHelper.GetPagesUsers(allSpaceUrls, startDate, endDate);

                var userViewsString = data.TotalsForAllResults.ContainsKey(GaUsers)
                    ? data.TotalsForAllResults[GaUsers]
                    : null;
                uint userViews;
                uint.TryParse(userViewsString, out userViews);

                spaceIdNameUserViews.Add(new SpaceIdNameUserViews()
                {
                    Id = spaceIdNameRelativeLink.Id,
                    Name = spaceIdNameRelativeLink.Name,
                    UserViews = userViews
                });
            }
            
            return Request.CreateResponse<object>(HttpStatusCode.OK, spaceIdNameUserViews);
        }

        [MemberAuthorize]
        [HttpGet]
        public async Task<object> GetSpaceUsersView(int spaceId, DateTime startDate, DateTime endDate)
        {
            var currentMember = Members.GetCurrentMember();
            var defaultLanguage = LanguageHelper.DefaultLanguage;

            if (!currentMember.CanManageProperty(spaceId))
            {
                return Request.CreateUserNoAccessResponse();
            }

            var property = _elasticRepo.GetPropertyById(spaceId.ToString());
            var allSpaceUrls = LanguageHelper.GetAllAllowedLanguagesUrl(property.Source.RelativeLink);
            var data = await GoogleAnalyticsHelper.GetPagesUsers(allSpaceUrls, startDate, endDate);

            var userViewsString = data.TotalsForAllResults.ContainsKey(GaUsers)
                ? data.TotalsForAllResults[GaUsers]
                : null;
            uint userViews;
            uint.TryParse(userViewsString, out userViews);

            var spaceIdNameUserViews = new SpaceIdNameUserViews()
            {
                Id = property.Source.Id,
                Name = property.Source.Name.FirstOrDefault(
                    n => n.LanguageCode.Equals(defaultLanguage, StringComparison.OrdinalIgnoreCase))?.Content,
                UserViews = userViews
            };
            
            return Request.CreateResponse<object>(HttpStatusCode.OK, spaceIdNameUserViews);
        }

        private IEnumerable<SpaceIdNameRelativeLink> GetCurrentMemberSpacesIdNameRelativeLinks()
        {
            var defaultLanguage = LanguageHelper.DefaultLanguage;

            var currentMember = Members.GetCurrentMember();

            var memberProperties = _elasticRepo.GetMemberProperties(currentMember);

            var spaces = memberProperties
                .Documents
                .Select(s => new SpaceIdNameRelativeLink()
                {
                    Id = s.Id,
                    Name = s.Name.FirstOrDefault(
                        n => n.LanguageCode.Equals(defaultLanguage, StringComparison.OrdinalIgnoreCase))?.Content,
                    RelativeLink = s.RelativeLink
                });

            return spaces;
        }

        private class SpaceIdName
        {
            public int Id { get; set; }
            public string Name { get; set; }
        }

        private class SpaceIdNameRelativeLink : SpaceIdName
        {
            public string RelativeLink { get; set; }
        }

        private class SpaceIdNameUserViews : SpaceIdName
        {
            public uint UserViews { get; set; }
        }
    }
}