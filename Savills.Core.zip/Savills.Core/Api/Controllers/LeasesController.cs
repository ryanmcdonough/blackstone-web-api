﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using Savills.Core.DataModels;
using Savills.Core.Api.Services;
using Umbraco.Web.WebApi;

namespace Savills.Core.Api.Controllers
{
    public class LeasesController : UmbracoApiController
    {
        private readonly LeaseService _leaseService = new LeaseService();

        [HttpPost, HttpOptions]
        public object Create(LeaseInfo request)
        {
            if (request == null)
            {
                return Request.CreateResponse<object>(HttpStatusCode.OK);
            }

            var response = _leaseService.Insert(request);

            return Request.CreateResponse<object>(HttpStatusCode.OK, response);
        }

        [HttpGet, HttpOptions]
        [MemberAuthorize]
        public object Member()
        {
            var currentMember = Members.GetCurrentMember();

            var geoResult = _leaseService.LeasesForMember(currentMember.Id);

            return Request.CreateResponse<object>(HttpStatusCode.OK, geoResult);
        }


    }
}