﻿using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using Savills.Core.Helpers;
using Savills.Core.Models;
using Umbraco.Web.WebApi;

namespace Savills.Core.Api.Controllers
{
    public class LanguageController : UmbracoApiController
    {
        /// <summary>
        /// Sets the language cookie so we know that we don't have to check for langugae mismatches any more
        /// </summary>
        [System.Web.Mvc.AcceptVerbs(HttpVerbs.Get|HttpVerbs.Post)]
        [System.Web.Http.HttpGet]
        [System.Web.Http.HttpPost]
        public bool SetLanguage()
        {
            LanguageHelper.SetLanguageCheckCookie();

            return true;
        }

        /// <summary>
        /// Sets the currency the user wants to use
        /// </summary>
        /// <param name="currency"></param>
        /// <returns></returns>
        [System.Web.Mvc.AcceptVerbs(HttpVerbs.Get | HttpVerbs.Post | HttpVerbs.Options)]
        [System.Web.Http.HttpGet]
        [System.Web.Http.HttpPost]
        [System.Web.Http.HttpOptions]
        public bool SetCurrency([FromBody] CurrencyItem currency)
        {
            if (currency == null)
            {
                return true;   
            }

            CurrencyHelper.SetCurrencyCookie(currency.Currency);

            return true;
        }

        [System.Web.Mvc.AcceptVerbs(HttpVerbs.Get | HttpVerbs.Post | HttpVerbs.Options)]
        [System.Web.Http.HttpGet]
        [System.Web.Http.HttpPost]
        [System.Web.Http.HttpOptions]
        public void SetLanguageAndCurrency([FromBody] CurrencyItem currency)
        {
            LanguageHelper.SetLanguageCheckCookie();
            if(currency.Currency != null)
                CurrencyHelper.SetCurrencyCookie(currency.Currency);
        }

        private void SetCurrencyCookie(string currency)
        {
            UmbracoContext.HttpContext.Response.Cookies.Add(new HttpCookie(CurrencyHelper.CurrencyCookieKey, currency));
        }

        private void SetLanguageCheckCookie()
        {
            UmbracoContext.HttpContext.Response.Cookies.Add(new HttpCookie(LanguageHelper.LanguageCookieKey, "1"));
        }
    }
}
