﻿using System;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Nest;
using Savills.Core.Elastic.Elastic.Model;
using Umbraco.Web.WebApi;
using Savills.Core.Api.Repositories;
using Savills.Core.Elastic.Models;

namespace Savills.Core.Api.Controllers
{
    public sealed class TransportController : UmbracoApiController
    {
        private readonly ElasticRepository _elasticRepo = new ElasticRepository();

        [HttpGet, HttpOptions]
        public object Search()
        {
            var data = new TransportSearch()
            {
                Latitude = !string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["lat"]) ? Convert.ToDouble(HttpContext.Current.Request.QueryString["lat"]) : 0,
                Longitude = !string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["lng"]) ? Convert.ToDouble(HttpContext.Current.Request.QueryString["lng"]) : 0,
                Distance = !string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["distance"]) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["distance"]) : 0,
            };

            //If distance, lat or lng is missing then throw an error.
            if (data.Latitude == 0 || data.Longitude == 0 || data.Distance == 0)
            {
                return Request.CreateResponse<object>(HttpStatusCode.BadRequest, "URL Parameters missing");
            }

            var geoResult = _elasticRepo.SearchTransport(data);

            return Request.CreateResponse<object>(HttpStatusCode.OK, geoResult.Documents);
        }

        [HttpGet, HttpOptions]
        public object Nearest()
        {
            var data = new TransportSearch()
            {
                Latitude = !string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["lat"]) ? Convert.ToDouble(HttpContext.Current.Request.QueryString["lat"]) : 0,
                Longitude = !string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["lng"]) ? Convert.ToDouble(HttpContext.Current.Request.QueryString["lng"]) : 0,
                Distance = !string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["distance"]) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["distance"]) : 0,
                Types = new [] { "RLY", "MET" }
            };

            //If distance, lat or lng is missing then throw an error.
            if (data.Latitude == 0 || data.Longitude == 0 || data.Distance == 0)
            {
                return Request.CreateResponse<object>(HttpStatusCode.BadRequest, "URL Parameters missing");
            }

            var item = _elasticRepo.SearchNearestTransport(data);

            item.Distance = Calculator.Distance.CalculateDistance(item.GeoLocation.Latitude, item.GeoLocation.Longitude, data.Latitude,
                data.Longitude, 'K');

            return Request.CreateResponse<object>(HttpStatusCode.OK, item);
        }

        [HttpGet, HttpOptions]
        public object Map()
        {
            var descriptor = new CreateIndexDescriptor("transport")
            .Mappings(ms => ms
                .Map<Property>(m => m.AutoMap())
            );

            return Request.CreateResponse<object>(HttpStatusCode.OK, "Transport Mapped");
        }
    }
}