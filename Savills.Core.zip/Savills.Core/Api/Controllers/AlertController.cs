﻿using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Mvc;
using Nest;
using Savills.Core.Elastic.Elastic.Model;
using Savills.Core.Api.Models;
using Umbraco.Web.WebApi;
using Savills.Core.Api.Repositories;
using Savills.Core.Crm;

namespace Savills.Core.Api.Controllers
{
    public class AlertController : UmbracoApiController
    {
        private readonly ElasticRepository _elasticRepo = new ElasticRepository();

        private readonly CrmService _crm = new CrmService();

        [HttpPost, HttpOptions]
        [MemberAuthorize]
        public async Task<object> Create(AlertRequest request)
        {
            if (request == null)
            {
                return Request.CreateResponse<object>(HttpStatusCode.OK);
            }

            var member = Members.GetCurrentMember();

            var alert = new Alert
            {
                Id = Guid.NewGuid(),
                MemberId = member.Id,
                Description = request.Description,
                Distance = request.Distance,
                GeoLocation = new PointGeoShape(new GeoCoordinate(request.Latitude, request.Longitude)),
            };

            var response = _elasticRepo.CreateAlert(alert);

            if (response.Result == Result.Updated)
            {

            }
            else
            {
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                Task.Run(() => _crm.AlertCreation(alert));
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
            }

            

            return Request.CreateResponse<object>(HttpStatusCode.OK, response.ShardsHit);
        }

        [HttpDelete, HttpOptions]

        public async Task<object> Delete(AlertRequest request)
        {
            if (request == null)
            {
                return Request.CreateResponse<object>(HttpStatusCode.OK);
            }

            var alert = new Alert
            {
                Id = request.Id
            };

#pragma warning disable 4014
            Task.Run(() => _crm.AlertDeletion(alert));
#pragma warning restore 4014

            var response = _elasticRepo.DeleteAlert(alert);

            return Request.CreateResponse<object>(HttpStatusCode.OK, response.Found);
        }

        [HttpGet, HttpOptions]
        public object Get()
        {
            var response = _elasticRepo.GetAlerts();

            return Request.CreateResponse<object>(HttpStatusCode.OK, response.Documents);

        }

    }
}