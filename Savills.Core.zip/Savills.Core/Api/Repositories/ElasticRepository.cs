﻿using Nest;
using Savills.Core.Api.Services;
using Savills.Core.Elastic.Elastic.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using GeoJSON.Net.Feature;
using Newtonsoft.Json;
using Savills.Core.Api.Models;
using Savills.Core.Elastic.Elastic.Client.Settings;
using Savills.Core.Elastic.Models;
using Umbraco.Core;
using Umbraco.Core.Models;
using Property = Savills.Core.Elastic.Elastic.Model.Property;

namespace Savills.Core.Api.Repositories
{
    public class ElasticRepository
    {
        private readonly ElasticService _service = new ElasticService();

        #region Alerts

        public IUpdateResponse<Alert> CreateAlert(Alert alert)
        {
            var client = _service.NewClient("alert");

            client.Map<Alert>(m => m.Index("alert"));

            var response = client.Update(DocumentPath<Alert>
                  .Id(alert.Id),
                  u => u.Doc(alert).DocAsUpsert());

            return response;
        }


        


        public IDeleteResponse DeleteAlert(Alert alert)
        {
            var client = _service.NewClient("alert");

            var response = client.Delete(DocumentPath<Alert>
                  .Id(alert.Id));

            return response;
        }

        public IGetResponse<Alert> GetAlert(Guid id)
        {
            var client = _service.NewClient("alert");

            var response = client.Get(DocumentPath<Alert>
                  .Id(id));

            return response;
        }

        public ISearchResponse<Alert> GetAlerts()
        {
            var client = _service.NewClient("alert");

            var response = client.Search<Alert>(s => s.From(0).Size(10000));

            return response;
        }

        public ISearchResponse<Alert> GetAlerts(int memberId)
        {
            var client = _service.NewClient("alert");


            var response = client.Search<Alert>(s => s
                .Query(q => q
                    .Bool(b => b
                        .Must(
                            bs => bs.Term(p => p.MemberId, memberId)
                        )
                    )
                )
            );

            return response;
        }

        public void EnquiryMapping()
        {
            var node = new Uri(System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Location"]);

            var settings = new ConnectionSettings(node);
            settings.DisableDirectStreaming();
            settings.BasicAuthentication(System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Username"], System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Password"]);

            var client = new Elastic.Elastic.Client.ElasticSearchClient<Enquiry>(new ConnectionString("http",System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Location.Ip"], 9200), "enquiries");

            client.CreateIndex();
        }

        public void AlertMapping()
        {
            var node = new Uri(System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Location"]);

            var settings = new ConnectionSettings(node);
            settings.DisableDirectStreaming();
            settings.BasicAuthentication(System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Username"], System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Password"]);

            var client = new Elastic.Elastic.Client.ElasticSearchClient<Alert>(new ConnectionString("http", System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Location.Ip"], 9200), "alert");

            client.CreateIndex();
        }

        #endregion

        #region Properties

        public void PropertyMapping()
        {
            var node = new Uri(System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Location"]);

            var settings = new ConnectionSettings(node);
            settings.DisableDirectStreaming();
            settings.BasicAuthentication(System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Username"], System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Password"]);

            var client = new Elastic.Elastic.Client.ElasticSearchClient<Property>(new ConnectionString("http", System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Location.Ip"], 9200), "buildings");

            client.CreateIndex();
        }

        public void PropertyMappingAll()
        {
            var node = new Uri(System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Location"]);

            var settings = new ConnectionSettings(node);
            settings.DisableDirectStreaming();
            settings.BasicAuthentication(System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Username"], System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Password"]);

            var client = new Elastic.Elastic.Client.ElasticSearchClient<Property>(new ConnectionString("http", System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Location.Ip"], 9200), "buildings-all");

            client.CreateIndex();
        }

        public ISearchResponse<Property> SearchProperties(PropertySearch data)
        {
            var client = _service.NewClient("buildings");

            var geoResult = client.Search<Property>(s => s.From(0).Size(10000)
                .Query(query => query
                    .Bool(b => b.Filter(filter => filter
                       .GeoShapeCircle(geo => geo
                           .Field(f => f.GeoLocation)
                           .Radius(data.Distance + "km")
                           .Coordinates(new GeoCoordinate(data.Latitude, data.Longitude)))
                    ))
                )
            );

            return geoResult;
        }

        public ISearchResponse<Property> RandomProperties(double amount)
        {
            var client = _service.NewClient("buildings");

            var geoResult =
                client.Search<Property>(
                    s =>
                        s.From(0)
                            .Size(Convert.ToInt32(amount))
                            .Query(
                                q =>
                                    q.FunctionScore(
                                        fs =>
                                            fs.Query(fq => fq.MatchAll())
                                                .Functions(
                                                    f => f.RandomScore(Guid.NewGuid().ToString())))));

            return geoResult;
        }

        public IGetResponse<Property> GetPropertyById(string propertyId)
        {
            var client = _service.NewClient("buildings");

            var response = client.Get(DocumentPath<Property>
                   .Id(propertyId));

            return response;
        }

        public IMultiGetResponse GetPropertiesById(string[] propertyIds)
        {
            var client = _service.NewClient("buildings");

            var response = client.MultiGet(m => m.GetMany<Property>(propertyIds));

            return response;
        }

        public ISearchResponse<Property> GetMemberProperties(IPublishedContent member)
        {
            var client = _service.NewClient("buildings-all");

            var memberDetails = ApplicationContext.Current.Services.MemberService.GetById(member.Id);
            var providerId = memberDetails.GetValue("providerID");
           
            var rawJson = " {\"bool\": {\"must\": [{\"nested\": {\"path\": \"provider\", \"query\": {\"bool\": {\"must\": [ {\"match\": {\"provider.id\": \"" + providerId + "\"}}]}}}}]}}";

            var response = client.Search<Property>(s => s.From(0).Size(10000)
                .Query(query => query
                    .Raw(rawJson)
                    )
            );

            return response;
        }

        public ISearchResponse<Property> SearchAreasForProperties(PropertySearch[] propertySearches)
        {
            var client = _service.NewClient("buildings");

            var funcs = propertySearches
                .Select(ps => new Func<QueryContainerDescriptor<Property>, QueryContainer>(qcd => qcd
                    .GeoIndexedShape(
                        gis => gis.Field(x => x.GeoLocation)
                        .IndexedShape(
                            @is => @is.Id(ps.Area)
                                .Index("location")
                                .Path("coordinates")
                                .Type("area")))));

            var geoResult = client.Search<Property>(search =>
                search
                .From(0)
                .Size(5000)
                .Query(query => query
                    .Bool(@bool=> @bool
                        .Should(funcs))));

            return geoResult;
        }

        public ISearchResponse<Property> SearchAreaForProperties(PropertySearch propertySearch)
        {
            var client = _service.NewClient("buildings");

            var geoResult = client.Search<Property>(s =>
                s
                .From(0)
                .Size(5000)
                .Query(query =>
                    query.Bool(b =>
                        b.Filter(f =>
                            f.GeoIndexedShape(gis => gis
                                .Field(x => x.GeoLocation)
                                .IndexedShape(
                                    @is => @is.Id(propertySearch.Area)
                                        .Index("location")
                                        .Path("coordinates")
                                        .Type("area")))))));
            return geoResult;
        }

        public ISearchResponse<Property> SearchAreaForPropertiesRandom(PropertySearch data, int amount)
        {
            var client = _service.NewClient("buildings");

            var rawJson = "{  \"bool\":{\"filter\":{\"geo_shape\":{\"geoLocation\":{\"indexed_shape\":{\"id\":\"" + data.Area + "\",\"type\":\"area\",\"index\":\"location\",\"path\":\"coordinates\"}}}}}}";

            var geoResult = client.Search<Property>(s => s.From(0).Size(amount)
                .Query(query => query
                    .Raw(rawJson)
                    )
            );

            return geoResult;
        }

        public void UpdatePropertyReviewScore(int propertyId, double reviewScore)
        {
            var result = GetPropertyById(propertyId.ToString());

            if (result.Found)
            {
                var property = result.Source;

                property.Rating = reviewScore;

                UpdateProperty(property);
            }
        }

        public void UpdateProperty(Property property)
        {
            var client = _service.NewClient("buildings");

            client.Update(DocumentPath<Property>
                  .Id(property.Id),
                  u => u.Doc(property).DocAsUpsert());
        }


        public IUpdateResponse<Enquiry> CreateEnquiry(Enquiry alert)
        {
            var client = _service.NewClient("enquiries");

            client.Map<Enquiry>(m => m.Index("enquiries"));

            var response = client.Update(DocumentPath<Enquiry>
                  .Id(alert.Id),
                  u => u.Doc(alert).DocAsUpsert());

            return response;
        }

        public IGetResponse<Enquiry> GetEnquiry(string id)
        {
            var client = _service.NewClient("enquiries");

            client.Map<Enquiry>(m => m.Index("enquiries"));

            var response = client.Get(DocumentPath<Enquiry>
                  .Id(id));

            return response;
        }

        public ISearchResponse<Property> SearchBoundsForProperties(
            double northLat,
            double eastLng,
            double southLat,
            double westLng)
        {
            var client = _service.NewClient("buildings");

            var envelopGeoCoordinates = new List<GeoCoordinate>{
                new GeoCoordinate(northLat, westLng),
                new GeoCoordinate(southLat, eastLng),
            };
            var geoResult = client.Search<Property>(s => s
                .From(0)
                .Size(5000)
                .Query(query => query
                    .Bool(b => b
                        .Filter(f =>f
                            .GeoShapeEnvelope(gse => gse
                                .Coordinates(envelopGeoCoordinates)
                                .Relation(GeoShapeRelation.Within)
                                .Field(p => p.GeoLocation))))));

            return geoResult;
        }

        #endregion

        #region Transport

        public ISearchResponse<Transport> SearchTransport(TransportSearch data)
        {
            var client = _service.NewClient("transport");

            var geoResult = client.Search<Transport>(s => s.From(0).Size(10000)
                    .Query(query => query
                            .Bool(b => b.Filter(filter => filter
                                .GeoDistance(geo => geo
                                    .Field(f => f.GeoLocation)
                                    .Distance(data.Distance, DistanceUnit.Kilometers)
                                    .Location(data.Latitude, data.Longitude)))
                            )

                    )
                    .Sort(sort => sort
                        .GeoDistance(g => g
                            .Field(f => f.GeoLocation)
                            .Order(SortOrder.Ascending)
                            .PinTo(new GeoLocation(data.Latitude, data.Longitude))
                            .DistanceType(GeoDistanceType.SloppyArc)))
            );

            return geoResult;
        }

        public Transport SearchNearestTransport(TransportSearch data)
        {
            var client = _service.NewClient("transport");

            var geoResult = client.Search<Transport>(s => s
                .Query(query => query
                    .Bool(@bool =>
                            {
                                data.Types
                                    .ForEach(t => @bool
                                        .Should(should => should
                                            .Match(match => match
                                                .Field(x => x.Type)
                                                    .Query(t))));
                                return @bool;
                            })
                )
                .Sort(sort => sort
                    .GeoDistance(g => g
                        .Field(f => f.GeoLocation)
                        .Order(SortOrder.Ascending)
                        .PinTo(new GeoLocation(data.Latitude, data.Longitude))
                        .DistanceType(GeoDistanceType.SloppyArc)))
                .Size(1)
           );

            return geoResult.Documents.FirstOrDefault();
        }

        #endregion

        #region Area

        public string AddGeoArea(string geoJson, string currentGuid, string name)
        {
            var client = _service.NewClient("location");

            var featureCollection = JsonConvert.DeserializeObject<FeatureCollection>(geoJson);

            if (currentGuid.IsNullOrWhiteSpace())
            {
                currentGuid = Guid.NewGuid().ToString();
            }
            

            foreach (var feature in featureCollection.Features)
            {
                var suburb = new Area
                {
                    Coordinates = feature.Geometry,
                    Name = name,
                };


                var response = client.Update(DocumentPath<Area>
                   .Id(currentGuid),
                   u => u.Doc(suburb).DocAsUpsert());
            }

            return currentGuid;
        }

        public void GeoMapping()
        {
            var node = new Uri(System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Location"]);

            var settings = new ConnectionSettings(node);
            settings.DisableDirectStreaming();
            settings.BasicAuthentication(System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Username"], System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Password"]);

            var client = new Elastic.Elastic.Client.ElasticSearchClient<Area>(new ConnectionString("http", System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Location.Ip"], 9200), "location");

            client.CreateIndex();
        }

        public IEnumerable<IMultiGetHit<Area>> GetGeoJsonAreas(List<string> geoShapeIds)
        {
            var elasticClient = _service.NewClient("location");

            var response = elasticClient
                .GetMany<Area>(geoShapeIds);

            return response;
        }

        #endregion
    }
}
