﻿using Nest;
using Savills.Core.Api.Services;
using Savills.Core.Elastic.Elastic.Client.Settings;
using Savills.Core.Elastic.Elastic.Model;
using Savills.Core.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using Savills.Core.Extensions;

namespace Savills.Core.Api.Repositories
{
    /// <summary>
    /// Repository for carrying out basic basket tasks in code, can be called from WebApiController etc
    /// </summary>
    public class BasketRepository
    {
        private readonly ElasticService _service = new ElasticService();
        private string _basketIndexName = "basketitems";

        public void TestMapping()
        {
            var node = new Uri(System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Location"]);

            var settings = new ConnectionSettings(node);
            settings.DisableDirectStreaming();
            settings.BasicAuthentication(System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Username"], System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Password"]);

            var client = new Elastic.Elastic.Client.ElasticSearchClient<BasketItem>(new ConnectionString("http", System.Configuration.ConfigurationManager.AppSettings["Savills.Elastic.Location.Ip"], 9200), _basketIndexName);

            client.CreateIndex();
        }


        /// <summary>
        /// Adds an item to a user's basket, if the item already exists, it will just overwrite the older item
        /// </summary>
        /// <param name="basketItem"></param>
        /// <returns></returns>
        public IUpdateResponse<BasketItem> AddBasketItem(BasketItem basketItem)
        {
            var client = _service.NewClient(_basketIndexName);

            //client.Map<BasketItem>(m => m.Index(_basketIndexName));

   

            if (basketItem.Id == Guid.Empty)
            {
                //check if item exists first
                var checkExists = client.Search<BasketItem>(s => s
                    .Query(q => q
                        .Bool(b => b
                            .Must(
                                bs => bs.Term(p => p.PropertyId, basketItem.PropertyId),
                                bs => bs.Term(p => p.UserId, basketItem.UserId)
                            )
                        )
                    )
                );

                if (checkExists.Documents != null && checkExists.Documents.Any())
                {
                    //exists, overwite the old one
                    basketItem.Id = checkExists.Documents.First().Id;
                }
                else
                {
                    //doesn't exist, new ID
                    basketItem.Id = Guid.NewGuid();
                }
            }

            var response = client.Update(DocumentPath<BasketItem>
                  .Id(basketItem.Id),
                  u => u.Doc(basketItem).DocAsUpsert());

            var update = client.Refresh("basketitems");

            return response;
        }

        /// <summary>
        /// Get all basket items for a specific user
        /// </summary>
        public IEnumerable<BasketItem> GetBasketItems()
        {
            var basketUserId = BasketHelper.GetBasketUserId();

            return GetBasketItems(basketUserId);
        }

        /// <summary>
        /// Private method for getting basket by specific ID, needed for merging baskets from logged out to logged in
        /// </summary>
        /// <param name="basketUserId"></param>
        public IEnumerable<BasketItem> GetBasketItems(string basketUserId)
        {
            var client = _service.NewClient(_basketIndexName);

            var searchResults = client.Search<BasketItem>(s => s.Query(q => q.Term(p => p.UserId, basketUserId)));

            if (searchResults.Documents != null && searchResults.Documents.Any())
            {
                return searchResults.Documents;
            }

            return new List<BasketItem>();
        }

        /// <summary>
        /// Merges a basket from a logged out user into a logged in user
        /// </summary>
        public void TransferBasketToMember(string oldBasketUserId, string newBasketUserId)
        {
            var oldBasket = GetBasketItems(oldBasketUserId);
            var newBasket = GetBasketItems(newBasketUserId);
            
            var notInNewBasket = oldBasket.Except(newBasket, new BasketItemEqualityComparer());

            foreach (var item in notInNewBasket)
            {
                item.UserId = newBasketUserId;
                AddBasketItem(item);
            }

            //Clear the none logged in basket.
            EmptyBasket(oldBasketUserId);
        }

        /// <summary>
        /// Empty the basket for a designated User
        /// </summary>
        public void EmptyBasket()
        {
            var basketUserId = BasketHelper.GetBasketUserId();

            EmptyBasket(basketUserId);
        }

        /// <summary>
        /// Empties the basket into the 
        /// </summary>
        /// <param name="basketUserId"></param>
        public void EmptyBasket(string basketUserId)
        {
            var client = _service.NewClient(_basketIndexName);

            var searchResults = client.Search<BasketItem>(s => s
                .Query(q => q
                    .Bool(b => b
                        .Must(
                            bs => bs.Term(p => p.UserId, basketUserId)
                        )
                    )
                )
            );

            if (searchResults.Documents != null && searchResults.Documents.Any())
            {
                client.DeleteMany(searchResults.Documents);
            }
        }

        /// <summary>
        /// Remove a specifc basket item from a basket
        /// </summary>
        /// <param name="basketItemId"></param>
        public IDeleteResponse RemoveBasketItem(Guid basketItemId)
        {
            var client = _service.NewClient(_basketIndexName);

            var response = client.Delete(DocumentPath<BasketItem>
                  .Id(basketItemId));

            var update = client.Refresh("basketitems");

            return response;
        }

        /// <summary>
        /// Removes a property from ALL baskets in the index, shoudl be called when a property is deleted or unpublished
        /// </summary>
        /// <param name="propertyId"></param>
        public void RemoveAllItemsForProperty(int propertyId)
        {
            var client = _service.NewClient(_basketIndexName);

            var searchResults = client.Search<BasketItem>(s => s
                .Query(q => q
                    .Bool(b => b
                        .Must(
                            bs => bs.Term(p => p.PropertyId, propertyId)
                        )
                    )
                )
            );

            if (searchResults.Documents != null && searchResults.Documents.Any())
            {
                client.DeleteMany(searchResults.Documents);
            }
        }
    }
}