﻿using System;
using System.Collections.Generic;

namespace Savills.Core.CRMModels
{

    public class AlertMail
    {
        public Guid EmailId { get; set; }
        public Guid CrmGuid { get; set; }
        public Guid AlertId { get; set; }
        public int MemberId { get; set; }
        public DateTime EmailDate { get; set; }
        public List<int> Properties { get; set; } = new List<int>();
    }

}
