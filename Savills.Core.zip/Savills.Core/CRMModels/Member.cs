﻿namespace Savills.Core.CRMModels
{
    public class Member
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Company { get; set; }
        public Provider Provider { get; set; }
        public bool ReceiveMarketingEmails { get; set; }
        public bool ReceiveEmails { get; set; }

    }

    public class Provider
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Logo { get; set; }
        public string Description { get; set; }
        public bool Trusted { get; set; }
    }

}
