﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Savills.Core.DataModels
{
    public class PendingItem
    {
        [Column("nodeId")]
        public int NodeId { get; set; }
        [Column("TotalRecords")]
        public int TotalRecords { get; set; }
    }
}
