﻿using System;

namespace Savills.Core.DataModels
{
    public class PendingProperty
    {
        public int Id { get; set; }
        public string PropertyName { get; set; }
        public string ProviderName { get; set; }
        public DateTime DateUpdated { get; set; }
    }
}
