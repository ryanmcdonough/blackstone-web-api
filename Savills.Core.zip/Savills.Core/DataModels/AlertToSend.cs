﻿using System;
using Umbraco.Core.Persistence;

namespace Savills.Core.DataModels
{
    [TableName("wtAlertMail")]
    [PrimaryKey("Id", autoIncrement = true)]
    public class AlertToSend
    {
        public Guid AlertId { get; set; }
        public string AlertName { get; set; }
        public int PropertyId { get; set; }
        public int UserId { get; set; }
    }
}
