﻿using System.Collections.Generic;

namespace Savills.Core.DataModels
{
    public class PagedPendingProviders : PagedBase
    {
        public List<PendingProvider> Providers { get; set; }
    }
}
