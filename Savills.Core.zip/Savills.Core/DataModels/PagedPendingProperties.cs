﻿using System.Collections.Generic;

namespace Savills.Core.DataModels
{
    public class PagedPendingProperties : PagedBase
    {
        public List<PendingProperty> Properties { get; set; }
    }
}
