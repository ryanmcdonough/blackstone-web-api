﻿using System;
using Umbraco.Core.Persistence;

namespace Savills.Core.DataModels
{
    [TableName("wtViewingReview")]
    public class ViewingReview
    {
        public Guid Id { get; set; }
        public int PropertyId { get; set; }
        public int Rating { get; set; }
        public bool Complete { get; set; }
    }
}
