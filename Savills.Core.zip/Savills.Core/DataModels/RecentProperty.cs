﻿using Umbraco.Core.Persistence;

namespace Savills.Core.DataModels
{

    [TableName("wtRecentProperty")]
    [PrimaryKey("Id", autoIncrement = true)]
    public class RecentProperty
    {
        public int PropertyId { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
    }

}