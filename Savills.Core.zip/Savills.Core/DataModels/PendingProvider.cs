﻿using System;

namespace Savills.Core.DataModels
{
    public class PendingProvider
    {
        public int Id { get; set; }
        public string ProviderName { get; set; }
        public DateTime DateUpdated { get; set; }
    }
}
