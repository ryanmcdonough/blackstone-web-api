﻿using System.Collections.Generic;

namespace Savills.Core.DataModels
{
    public class PagedPendingReviews : PagedBase
    {
        public List<PendingReview> Reviews { get; set; }
    }
}