﻿namespace Savills.Core.DataModels
{
    public class PagedBase
    {
        public long CurrentPage { get; set; }

        public long ItemsPerPage { get; set; }

        public long TotalPages { get; set; }

        public long TotalItems { get; set; }
    }
}
