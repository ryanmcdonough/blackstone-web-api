﻿using System;

namespace Savills.Core.DataModels
{
    public class AwaitingReview
    {
        public Guid LeaseId { get; set; }

        public string PropertyName { get; set; }
    }
}
