﻿using System;
using Umbraco.Core.Persistence;
using Umbraco.Core.Persistence.DatabaseAnnotations;

namespace Savills.Core.DataModels
{
    [TableName("wtLease")]
    public class LeaseInfo
    {
        [PrimaryKeyColumn]
        public Guid Id { get; set; }
        public int PropertyId { get; set; }
        public int MemberId { get; set; }
        public string Name { get; set; }
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }
        public bool CompletedLease { get; set; }
        public bool CompletedReview { get; set; }
        public int ReviewId { get; set; }
        public DateTime ReviewOn { get; set; }
    }
}
