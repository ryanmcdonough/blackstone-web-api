﻿using System;
using Umbraco.Core.Models;
using Umbraco.Web;

namespace Savills.Core.DataModels
{
    public class PendingReview
    {
        public int Id { get; set; }
        public string PropertyName { get; set; }
        public string ReviewerName { get; set; }
        public int OverallRating { get; set; }
        public int BuildingRating { get; set; }
        public int ProviderRating { get; set; }
        public int FacilitiesRating { get; set; }
        public string Review { get; set; }
        public DateTime DateReviewed { get; set; }

        /// <summary>
        /// Constructor from content service item
        /// </summary>
        /// <param name="contentItem"></param>
        public PendingReview(IContent contentItem)
        {
            Id = contentItem.Id;
            BuildingRating = contentItem.GetValue<int>("buildingRating");
            DateReviewed = contentItem.CreateDate;
            FacilitiesRating = contentItem.GetValue<int>("facilitiesRating");
            OverallRating = contentItem.GetValue<int>("overallRating");
            ProviderRating = contentItem.GetValue<int>("providerRating");
            Review = contentItem.GetValue<string>("reviewContent");
            ReviewerName = contentItem.GetValue<string>("reviewerName");
        }

        /// <summary>
        /// Constructor from front end IPublishedContent
        /// </summary>
        /// <param name="contentItem"></param>
        public PendingReview(IPublishedContent contentItem)
        {
            Id = contentItem.Id;
            BuildingRating = contentItem.GetPropertyValue<int>("buildingRating");
            DateReviewed = contentItem.CreateDate;
            FacilitiesRating = contentItem.GetPropertyValue<int>("facilitiesRating");
            OverallRating = contentItem.GetPropertyValue<int>("overallRating");
            ProviderRating = contentItem.GetPropertyValue<int>("providerRating");
            Review = contentItem.GetPropertyValue<string>("reviewContent");
            ReviewerName = contentItem.GetPropertyValue<string>("reviewerName");
            PropertyName = contentItem.Parent.Name;
        }
    }
}