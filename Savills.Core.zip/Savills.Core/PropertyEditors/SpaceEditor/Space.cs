﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Savills.Core.PropertyEditors.SpaceEditor
{
    /// <summary>
    /// Property converter model class to represent an
    /// individual space
    /// </summary>
    public class Space
    {
        public Guid SpaceId { get; set; }
        public int Index { get; set; }
        public string Type { get; set; }
        [Required(ErrorMessage = "Please provide minimum amount of desks")]
        public int Minimum { get; set; }
        [Required(ErrorMessage = "Please provide maxmium amount of desks")]
        public int Maximum { get; set; }
        [Required(ErrorMessage = "Please set a price")]
        [Display(Name = "Price")]
        public decimal Price { get; set; }
        
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd MMMM, yyyy}")]
        public DateTime AvailableFrom { get; set; }
        public string Contract { get; set; }
        public string CrmGuid { get; set; }
        public decimal SqFt { get; set; }
        public bool Poa { get; set; }
    }
}