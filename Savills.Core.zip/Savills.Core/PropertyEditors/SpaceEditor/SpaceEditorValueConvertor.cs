﻿using System.Collections.Generic;
using Newtonsoft.Json;
using Umbraco.Core.Models.PublishedContent;
using Umbraco.Core.PropertyEditors;
using Umbraco.Web;

namespace Savills.Core.PropertyEditors.SpaceEditor
{
  
    [PropertyValueType(typeof(List<string>))]
    [PropertyValueCache(PropertyCacheValue.All, PropertyCacheLevel.Content)]
    public class SpaceEditorValueConvertor : PropertyValueConverterBase
    {

        public override object ConvertDataToSource(PublishedPropertyType propertyType, object source, bool preview)
        {
            if (source == null)
                return null;

            var settings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore
            };

            return UmbracoContext.Current == null ? null : JsonConvert.DeserializeObject<Space>(source.ToString(), settings);
        }
    
        public override bool IsConverter(PublishedPropertyType propertyType)
        {
            return propertyType.PropertyEditorAlias.Equals("spaceeditor");
        }
    }
}