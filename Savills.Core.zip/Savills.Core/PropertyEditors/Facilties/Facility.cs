﻿namespace Savills.Core.PropertyEditors.Facilties
{
    public class Facility
    {
        public string Name { get; set; }
    }
}
