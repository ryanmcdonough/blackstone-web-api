﻿namespace Savills.Core.PropertyEditors.Facilties
{
    public class Facilities
    {
        public bool Wifi { get; set; }
        public bool Access24Hour { get; set; }
        public bool Kitchen { get; set; }
        public bool Furnished { get; set; }
        public bool AirCon { get; set; }
        public bool Reception { get; set; }
        public bool MeetingRooms { get; set; }
        public bool Parking { get; set; }
        public bool Showers { get; set; }
        public bool FoodService { get; set; }
        public bool BikeParking { get; set; }
        public bool BreakoutArea { get; set; }
        public bool Lifts { get; set; }
        public bool Cleaning { get; set; }
        public bool AdminSupport { get; set; }
        public bool DisabledAccess { get; set; }
        public bool PetsAllowed { get; set; }
        public bool EventSpace { get; set; }
        public bool Lockers { get; set; }
        public bool PingPong { get; set; }
        public bool Concierge { get; set; }
        public bool RoofTopTerrace { get; set; }
        public bool CourtYard { get; set; }
        public bool TeaAndCoffee { get; set; }
        public bool Gym { get; set; }
        public bool Unfurnished { get; set; }
        public bool Bar { get; set; }
        public bool RuralLocation { get; set; }
        public bool NetworkingEvents { get; set; }
        public bool UniversityLink { get; set; }
        public bool BusinessAdvice { get; set; }
        public bool RecordingStudio { get; set; }
        public bool Laboratory { get; set; }
    }
}
