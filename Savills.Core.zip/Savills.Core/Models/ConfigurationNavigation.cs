﻿using System.Collections.Generic;
using System.Linq;
using Savills.Core.Extensions;
using Umbraco.Core.Models;
using Umbraco.ModelsBuilder;
using Umbraco.Web;

namespace Savills.Core.Models
{
    public partial class ConfigurationNavigation
    {
        private static IEnumerable<IPublishedContent> FilterNoIndex(IEnumerable<IPublishedContent> content)
        {
            // remove things that aren't derived from pages and aren't ticked as "No index"
            var filtered = from c in content
                           let page = c as Page
                           where page != null
                           select page;

            return filtered;
        }

        [ImplementPropertyType("headerNavigation")]
        public IEnumerable<IPublishedContent> HeaderNavigation
        {
            get
            {
                var content = this.GetPropertyValue<IEnumerable<IPublishedContent>>("headerNavigation");
                return FilterNoIndex(content);
            }
        }


        [ImplementPropertyType("dashboardNavigation")]
        public IEnumerable<IPublishedContent> DashboardNavigation
        {

            get
            {
                var content = this.GetPropertyValue<IEnumerable<IPublishedContent>>("dashboardNavigation");
                return FilterNoIndex(content);
            }
        }


        [ImplementPropertyType("footerNavigation")]
        public IEnumerable<IPublishedContent> FooterNavigation
        {

            get
            {
                var content = this.GetPropertyValue<IEnumerable<IPublishedContent>>("footerNavigation");
                return FilterNoIndex(content);
            }
        }

        [ImplementPropertyType("footerColumn1")]
        public IEnumerable<IPublishedContent> FooterColumn1
        {

            get
            {
                var content = this.GetPropertyValue<IEnumerable<IPublishedContent>>("footerColumn1");
                return FilterNoIndex(content);
            }

        }


        [ImplementPropertyType("footerColumn2")]
        public IEnumerable<IPublishedContent> FooterColumn2
        {
            get
            {
                var content = this.GetPropertyValue<IEnumerable<IPublishedContent>>("footerColumn2");
                return FilterNoIndex(content);
            }
        }


        [ImplementPropertyType("footerColumn3")]
        public IEnumerable<IPublishedContent> FooterColumn3
        {

            get
            {
                var content = this.GetPropertyValue<IEnumerable<IPublishedContent>>("footerColumn3");
                return FilterNoIndex(content);
            }
        }

        [ImplementPropertyType("footerColumn4")]
        public IEnumerable<IPublishedContent> FooterColumn4
        {

            get
            {
                var content = this.GetPropertyValue<IEnumerable<IPublishedContent>>("footerColumn4");
                return FilterNoIndex(content);
            }
        }


        [ImplementPropertyType("footerColumn1Header")]
        public string FooterColumn1Header => this.GetTranslatedPropertyValue<string>("footerColumn1Header");

        [ImplementPropertyType("footerColumn2Header")]
        public string FooterColumn2Header => this.GetTranslatedPropertyValue<string>("footerColumn2Header");

        [ImplementPropertyType("footerColumn3Header")]
        public string FooterColumn3Header => this.GetTranslatedPropertyValue<string>("footerColumn3Header");

        [ImplementPropertyType("footerColumn4Header")]
        public string FooterColumn4Header => this.GetTranslatedPropertyValue<string>("footerColumn4Header");


        [ImplementPropertyType("home")]
        public Page Home => this.GetPropertyValue<IPublishedContent>("home") as Page;

        [ImplementPropertyType("register")]
        public Page Register => this.GetPropertyValue<IPublishedContent>("register") as Page;

        ///<summary>
		/// Account Details
		///</summary>
		[ImplementPropertyType("accountDetails")]
        public Page AccountDetails => this.GetPropertyValue<IPublishedContent>("accountDetails") as Page;

        ///<summary>
        /// Forgotten Password
        ///</summary>
        [ImplementPropertyType("forgottenPassword")]
        public Page ForgottenPassword => this.GetPropertyValue<IPublishedContent>("forgottenPassword") as Page;


        ///<summary>
        /// Location Updates
        ///</summary>
        [ImplementPropertyType("locationUpdates")]
        public Page LocationUpdates => this.GetPropertyValue<IPublishedContent>("locationUpdates") as Page;

        ///<summary>
        /// Login
        ///</summary>
        [ImplementPropertyType("login")]
        public Page Login => this.GetPropertyValue<IPublishedContent>("login") as Page;

        ///<summary>
        /// Logout
        ///</summary>
        [ImplementPropertyType("logout")]
        public Page Logout => this.GetPropertyValue<IPublishedContent>("logout") as Page;

        ///<summary>
        /// Manage Listings
        ///</summary>
        [ImplementPropertyType("manageListings")]
        public Page ManageListings => this.GetPropertyValue<IPublishedContent>("manageListings") as Page;

        ///<summary>
        /// Manage Reviews
        ///</summary>
        [ImplementPropertyType("manageReviews")]
        public Page ManageReviews => this.GetPropertyValue<IPublishedContent>("manageReviews") as Page;

        ///<summary>
        /// Rate Viewings
        ///</summary>
        [ImplementPropertyType("rateViewings")]
        public Page RateViewings => this.GetPropertyValue<IPublishedContent>("rateViewings") as Page;

        ///<summary>
        /// Your Reviews
        ///</summary>
        [ImplementPropertyType("yourReviews")]
        public Page YourReviews => this.GetPropertyValue<IPublishedContent>("yourReviews") as Page;


        ///<summary>
        /// Your Reviews
        ///</summary>
        [ImplementPropertyType("guides")]
        public Page Guides => this.GetPropertyValue<IPublishedContent>("guides") as Page;

        ///<summary>
        /// Your Reviews
        ///</summary>
        [ImplementPropertyType("contactUs")]
        public Page ContactUs => this.GetPropertyValue<IPublishedContent>("contactUs") as Page;

        ///<summary>
        /// Your Reviews
        ///</summary>
        [ImplementPropertyType("listYourSpace")]
        public Page ListYourSpace => this.GetPropertyValue<IPublishedContent>("listYourSpace") as Page;

        ///<summary>
        /// Your Reviews
        ///</summary>
        [ImplementPropertyType("whyUs")]
        public Page WhyUs => this.GetPropertyValue<IPublishedContent>("whyUs") as Page;

        ///<summary>
        /// Your Reviews
        ///</summary>
        [ImplementPropertyType("shortlist")]
        public Page Shortlist => this.GetPropertyValue<IPublishedContent>("shortlist") as Page;

        ///<summary>
        /// Your Reviews
        ///</summary>
        [ImplementPropertyType("enquiryComplete")]
        public Page EnquiryComplete => this.GetPropertyValue<IPublishedContent>("enquiryComplete") as Page;

        ///<summary>
        /// Your Reviews
        ///</summary>
        [ImplementPropertyType("searchResults")]
        public Page SearchResults => this.GetPropertyValue<IPublishedContent>("searchResults") as Page;

    }
}
