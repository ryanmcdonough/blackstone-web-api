﻿using System.Collections.Generic;
using System.Linq;
using Savills.Core.Extensions;
using Umbraco.Core.Models;
using Umbraco.ModelsBuilder;

namespace Savills.Core.Models
{
    public partial class PageWhyUsBenefits
    {
        [ImplementPropertyType("findSpaceText")]
        public string FindSpaceText => this.GetTranslatedPropertyValue<string>("findSpaceText");

        [ImplementPropertyType("findWhatYouNeedText")]
        public string FindWhatYouNeedText => this.GetTranslatedPropertyValue<string>("findWhatYouNeedText");

        [ImplementPropertyType("heroBulletPoints")]
        public IEnumerable<DataRepeatableString> HeroBulletPoints
        {
            get { return this.GetTranslatedPropertyValue<IEnumerable<IPublishedContent>>("heroBulletPoints").Select(a => new DataRepeatableString(a)); }
        }

        [ImplementPropertyType("heroImage")]
        public IPublishedContent HeroImage => this.GetTranslatedPropertyValue<IPublishedContent>("heroImage");

        [ImplementPropertyType("occupiersTitle")]
        public string OccupiersTitle => this.GetTranslatedPropertyValue<string>("occupiersTitle");

        [ImplementPropertyType("occupiersItems")]
        public IEnumerable<DataKeyFeature> OccupiersItems
        {
            get { return this.GetTranslatedPropertyValue<IEnumerable<IPublishedContent>>("occupiersItems").Select(a => new DataKeyFeature(a)); }
        }

        [ImplementPropertyType("providersTitle")]
        public string ProvidersTitle => this.GetTranslatedPropertyValue<string>("providersTitle");

        [ImplementPropertyType("providersItems")]
        public IEnumerable<DataKeyFeature> ProvidersItems
        {
            get { return this.GetTranslatedPropertyValue<IEnumerable<IPublishedContent>>("providersItems").Select(a => new DataKeyFeature(a)); }
        }

        [ImplementPropertyType("searchAlertText")]
        public string SearchAlertText => this.GetTranslatedPropertyValue<string>("searchAlertText");

        [ImplementPropertyType("searchAlertTitle")]
        public string SearchAlertTitle => this.GetTranslatedPropertyValue<string>("searchAlertTitle");

        [ImplementPropertyType("shortlistText")]
        public string ShortlistText => this.GetTranslatedPropertyValue<string>("shortlistText");

        [ImplementPropertyType("shortlistTitle")]
        public string ShortlistTitle => this.GetTranslatedPropertyValue<string>("shortlistTitle");
    }
}
