﻿namespace Savills.Core.Models
{
    public class AlternateLink
    {
        public string Link { get; set; }

        public string Language { get; set; }
    }
}
