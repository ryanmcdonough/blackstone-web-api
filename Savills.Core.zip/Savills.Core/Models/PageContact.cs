﻿using Savills.Core.Extensions;
using Savills.Core.ViewModels;
using Umbraco.ModelsBuilder;

namespace Savills.Core.Models
{
    public partial class PageContact
    {
        public ContactFormViewModel Form { get; set; } = new ContactFormViewModel();

        ///<summary>
        /// Hero
        ///</summary>
        [ImplementPropertyType("hero")]
        public Image Hero => this.GetTranslatedPropertyValue<Image>("hero");

        ///<summary>
        /// Subtitle
        ///</summary>
        [ImplementPropertyType("subtitle")]
        public string Subtitle => this.GetTranslatedPropertyValue<string>("subtitle");
    }
}