﻿using System.Collections.Generic;
using System.Linq;
using Umbraco.Core.Models;
using Umbraco.ModelsBuilder;
using Umbraco.Web;

namespace Savills.Core.Models
{
    public partial class ConfigurationSearch
    {
		///<summary>
		/// Place Type Default Radiuses
		///</summary>
		[ImplementPropertyType("placeTypeDefaultRadiuses")]
		public IEnumerable<DataPlaceTypeDefaultRadius> PlaceTypeDefaultRadiuses
		{
		    get
		    {
		        var dataPlaceTypeDefaultRadiuses = this.GetPropertyValue<IEnumerable<IPublishedContent>>(
		            "placeTypeDefaultRadiuses")
                    .Select(pc => new DataPlaceTypeDefaultRadius(pc));
		        return dataPlaceTypeDefaultRadiuses;
		    }
		}
    }
}