﻿using Savills.Core.Extensions;
using Umbraco.ModelsBuilder;
using Umbraco.Core.Models;

namespace Savills.Core.Models
{
    public partial class PageSimpleContent
    {
        [ImplementPropertyType("heroImage")]
        public IPublishedContent HeroImage => this.GetTranslatedPropertyValue<IPublishedContent>("heroImage");

        [ImplementPropertyType("pageContent")]
        public string PageContent => this.GetTranslatedPropertyValue<string>("pageContent");

        [ImplementPropertyType("strapline")]
        public string Strapline => this.GetTranslatedPropertyValue<string>("strapline");
    }
}
