﻿using Savills.Core.ViewModels;

namespace Savills.Core.Models
{
    public partial class PageManageSpace
    {
        public ListPropertyViewModel PropertyDetail { get; set; } = new ListPropertyViewModel();
    }
}