﻿using System;
using System.Collections.Generic;
using UIOMatic.Attributes;
using UIOMatic.Enums;
using Umbraco.Core.Persistence;
using Umbraco.Core.Persistence.DatabaseAnnotations;

namespace Savills.Core.Models
{
    [UIOMatic("leases", "Leases", "Lease", FolderIcon = "icon-users", ItemIcon = "icon-user", RenderType = UIOMaticRenderType.List)]
    [TableName("wtLease")]
    public class LeaseInfoUi
    {
        [PrimaryKeyColumn(AutoIncrement = false)]
        [UIOMaticListViewField]
        public Guid Id { get; set; } = Guid.NewGuid();
        [UIOMaticListViewField]
        [UIOMaticField(Name = "Reference", Description = "")]
        public string Name { get; set; }
        [UIOMaticField(Name = "Property ID", Description = "Enter the property ID for the lease")]
        public int PropertyId { get; set; }
        [UIOMaticField(Name = "Member ID", Description = "Enter the member's ID for the lease")]
        public int MemberId { get; set; }
        [UIOMaticListViewField]
        [UIOMaticField(Name = "Start Date", Description = "",View = UIOMatic.Constants.FieldEditors.Date)]
        public DateTime DateFrom { get; set; }
        [UIOMaticListViewField]
        [UIOMaticField(Name = "End Date", Description = "", View = UIOMatic.Constants.FieldEditors.Date)]
        public DateTime DateTo { get; set; }


        public override string ToString()
        {
            return Id.ToString();
        }

        public void SetDefaultValue()
        {
            if (Id == Guid.Empty)
            {
                Id = Guid.NewGuid();
            }
        }

        public IEnumerable<Exception> Validate()
        {
            var exs = new List<Exception>();



            //if(string.IsNullOrEmpty(PropertyID))
            //     exs.Add(new Exception("Please provide a value for first name"));

            // if (string.IsNullOrEmpty(MemberID))
            //     exs.Add(new Exception("Please provide a value for last name"));

            return exs;
        }
    }
}