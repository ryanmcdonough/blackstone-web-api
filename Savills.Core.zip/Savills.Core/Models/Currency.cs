﻿namespace Savills.Core.Models
{
    public class CurrencyItem
    {
        public string Currency { get; set; }
    }
}
