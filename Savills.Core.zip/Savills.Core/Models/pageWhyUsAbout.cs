﻿using System.Collections.Generic;
using System.Linq;
using Savills.Core.Extensions;
using Umbraco.Core.Models;
using Umbraco.ModelsBuilder;

namespace Savills.Core.Models
{
    public partial class PageWhyUsAbout
    {
        [ImplementPropertyType("heroImage")]
        public IPublishedContent HeroImage => this.GetTranslatedPropertyValue<IPublishedContent>("heroImage");

        [ImplementPropertyType("introCopy")]
        public string IntroCopy => this.GetTranslatedPropertyValue<string>("introCopy");

        [ImplementPropertyType("poweredByImage")]
        public IPublishedContent PoweredByImage => this.GetTranslatedPropertyValue<IPublishedContent>("poweredByImage");

        [ImplementPropertyType("poweredByText")]
        public string PoweredByText => this.GetTranslatedPropertyValue<string>("poweredByText");

        [ImplementPropertyType("poweredByTitle")]
        public string PoweredByTitle => this.GetTranslatedPropertyValue<string>("poweredByTitle");

        [ImplementPropertyType("promoItems")]
        public IEnumerable<DataPromoBlock> PromoItems
        {
            get
            {
                return this.GetTranslatedPropertyValue<IEnumerable<IPublishedContent>>("promoItems").Select(a => new DataPromoBlock(a));
            }
        }

        [ImplementPropertyType("strapline")]
        public string Strapline => this.GetTranslatedPropertyValue<string>("strapline");

        [ImplementPropertyType("teamMembers")]
        public IEnumerable<DataTeamMember> TeamMembers
        {
            get { return this.GetTranslatedPropertyValue<IEnumerable<IPublishedContent>>("teamMembers").Select(a => new DataTeamMember(a)); }
        }

        [ImplementPropertyType("teamTitle")]
        public string TeamTitle => this.GetTranslatedPropertyValue<string>("teamTitle");
    }
}
