﻿using Savills.Core.Extensions;
using Umbraco.ModelsBuilder;
using Umbraco.Core.Models;

namespace Savills.Core.Models
{
    public partial class PageWhyUsSpaceMatters
    {
        [ImplementPropertyType("footerText")]
        public string FooterText => this.GetTranslatedPropertyValue<string>("footerText");

        [ImplementPropertyType("heroImage")]
        public IPublishedContent HeroImage => this.GetTranslatedPropertyValue<IPublishedContent>("heroImage");

        [ImplementPropertyType("image1")]
        public IPublishedContent Image1 => this.GetTranslatedPropertyValue<IPublishedContent>("image1");

        [ImplementPropertyType("image2")]
        public IPublishedContent Image2 => this.GetTranslatedPropertyValue<IPublishedContent>("image2");

        [ImplementPropertyType("image3")]
        public IPublishedContent Image3 => this.GetTranslatedPropertyValue<IPublishedContent>("image3");

        [ImplementPropertyType("introImageLarge")]
        public IPublishedContent IntroImageLarge => this.GetTranslatedPropertyValue<IPublishedContent>("introImageLarge");

        [ImplementPropertyType("introImageSmall")]
        public IPublishedContent IntroImageSmall => this.GetTranslatedPropertyValue<IPublishedContent>("introImageSmall");

        [ImplementPropertyType("introImageText")]
        public string IntroImageText => this.GetTranslatedPropertyValue<string>("introImageText");

        [ImplementPropertyType("pageContent")]
        public string PageContent => this.GetTranslatedPropertyValue<string>("pageContent");

        [ImplementPropertyType("strapline")]
        public string Strapline => this.GetTranslatedPropertyValue<string>("strapline");
    }
}
