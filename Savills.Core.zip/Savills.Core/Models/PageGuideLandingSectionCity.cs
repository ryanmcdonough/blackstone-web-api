﻿using Umbraco.ModelsBuilder;
using Umbraco.Web;
using Savills.Core.Extensions;

namespace Savills.Core.Models
{
    public partial class PageGuideLandingSectionCity
    {
        [ImplementPropertyType("country")]
        public string Country => this.GetPropertyValue<string>("country");

        [ImplementPropertyType("description")]
        public string Description => this.GetTranslatedPropertyValue<string>("description");

        [ImplementPropertyType("tagline")]
        public string Tagline => this.GetTranslatedPropertyValue<string>("tagline");
    }
}
