﻿using System.Collections.Generic;
using System.Linq;
using Savills.Core.Extensions;
using Umbraco.ModelsBuilder;
using Umbraco.Core.Models;

namespace Savills.Core.Models
{
    public partial class PageWhyUsLanding
    {
        [ImplementPropertyType("aboutButtonLink")]
        public IPublishedContent AboutButtonLink => this.GetTranslatedPropertyValue<IPublishedContent>("aboutButtonLink");

        [ImplementPropertyType("aboutButtonText")]
        public string AboutButtonText => this.GetTranslatedPropertyValue<string>("aboutButtonText");

        [ImplementPropertyType("aboutImage")]
        public IPublishedContent AboutImage => this.GetTranslatedPropertyValue<IPublishedContent>("aboutImage");

        [ImplementPropertyType("aboutText")]
        public string AboutText => this.GetTranslatedPropertyValue<string>("aboutText");

        [ImplementPropertyType("heroBulletPoints")]
        public IEnumerable<DataRepeatableString> HeroBulletPoints
        {
            get { return this.GetTranslatedPropertyValue<IEnumerable<IPublishedContent>>("heroBulletPoints").Select(a => new DataRepeatableString(a)); }
        }

        [ImplementPropertyType("heroButtonLink")]
        public IPublishedContent HeroButtonLink => this.GetTranslatedPropertyValue<IPublishedContent>("heroButtonLink");

        [ImplementPropertyType("heroButtonText")]
        public string HeroButtonText => this.GetTranslatedPropertyValue<string>("heroButtonText");

        [ImplementPropertyType("heroImage")]
        public IPublishedContent HeroImage => this.GetTranslatedPropertyValue<IPublishedContent>("heroImage");

        [ImplementPropertyType("howItWorksButtonLink")]
        public IPublishedContent HowItWorksButtonLink => this.GetTranslatedPropertyValue<IPublishedContent>("howItWorksButtonLink");

        [ImplementPropertyType("howItWorksButtonText")]
        public string HowItWorksButtonText => this.GetTranslatedPropertyValue<string>("howItWorksButtonText");

        [ImplementPropertyType("howItWorksLeftImage")]
        public IPublishedContent HowItWorksLeftImage => this.GetTranslatedPropertyValue<IPublishedContent>("howItWorksLeftImage");

        [ImplementPropertyType("howItWorksLeftTitle")]
        public string HowItWorksLeftTitle => this.GetTranslatedPropertyValue<string>("howItWorksLeftTitle");

        [ImplementPropertyType("howItWorksRightImage")]
        public IPublishedContent HowItWorksRightImage => this.GetTranslatedPropertyValue<IPublishedContent>("howItWorksRightImage");

        [ImplementPropertyType("howItWorksRightTitle")]
        public string HowItWorksRightTitle => this.GetTranslatedPropertyValue<string>("howItWorksRightTitle");

        [ImplementPropertyType("howItWorksText")]
        public string HowItWorksText => this.GetTranslatedPropertyValue<string>("howItWorksText");

        [ImplementPropertyType("heroText")]
        public string HeroText => this.GetTranslatedPropertyValue<string>("heroText");

        [ImplementPropertyType("whySpaceMattersButtonLink")]
        public IPublishedContent WhySpaceMattersButtonLink => this.GetTranslatedPropertyValue<IPublishedContent>("whySpaceMattersButtonLink");

        [ImplementPropertyType("whySpaceMattersButtonText")]
        public string WhySpaceMattersButtonText => this.GetTranslatedPropertyValue<string>("whySpaceMattersButtonText");

        [ImplementPropertyType("whySpaceMattersImageLarge")]
        public IPublishedContent WhySpaceMattersImageLarge => this.GetTranslatedPropertyValue<IPublishedContent>("whySpaceMattersImageLarge");

        [ImplementPropertyType("whySpaceMattersImageSmall")]
        public IPublishedContent WhySpaceMattersImageSmall => this.GetTranslatedPropertyValue<IPublishedContent>("whySpaceMattersImageSmall");

        [ImplementPropertyType("whySpaceMattersText")]
        public string WhySpaceMattersText => this.GetTranslatedPropertyValue<string>("whySpaceMattersText");
    }
}
