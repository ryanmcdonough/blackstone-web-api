﻿using System.Collections.Generic;
using Savills.Core.DataModels;

namespace Savills.Core.Models
{
    public partial class PageAccount
    {
        public List<LeaseInfo> Leases { get; set; } = new List<LeaseInfo>();
        public Nest.ISearchResponse<Elastic.Elastic.Model.Alert> Alerts { get; set; }

    }
}