﻿using System.Collections.Generic;
using System.Linq;
using Savills.Core.Extensions;
using Umbraco.ModelsBuilder;
using Umbraco.Core.Models;

namespace Savills.Core.Models
{
    public partial class PageWhyUsTestimonials
    {
        [ImplementPropertyType("testimonials")]
        public IEnumerable<DataTestimonial> Testimonials
        {
            get { return this.GetTranslatedPropertyValue<IEnumerable<IPublishedContent>>("testimonials").Select(a => new DataTestimonial(a)); }
        }

        [ImplementPropertyType("mainQuoteImage")]
        public IPublishedContent MainQuoteImage => this.GetTranslatedPropertyValue<IPublishedContent>("mainQuoteImage");
    }
}
