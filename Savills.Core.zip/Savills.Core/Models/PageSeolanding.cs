﻿using Epiphany.SeoMetadata;
using Savills.Core.Extensions;
using Umbraco.ModelsBuilder;

namespace Savills.Core.Models
{
    public partial class PageSeolanding
    {
        public bool IsVirtualLandingPage { get; set; } = false;

        public PagePlace Place { get; set; } = null;

        public string VirtualUrl { get; set; } = string.Empty;

        public string TokenizedVirtualSeoTitle
        {
            get
            {
                var title = !string.IsNullOrEmpty(Place.LandingMetadata.Title) ? Place.LandingMetadata.Title : SubPageMetaData.Title;

                return title.GetTokenisedSeoString(Title, Place.Title);
            }
        }

        public string TokenizedVirtualSeoDescription
        {
            get
            {
                var description = !string.IsNullOrEmpty(Place.LandingMetadata.Description) ? Place.LandingMetadata.Description : SubPageMetaData.Description;

                return description.GetTokenisedSeoString(Title, Place.Title);
            }
        }

        public string TokenizedVirtualPageHeading
        {
            get
            {
                var heading = !string.IsNullOrEmpty(Place.LandingTitle) ? Place.LandingTitle : SubPageTitle;

                return heading.GetTokenisedSeoString(Title, Place.Title);
            }
        }

        public string TokenizedVirtualPageContent
        {
            get
            {
                var content = !string.IsNullOrEmpty(Place.LandingContent) ? Place.LandingContent : SubPageContent;

                return content.GetTokenisedSeoString(Title, Place.Title);
            }
        }

        public override string Url
        {
            get
            {
                if (!string.IsNullOrEmpty(VirtualUrl))
                {
                    return VirtualUrl;
                }
                else
                {
                    return base.Url;
                }
            }
        }

        [ImplementPropertyType("subPageMetadata")]
        public virtual SeoMetadata SubPageMetaData
        {
            get
            {
                var metadata = this.GetTranslatedPropertyValue<SeoMetadata>("subPageMetadata") ?? new SeoMetadata
                {
                    Title = Name,
                    NoIndex = false,
                };

                return metadata;
            }
        }

        [ImplementPropertyType("subPageTitle")]
        public string SubPageTitle
        {
            get
            {
                var title = this.GetTranslatedPropertyValue<string>("subPageTitle");

                return title;
            }
        }

        [ImplementPropertyType("subPageContent")]
        public string SubPageContent
        {
            get
            {
                var content = this.GetTranslatedPropertyValue<string>("subPageContent");
                
                return content;
            }
        }
    }
}