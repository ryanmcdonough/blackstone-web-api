﻿using Savills.Core.DataModels;

namespace Savills.Core.Models
{
    public partial class PageViewingReview
    {
        public ViewingReview Review { get; set; } = new ViewingReview();
    }
}