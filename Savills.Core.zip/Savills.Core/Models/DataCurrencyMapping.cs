﻿using Umbraco.ModelsBuilder;
using Umbraco.Web;

namespace Savills.Core.Models
{
    public partial class DataCurrencyMapping
    {
        [ImplementPropertyType("currency")]
        public string Currency => this.GetPropertyValue<string>("currency");

        ///<summary>
        /// Language
        ///</summary>
        [ImplementPropertyType("language")]
        public string Language => this.GetPropertyValue<string>("language");
    }
}
