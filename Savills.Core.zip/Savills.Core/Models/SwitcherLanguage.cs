﻿namespace Savills.Core.Models
{
    public class SwitcherLanguage
    {
        public string LanguageName { get; set; }
        public string LanguageCode { get; set; }
        public bool IsCurrentLanguage { get; set; }
        public string RedirectUrl { get; set; }
    }

    public class SwitcherCurrency
    {
        public string CurrencyName { get; set; }
        public string CurrencyCode { get; set; }
        public bool IsCurrentCurrency { get; set; }
        public string RedirectUrl { get; set; }
    }

}
