﻿namespace Savills.Core.Models
{
    public class FacebookLogin
    {
        public string AccessKey { get; set; }
    }
}