﻿using System.Collections.Generic;

namespace Savills.Core.Models
{
    public class LanguageWarning
    {
        public bool ShouldDisplayWarning { get; set; }
        public string WarningMessage        { get; set; }
        public string YesButtonText { get; set; }
        public string NoButtonText { get; set; }
        public string NativeLanguageUrl { get; set; }
        public IList<LanguageWarningLanguage> AvailableLanguages { get; set; }
    }

    public class LanguageWarningLanguage
    {
        /// <summary>
        /// IETF Tag
        /// </summary>
        public string Code        { get; }

        /// <summary>
        /// In the current browser language.
        /// </summary>
        public string DisplayName { get; }

        /// <summary>
        /// Must not be empty.
        /// </summary>
        public string FlagUrl     { get; }

        /// <summary>
        /// Current URL in this language.
        /// </summary>
        public string CurrentUrl  { get; }

        public LanguageWarningLanguage(string code, string displayName, string flagUrl, string currentUrl)
        {
            Code        = code;
            DisplayName = displayName;
            FlagUrl     = flagUrl;
            CurrentUrl  = currentUrl;
        }
    }
}