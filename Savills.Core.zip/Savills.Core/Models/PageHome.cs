﻿using System.Collections.Generic;
using System.Linq;
using Savills.Core.Extensions;
using Umbraco.Core.Models;
using Umbraco.ModelsBuilder;

namespace Savills.Core.Models
{
    public partial class PageHome
    {
        ///<summary> 
        /// Bottom Left Block Call To Action 
        ///</summary> 
        [ImplementPropertyType("bottomLeftBlockCallToAction")]
        public RJP.MultiUrlPicker.Models.MultiUrls BottomLeftBlockCallToAction
        {
            get { return this.GetTranslatedPropertyValue<RJP.MultiUrlPicker.Models.MultiUrls>("bottomLeftBlockCallToAction"); }
        }

        ///<summary> 
        /// Bottom Right Block Call To Action 
        ///</summary> 
        [ImplementPropertyType("bottomRightBlockCallToAction")]
        public RJP.MultiUrlPicker.Models.MultiUrls BottomRightBlockCallToAction
        {
            get { return this.GetTranslatedPropertyValue<RJP.MultiUrlPicker.Models.MultiUrls>("bottomRightBlockCallToAction"); }
        }


        [ImplementPropertyType("testimonials")]
        public List<DataTestimonial> Testimonials => this.GetTranslatedPropertyValue<IEnumerable<IPublishedContent>>("testimonials")
            .Select(a => new DataTestimonial(a))
            .ToList();

        ///<summary>
        /// Right Bottom Block Background
        ///</summary>
        [ImplementPropertyType("bottomRightBlockBackground")]
        public Image BottomRightBlockBackground => this.GetTranslatedPropertyValue<Image>("bottomRightBlockBackground");

        ///<summary>
        /// Right Bottom Block Description
        ///</summary>
        [ImplementPropertyType("bottomRightBlockDescription")]
        public string BottomRightBlockDescription => this.GetTranslatedPropertyValue<string>("bottomRightBlockDescription");

        ///<summary>
        /// Right Bottom Block Heading
        ///</summary>
        [ImplementPropertyType("bottomRightBlockHeading")]
        public string BottomRightBlockHeading => this.GetTranslatedPropertyValue<string>("bottomRightBlockHeading");

        ///<summary>
        /// Left Block Background
        ///</summary>
        [ImplementPropertyType("bottomLeftBlockBackground")]
        public Image BottomLeftBlockBackground => this.GetTranslatedPropertyValue<Image>("bottomLeftBlockBackground");

        ///<summary>
        /// Left Bottom Block Description
        ///</summary>
        [ImplementPropertyType("bottomLeftBlockDescription")]
        public string BottomLeftBlockDescription => this.GetTranslatedPropertyValue<string>("bottomLeftBlockDescription");

        ///<summary>
        /// Left Bottom Block Heading
        ///</summary>
        [ImplementPropertyType("bottomLeftBlockHeading")]
        public string BottomLeftBlockHeading => this.GetTranslatedPropertyValue<string>("bottomLeftBlockHeading");

        [ImplementPropertyType("featureFour")]
        public string FeatureFour => this.GetTranslatedPropertyValue<string>("featureFour");

        ///<summary>
        /// Feature Four Description
        ///</summary>
        [ImplementPropertyType("featureFourDescription")]
        public string FeatureFourDescription => this.GetTranslatedPropertyValue<string>("featureFourDescription");

        ///<summary>
        /// Feature One
        ///</summary>
        [ImplementPropertyType("featureOne")]
        public string FeatureOne => this.GetTranslatedPropertyValue<string>("featureOne");

        ///<summary>
        /// Feature One Description
        ///</summary>
        [ImplementPropertyType("featureOneDescription")]
        public string FeatureOneDescription => this.GetTranslatedPropertyValue<string>("featureOneDescription");

        ///<summary>
        /// Features Title
        ///</summary>
        [ImplementPropertyType("featuresTitle")]
        public string FeaturesTitle => this.GetTranslatedPropertyValue<string>("featuresTitle");

        ///<summary>
        /// Feature Three
        ///</summary>
        [ImplementPropertyType("featureThree")]
        public string FeatureThree => this.GetTranslatedPropertyValue<string>("featureThree");

        ///<summary>
        /// Feature Three Description
        ///</summary>
        [ImplementPropertyType("featureThreeDescription")]
        public string FeatureThreeDescription => this.GetTranslatedPropertyValue<string>("featureThreeDescription");

        ///<summary>
        /// Feature Two
        ///</summary>
        [ImplementPropertyType("featureTwo")]
        public string FeatureTwo => this.GetTranslatedPropertyValue<string>("featureTwo");

        ///<summary>
        /// Feature Two Description
        ///</summary>
        [ImplementPropertyType("featureTwoDescription")]
        public string FeatureTwoDescription => this.GetTranslatedPropertyValue<string>("featureTwoDescription");

        ///<summary>
        /// Promo Description
        ///</summary>
        [ImplementPropertyType("homePromoDescription")]
        public string HomePromoDescription => this.GetTranslatedPropertyValue<string>("homePromoDescription");

        ///<summary>
        /// Promo Link Text
        ///</summary>
        [ImplementPropertyType("homePromoLinkText")]
        public string HomePromoLinkText => this.GetTranslatedPropertyValue<string>("homePromoLinkText");

        ///<summary>
        /// Promo Title
        ///</summary>
        [ImplementPropertyType("homePromoTitle")]
        public string HomePromoTitle => this.GetTranslatedPropertyValue<string>("homePromoTitle");

        ///<summary>
        /// Promo Image
        ///</summary>
        [ImplementPropertyType("promoImage")]
        public IPublishedContent PromoImage => this.GetTranslatedPropertyValue<IPublishedContent>("promoImage");

        ///<summary>
        /// Video Tagline
        ///</summary>
        [ImplementPropertyType("videoTagline")]
        public string VideoTagline => this.GetTranslatedPropertyValue<string>("videoTagline");

        ///<summary>
        /// Video Title
        ///</summary>
        [ImplementPropertyType("videoTitle")]
        public string VideoTitle => this.GetTranslatedPropertyValue<string>("videoTitle");
    }
}