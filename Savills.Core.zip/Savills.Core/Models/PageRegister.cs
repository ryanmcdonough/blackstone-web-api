﻿using System.Collections.Generic;
using Savills.Core.Extensions;
using Umbraco.Core.Models;
using Umbraco.ModelsBuilder;

namespace Savills.Core.Models
{
    public partial class PageRegister
    {
        ///<summary>
        /// Features
        ///</summary>
        [ImplementPropertyType("features")]
        public IEnumerable<IPublishedContent> Features => this.GetTranslatedPropertyValue<IEnumerable<IPublishedContent>>("features");

        ///<summary>
        /// Feature Title
        ///</summary>
        [ImplementPropertyType("featureTitle")]
        public string FeatureTitle => this.GetTranslatedPropertyValue<string>("featureTitle");

        ///<summary>
        /// Feature Description
        ///</summary>
        [ImplementPropertyType("featureDescription")]
        public string FeatureDescription => this.GetTranslatedPropertyValue<string>("featureDescription");
    }
}