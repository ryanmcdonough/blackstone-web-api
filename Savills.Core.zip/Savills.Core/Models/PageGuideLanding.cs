﻿using Umbraco.ModelsBuilder;
using Savills.Core.Extensions;

namespace Savills.Core.Models
{
    public partial class PageGuideLanding
    {
        [ImplementPropertyType("marketInformationCTAText")]
        public string MarketInformationCtatext => this.GetTranslatedPropertyValue<string>("marketInformationCTAText");

        [ImplementPropertyType("marketInformationTextArea")]
        public string MarketInformationTextArea => this.GetTranslatedPropertyValue<string>("marketInformationTextArea");

        [ImplementPropertyType("marketInformationTitle")]
        public string MarketInformationTitle => this.GetTranslatedPropertyValue<string>("marketInformationTitle");
    }
}
