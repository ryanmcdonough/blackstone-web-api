﻿// ReSharper disable InconsistentNaming
namespace Savills.Core.Models.GoogleMaps.Geocoding
{
    public class Location
    {
        public double lat { get; set; }
        public double lng { get; set; }
    }
}