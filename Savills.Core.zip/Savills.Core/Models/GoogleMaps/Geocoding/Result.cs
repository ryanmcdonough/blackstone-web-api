// ReSharper disable InconsistentNaming
using System.Collections.Generic;

namespace Savills.Core.Models.GoogleMaps.Geocoding
{
    public class Result
    {
        public List<AddressComponent> address_components { get; set; }
        public string formatted_address { get; set; }
        public Geometry geometry { get; set; }
        public string place_id { get; set; }
        public List<string> types { get; set; }
    }
}