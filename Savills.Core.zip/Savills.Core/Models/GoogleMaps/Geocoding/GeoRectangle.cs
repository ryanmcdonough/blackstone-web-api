// ReSharper disable InconsistentNaming
namespace Savills.Core.Models.GoogleMaps.Geocoding
{
    public class GeoRectangle
    {
        public double east { get; set; }
        public double north { get; set; }
        public double south { get; set; }
        public double west { get; set; }
    }
}