﻿// ReSharper disable InconsistentNaming
using System.Collections.Generic;

namespace Savills.Core.Models.GoogleMaps.Geocoding
{
    public class AddressComponent
    {
        public string long_name { get; set; }
        public string short_name { get; set; }
        public List<string> types { get; set; }
    }
}