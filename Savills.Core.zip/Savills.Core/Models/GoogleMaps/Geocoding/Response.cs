// ReSharper disable InconsistentNaming
using System.Collections.Generic;

namespace Savills.Core.Models.GoogleMaps.Geocoding
{
    public class Response
    {
        public List<Result> results { get; set; }
        public string status { get; set; }
    }
}