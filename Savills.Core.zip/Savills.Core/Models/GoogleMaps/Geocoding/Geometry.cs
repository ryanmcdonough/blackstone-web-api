// ReSharper disable InconsistentNaming
namespace Savills.Core.Models.GoogleMaps.Geocoding
{
    public class Geometry
    {
        public Location location { get; set; }
        public string location_type { get; set; }
        public GeoRectangle viewport { get; set; }
        public GeoRectangle bounds { get; set; }
    }
}