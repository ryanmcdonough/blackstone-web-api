﻿using Savills.Core.Extensions;
using Umbraco.ModelsBuilder;

namespace Savills.Core.Models
{
    public partial class ConfigurationContact
    {
        [ImplementPropertyType("telephone")]
        public string Telephone => this.GetTranslatedPropertyValue<string>("telephone");
        [ImplementPropertyType("eMailAddress")]
        public string EMailAddress => this.GetTranslatedPropertyValue<string>("eMailAddress");
        [ImplementPropertyType("addressLine1")]
        public string AddressLine1 => this.GetTranslatedPropertyValue<string>("addressLine1");
        [ImplementPropertyType("addressLine2")]
        public string AddressLine2 => this.GetTranslatedPropertyValue<string>("addressLine2");
        [ImplementPropertyType("addressLine3")]
        public string AddressLine3 => this.GetTranslatedPropertyValue<string>("addressLine3");
        [ImplementPropertyType("addressLine4")]
        public string AddressLine4 => this.GetTranslatedPropertyValue<string>("addressLine4");
        [ImplementPropertyType("addressPostcode")]
        public string AddressPostcode => this.GetTranslatedPropertyValue<string>("addressPostcode");
        [ImplementPropertyType("available")]
        public string Available => this.GetTranslatedPropertyValue<string>("available");

    }
}
