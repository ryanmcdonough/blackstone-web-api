﻿using Savills.Core.Models;
using Umbraco.ModelsBuilder;

[assembly: ModelsBaseClass(typeof(ModelBase))]