﻿using System;
using Newtonsoft.Json;
using Umbraco.ModelsBuilder;
using Umbraco.Web;

namespace Savills.Core.Models
{
    [Serializable()]
    public partial class Image
    {
        [ImplementPropertyType("umbracoFile")]
        public ImageCrop UmbracoFile => JsonConvert.DeserializeObject<ImageCrop>(this.GetPropertyValue<string>("imageData"));
    }
}