﻿using System;

namespace Savills.Core.Models
{
    public partial class PageYourReviews
    {
        public Guid ReviewToAdd { get; set; }
    }
}