﻿using Umbraco.ModelsBuilder;
using Umbraco.Web;

namespace Savills.Core.Models
{
    public partial class DataPlaceTypeDefaultRadius
    {
		///<summary>
		/// Radius
		///</summary>
		[ImplementPropertyType("radius")]
		public float? Radius => this.GetPropertyValue<float?>("radius");
    }
}