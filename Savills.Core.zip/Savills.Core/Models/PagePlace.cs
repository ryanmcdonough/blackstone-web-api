﻿using Epiphany.SeoMetadata;
using Savills.Core.Extensions;
using Umbraco.Core.Models;
using Umbraco.ModelsBuilder;

namespace Savills.Core.Models
{
    public partial class PagePlace
    {
        [ImplementPropertyType("landingMetadata")]
        public virtual SeoMetadata LandingMetadata
        {
            get
            {
                var metadata = this.GetTranslatedPropertyValue<SeoMetadata>("landingMetadata") ?? new SeoMetadata
                {
                    Title = "",
                    NoIndex = false,
                };

                return metadata;
            }
        }

        [ImplementPropertyType("landingTitle")]
        public string LandingTitle
        {
            get
            {
                var title = this.GetTranslatedPropertyValue<string>("landingTitle");

                return title;
            }
        }

        [ImplementPropertyType("landingContent")]
        public string LandingContent
        {
            get
            {
                var content = this.GetTranslatedPropertyValue<string>("landingContent");

                return content;
            }
        }

        [ImplementPropertyType("landingCanonicalOverride")]
        public IPublishedContent LandingCanonicalOverride => this.GetTranslatedPropertyValue<IPublishedContent>("landingCanonicalOverride");
    }
}
