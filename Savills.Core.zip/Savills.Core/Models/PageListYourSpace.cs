﻿using System.Collections.Generic;
using System.Linq;
using Savills.Core.Extensions;
using Umbraco.Core.Models;
using Umbraco.ModelsBuilder;

namespace Savills.Core.Models
{
    public partial class PageListYourSpace
    {
        /// <summary>
        ///     Bottom CTA Button Text
        /// </summary>
        [ImplementPropertyType("bottomCTAButtonText")]
        public string BottomCtabuttonText => this.GetTranslatedPropertyValue<string>("bottomCTAButtonText");

        /// <summary>
        ///     Bottom CTA Heading
        /// </summary>
        [ImplementPropertyType("bottomCTAHeading")]
        public string BottomCtaheading => this.GetTranslatedPropertyValue<string>("bottomCTAHeading");

        /// <summary>
        ///     Bottom CTA Text
        /// </summary>
        [ImplementPropertyType("bottomCTAText")]
        public string BottomCtatext => this.GetTranslatedPropertyValue<string>("bottomCTAText");

        /// <summary>
        ///     CTA Box Description
        /// </summary>
        [ImplementPropertyType("ctaBoxDescription")]
        public string CtaBoxDescription => this.GetTranslatedPropertyValue<string>("ctaBoxDescription");

        /// <summary>
        ///     CTA Box Button Text
        /// </summary>
        [ImplementPropertyType("ctaBoxButtonText")]
        public string CtaBoxButtonText => this.GetTranslatedPropertyValue<string>("ctaBoxButtonText");

        /// <summary>
        ///     CTA Box Heading
        /// </summary>
        [ImplementPropertyType("ctaBoxHeading")]
        public string CtaBoxHeading => this.GetTranslatedPropertyValue<string>("ctaBoxHeading");

        /// <summary>
        ///     CTA Description
        /// </summary>
        [ImplementPropertyType("ctaDescription")]
        public string CtaDescription => this.GetTranslatedPropertyValue<string>("ctaDescription");

        /// <summary>
        ///     CTA First Button Text
        /// </summary>
        [ImplementPropertyType("ctaFirstButtonText")]
        public string CtaFirstButtonText => this.GetTranslatedPropertyValue<string>("ctaFirstButtonText");

        /// <summary>
        ///     CTA Heading
        /// </summary>
        [ImplementPropertyType("ctaHeading")]
        public string CtaHeading => this.GetTranslatedPropertyValue<string>("ctaHeading");

        /// <summary>
        ///     CTA Image
        /// </summary>
        [ImplementPropertyType("ctaImage")]
        public Image CtaImage => this.GetTranslatedPropertyValue<Image>("ctaImage");

        /// <summary>
        ///     CTA Large Description
        /// </summary>
        [ImplementPropertyType("ctaLargeDescription")]
        public string CtaLargeDescription => this.GetTranslatedPropertyValue<string>("ctaLargeDescription");

        /// <summary>
        ///     FAQ Heading
        /// </summary>
        [ImplementPropertyType("faqHeading")]
        public string FaqHeading => this.GetTranslatedPropertyValue<string>("faqHeading");

        /// <summary>
        ///     FAQs
        /// </summary>
        [ImplementPropertyType("faqs")]
        public IEnumerable<DataGlossaryItem> Faqs
        {
            get
            {
                var dataGlossaryItems = this.GetTranslatedPropertyValue<IEnumerable<IPublishedContent>>("faqs")
                    .Select(a => new DataGlossaryItem(a));
                return dataGlossaryItems;
            }
        }

        /// <summary>
        ///     Hero Description
        /// </summary>
        [ImplementPropertyType("heroDescription")]
        public string HeroDescription => this.GetTranslatedPropertyValue<string>("heroDescription");

        /// <summary>
        ///     Hero First Button Text
        /// </summary>
        [ImplementPropertyType("heroFirstButtonText")]
        public string HeroFirstButtonText => this.GetTranslatedPropertyValue<string>("heroFirstButtonText");

        /// <summary>
        ///     Hero Heading
        /// </summary>
        [ImplementPropertyType("heroHeading")]
        public string HeroHeading => this.GetTranslatedPropertyValue<string>("heroHeading");

        /// <summary>
        ///     Hero Image
        /// </summary>
        [ImplementPropertyType("heroImage")]
        public Image HeroImage => this.GetTranslatedPropertyValue<Image>("heroImage");

        /// <summary>
        ///     Hero Second Button Text
        /// </summary>
        [ImplementPropertyType("heroSecondButtonText")]
        public string HeroSecondButtonText => this.GetTranslatedPropertyValue<string>("heroSecondButtonText");

        /// <summary>
        ///     Quote Author
        /// </summary>
        [ImplementPropertyType("quoteAuthor")]
        public string QuoteAuthor => this.GetTranslatedPropertyValue<string>("quoteAuthor");

        /// <summary>
        ///     Quote Author Description
        /// </summary>
        [ImplementPropertyType("quoteAuthorDescription")]
        public string QuoteAuthorDescription => this.GetTranslatedPropertyValue<string>("quoteAuthorDescription");

        /// <summary>
        ///     Quote Content
        /// </summary>
        [ImplementPropertyType("quoteContent")]
        public string QuoteContent => this.GetTranslatedPropertyValue<string>("quoteContent");

        /// <summary>
        ///     Quote Image
        /// </summary>
        [ImplementPropertyType("quoteImage")]
        public Image QuoteImage => this.GetTranslatedPropertyValue<Image>("quoteImage");

        /// <summary>
        ///     Steps
        /// </summary>
        [ImplementPropertyType("steps")]
        public IEnumerable<DataGlossaryItem> Steps
        {
            get
            {
                var dataGlossaryItems = this.GetTranslatedPropertyValue<IEnumerable<IPublishedContent>>("steps")
                    .Select(a => new DataGlossaryItem(a));
                return dataGlossaryItems;
            }
        }

        /// <summary>
        ///     Steps Heading
        /// </summary>
        [ImplementPropertyType("stepsHeading")]
        public string StepsHeading => this.GetTranslatedPropertyValue<string>("stepsHeading");

        /// <summary>
        ///     USP Heading
        /// </summary>
        [ImplementPropertyType("uspHeading")]
        public string UspHeading => this.GetTranslatedPropertyValue<string>("uspHeading");

        /// <summary>
        ///     USP Points
        /// </summary>
        [ImplementPropertyType("uspPoints")]
        public IEnumerable<DataRepeatableString> UspPoints
        {
            get
            {
                var uspPoints = this.GetTranslatedPropertyValue<IEnumerable<IPublishedContent>>("uspPoints")
                    .Select(a => new DataRepeatableString(a));
                return uspPoints;
            }
        }
    }
}