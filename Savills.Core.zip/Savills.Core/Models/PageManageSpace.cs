﻿using System.Collections.Generic;

namespace Savills.Core.Models
{
    public partial class PageYourSpaces
    {
        public List<PropertySpace> List { get; set; } = new List<PropertySpace>();
    }
}