﻿using Savills.Core.Extensions;
using Umbraco.ModelsBuilder;

namespace Savills.Core.Models
{
    public partial class PageBlogArticle
    {
        ///<summary>
        /// Summary: This is show on landing pages.
        ///</summary>
        [ImplementPropertyType("summary")]
        public string Summary => this.GetTranslatedPropertyValue<string>("summary");
    }
}