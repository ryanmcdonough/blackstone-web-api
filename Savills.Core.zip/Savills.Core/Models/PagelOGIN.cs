﻿using Savills.Core.ViewModels;

namespace Savills.Core.Models
{
    public partial class PageLogin
    {
        public LoginViewModel Action { get; set; } = new LoginViewModel();
    }
}