﻿using Epiphany.SeoMetadata;
using Savills.Core.Extensions;
using Umbraco.Core.Models;
using Umbraco.ModelsBuilder;

namespace Savills.Core.Models
{
    public partial class Page : IPage
    {
        [ImplementPropertyType("metadata")]
        public virtual SeoMetadata Metadata
        {
            get
            {
                var metadata = this.GetTranslatedPropertyValue<SeoMetadata>("metadata") ?? new SeoMetadata
                               {
                                   Title = Name,
                                   NoIndex = false
                               };

                return metadata;
            }
        }


        [ImplementPropertyType("title")]
        public string Title
        {
            get
            {
                var title = this.GetTranslatedPropertyValue<string>("title");

                return title;
            }
            set { }
        }

        [ImplementPropertyType("canonicalOverride")]
        public IPublishedContent CanonicalOverride => this.GetTranslatedPropertyValue<IPublishedContent>("canonicalOverride");
    }
}