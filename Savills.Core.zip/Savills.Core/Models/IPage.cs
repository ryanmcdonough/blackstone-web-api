﻿using Epiphany.SeoMetadata;
using Umbraco.Core.Models;

namespace Savills.Core.Models
{
    public interface IPage : IPublishedContent
    {
        SeoMetadata Metadata { get; }
        string Title { get; set; }

    }
}