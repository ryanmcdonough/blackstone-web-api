﻿using Savills.Core.Extensions;
using Umbraco.ModelsBuilder;
using Umbraco.Core.Models;

namespace Savills.Core.Models
{
    public partial class PageWhyUsHowItWorks
    {
        [ImplementPropertyType("journeyImage")]
        public IPublishedContent JourneyImage => this.GetTranslatedPropertyValue<IPublishedContent>("journeyImage");

        [ImplementPropertyType("journeyTitle")]
        public string JourneyTitle => this.GetTranslatedPropertyValue<string>("journeyTitle");

        [ImplementPropertyType("leftContent")]
        public string LeftContent => this.GetTranslatedPropertyValue<string>("leftContent");

        [ImplementPropertyType("leftImage")]
        public IPublishedContent LeftImage => this.GetTranslatedPropertyValue<IPublishedContent>("leftImage");

        [ImplementPropertyType("leftTitle")]
        public string LeftTitle => this.GetTranslatedPropertyValue<string>("leftTitle");

        [ImplementPropertyType("mainSubtitle")]
        public string MainSubtitle => this.GetTranslatedPropertyValue<string>("mainSubtitle");

        [ImplementPropertyType("rightContent")]
        public string RightContent => this.GetTranslatedPropertyValue<string>("rightContent");

        [ImplementPropertyType("rightImage")]
        public IPublishedContent RightImage => this.GetTranslatedPropertyValue<IPublishedContent>("rightImage");

        [ImplementPropertyType("rightTitle")]
        public string RightTitle => this.GetTranslatedPropertyValue<string>("rightTitle");

        [ImplementPropertyType("stepFiveText")]
        public string StepFiveText => this.GetTranslatedPropertyValue<string>("stepFiveText");

        [ImplementPropertyType("stepFiveTitle")]
        public string StepFiveTitle => this.GetTranslatedPropertyValue<string>("stepFiveTitle");

        [ImplementPropertyType("stepFourText")]
        public string StepFourText => this.GetTranslatedPropertyValue<string>("stepFourText");

        [ImplementPropertyType("stepFourTitle")]
        public string StepFourTitle => this.GetTranslatedPropertyValue<string>("stepFourTitle");

        [ImplementPropertyType("stepOneContent")]
        public string StepOneContent => this.GetTranslatedPropertyValue<string>("stepOneContent");

        [ImplementPropertyType("stepOneTitle")]
        public string StepOneTitle => this.GetTranslatedPropertyValue<string>("stepOneTitle");

        [ImplementPropertyType("stepThreeText")]
        public string StepThreeText => this.GetTranslatedPropertyValue<string>("stepThreeText");

        [ImplementPropertyType("stepThreeTitle")]
        public string StepThreeTitle => this.GetTranslatedPropertyValue<string>("stepThreeTitle");

        [ImplementPropertyType("stepTwoText")]
        public string StepTwoText => this.GetTranslatedPropertyValue<string>("stepTwoText");

        [ImplementPropertyType("stepTwoTitle")]
        public string StepTwoTitle => this.GetTranslatedPropertyValue<string>("stepTwoTitle");
    }
}