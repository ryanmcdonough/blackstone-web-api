﻿using Epiphany.SeoMetadata;
using Umbraco.Core.Models;
using Savills.Core.Helpers;

namespace Savills.Core.Models
{
    public interface IPageModel
    {
        IPublishedContent Content { get; }
        SeoMetadata Seo { get; }
        SettingsHelper Settings { get; }
        int SectionId { get; }

    }
}