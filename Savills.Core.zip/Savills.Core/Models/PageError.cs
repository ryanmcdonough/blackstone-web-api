﻿using Umbraco.ModelsBuilder;
using Savills.Core.Extensions;

namespace Savills.Core.Models
{
    public partial class PageError
    {
        [ImplementPropertyType("errorMessage")]
        public string ErrorMessage => this.GetTranslatedPropertyValue<string>("errorMessage");

        [ImplementPropertyType("featuredErrorLinkCTAText")]
        public string FeaturedErrorLinkCtatext => this.GetTranslatedPropertyValue<string>("featuredErrorLinkCTAText");
    }
}
