﻿using Epiphany.SeoMetadata;
using Umbraco.Web;
using Umbraco.Web.Models;
using Savills.Core.Helpers;

namespace Savills.Core.Models
{
    public class PageModel<T> : RenderModel<T>, IPageModel where T : class, IPage
    {
        // We cannot use generics with interfaces, so we have to use the IPageModel in the master layout
        // As a result, we expose the properties that the master template needs in the PageModel

        public PageModel(T content) : base(content)
        {
            Page = content as Page;
        }

        private Page Page { get; }

        public SeoMetadata Seo => Page.Metadata;
        public SettingsHelper Settings => SettingsHelper.Instance;

        public int SectionId
        {
            get
            {
                if (Content.Level == 1) return -1;
                return Content.AncestorOrSelf(2).Id;
            }
        }

    }
}