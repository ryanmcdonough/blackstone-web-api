﻿using System.Collections.Generic;
using System.Linq;
using Umbraco.Web;
using Umbraco.ModelsBuilder;
using Umbraco.Core.Models;

namespace Savills.Core.Models
{
    public partial class ConfigurationCurrency
    {
        [ImplementPropertyType("defaultCurrencies")]
        public IEnumerable<DataCurrencyMapping> DefaultCurrencies
        {
            get { return this.GetPropertyValue<IEnumerable<IPublishedContent>>("defaultCurrencies").Select(a => new DataCurrencyMapping(a)); }
        }
    }
}
