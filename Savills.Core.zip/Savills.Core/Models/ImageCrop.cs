﻿namespace Savills.Core.Models
{
    public class ImageCrop
    {
        public FocalPoint FocalPoint { get; set; }
        public string Src { get; set; }
        public Crop[] Crops { get; set; }
    }

    public struct FocalPoint
    {
        public decimal Left { get; set; }
        public decimal Right { get; set; }
    }

    public struct Crop
    {
        public string Alias { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public Coordinate Coordinates { get; set; }
    }

    public struct Coordinate
    {
        public decimal X1 { get; set; }
        public decimal Y1 { get; set; }
        public decimal X2 { get; set; }
        public decimal Y2 { get; set; }
    }
}