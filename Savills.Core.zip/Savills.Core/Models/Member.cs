﻿using System;
using Umbraco.Core;
using Umbraco.Core.Models;
using Umbraco.ModelsBuilder;
using Umbraco.Web;

namespace Savills.Core.Models
{
    [Serializable()]
    public partial class Member
    {
        ///<summary>
        /// Photo
        ///</summary>
        [ImplementPropertyType("photo")]
        public IPublishedContent Photo => this?.GetPropertyValue<IPublishedContent>("photo");

        ///<summary>
        /// Provider Profile
        ///</summary>
        public IContent ProviderContent
        {
            get
            {
                // Value is null!
                var providerIdPropertyValue = this?.GetProperty("providerID")?.DataValue as string;
                int providerId;

                if (!int.TryParse(providerIdPropertyValue, out providerId))
                {
                    return null;
                }

                // We need the value from the DB because the provider may nothave been published
                // (approved) yet!
                var providerContent = ApplicationContext.Current.Services.ContentService
                    .GetById(providerId);
                return providerContent;
            }
        }

    }
}