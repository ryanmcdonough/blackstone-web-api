﻿using Savills.Core.ViewModels;

namespace Savills.Core.Models
{
    public partial class PageListSpace
    {
        public ListPropertyViewModel PropertyDetail { get; set; } = new ListPropertyViewModel();
    }
}