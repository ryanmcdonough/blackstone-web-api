﻿using System;
using Savills.Core.Helpers;
using Umbraco.Core.Models;
using Umbraco.Core.Models.PublishedContent;
using Umbraco.Web;

namespace Savills.Core.Models
{
    public abstract class ModelBase : PublishedContentModel
    {
        private readonly Lazy<UmbracoHelper> _umbracoHelper = new Lazy<UmbracoHelper>(() => new UmbracoHelper(UmbracoContext.Current));

        protected ModelBase(IPublishedContent content) : base(content)
        {
        }

        public SettingsHelper Settings => SettingsHelper.Instance;

        public UmbracoHelper Umbraco => _umbracoHelper.Value;
    }
}