﻿using Savills.Core.Api.Models;

namespace Savills.Core.Models
{
    public partial class PageEnquiryComplete
    {
        public Enquiry Enquiry { get; set; } = new Enquiry();
    }
}