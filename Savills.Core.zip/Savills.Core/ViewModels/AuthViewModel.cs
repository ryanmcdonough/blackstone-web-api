﻿using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using Savills.Core.DataAnnotations;

namespace Savills.Core.ViewModels
{
    public class LoginViewModel
    {
        [UmbracoLocalisedDisplay("Forms.Login.Email.Display")]
        [DataType(DataType.EmailAddress)]
        [UmbracoLocalisedRequired("Forms.Login.Email.Required")]
        [UmbracoLocalisedEmail("Forms.Login.Email.Format")]
        public string EmailAddress { get; set; }

        [DataType(DataType.Password)]
        [UmbracoLocalisedDisplay("Forms.Login.Password.Display")]
        [UmbracoLocalisedRequired("Forms.Login.Password.Required")]
        public string Password { get; set; }

        [HiddenInput(DisplayValue = false)]
        public string ReturnUrl { get; set; }
    }

    /// <summary>
    /// Register View Model
    /// </summary>
    public class RegisterViewModel
    {
        [UmbracoLocalisedDisplay("Forms.Profile.FirstName.Display")]
        [UmbracoLocalisedRequired("Forms.Register.FirstName.Required")]
        public string FirstName { get; set; }

        [UmbracoLocalisedDisplay("Forms.Profile.LastName.Display")]
        [UmbracoLocalisedRequired("Forms.Register.LastName.Required")]
        public string LastName { get; set; }

        [UmbracoLocalisedDisplay("Forms.Profile.Telephone.Display")]
        [UmbracoLocalisedRequired("Forms.Register.Telephone.Required")]
        public string Telephone { get; set; }

        [UmbracoLocalisedDisplay("Forms.Profile.Email.Display")]
        [DataType(DataType.EmailAddress)]
        [UmbracoLocalisedRequired("Forms.Login.Email.Required")]
        [UmbracoLocalisedEmail("Forms.Login.Email.Format")]
        public string EmailAddress { get; set; }

        [DataType(DataType.Password)]
        [UmbracoLocalisedDisplay("Forms.Login.Password.Display")]
        [UmbracoLocalisedRequired("Forms.Login.Password.Required")]
        public string Password { get; set; }

        [UmbracoLocalisedDisplay("Forms.Profile.CommunicationsPreference.Display")]
        public string CommunicationsLanguage { get; set; }

        [UmbracoLocalisedDisplay("Forms.Profile.Currency.Display")]
        [UmbracoLocalisedRequired("Forms.Account.Currency.Required")]
        public string Currency { get; set; }

        [UmbracoLocalisedDisplay("Forms.Profile.Company.Display")]
        public string Company { get; set; }
    }

    //Forgotten Password View Model
    public class ForgottenPasswordViewModel
    {
        [UmbracoLocalisedDisplay("Forms.Login.Email.Display")]
        [UmbracoLocalisedRequired("Forms.Login.Email.Required")]
        [UmbracoLocalisedEmail("Forms.Login.Email.Format")]
        public string EmailAddress { get; set; }
    }

    //Reset Password View Model
    public class ResetPasswordViewModel
    {
        [UmbracoLocalisedDisplay("Forms.Login.Email.Display")]
        [UmbracoLocalisedRequired("Forms.Login.Email.Required")]
        [UmbracoLocalisedEmail("Forms.Login.Email.Format")]
        public string EmailAddress { get; set; }

        [DataType(DataType.Password)]
        [UmbracoLocalisedDisplay("Forms.Login.Password.Display")]
        [UmbracoLocalisedRequired("Forms.Login.Password.Required")]
        public string Password { get; set; }
    }
}