﻿using Savills.Core.DataAnnotations;

namespace Savills.Core.ViewModels
{
    public class AddReviewViewModel
    {
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        [UmbracoLocalisedRange(1, 5, "Forms.PropertyReview.Range15")]
        public int OverallRating { get; set; }

        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        [UmbracoLocalisedRange(1, 5, "Forms.PropertyReview.Range15")]
        public int BuildingRating { get; set; }

        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        [UmbracoLocalisedRange(1, 5, "Forms.PropertyReview.Range15")]
        public int ProviderRating { get; set; }

        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        [UmbracoLocalisedRange(1, 5, "Forms.PropertyReview.Range15")]
        public int FacilitiesRating { get; set; }

        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public string Review { get; set; }

        public string PropertyName { get; set; }
    }
}