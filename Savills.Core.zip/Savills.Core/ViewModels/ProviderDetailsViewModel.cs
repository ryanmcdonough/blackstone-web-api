﻿using System.Web;
using Savills.Core.DataAnnotations;

namespace Savills.Core.ViewModels
{
    public class ProviderDetailsViewModel
    {
        public int Id { get; set; }
        [UmbracoLocalisedDisplay("Forms.Profile.Provider.Name.Display")]
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public string Name { get; set; }

        public string Description { get; set; }

        public string CurrentLogo { get; set; }

        public HttpPostedFileWrapper Logo { get; set; }

        public bool IsPendingApproval { get; set; }
    }
}