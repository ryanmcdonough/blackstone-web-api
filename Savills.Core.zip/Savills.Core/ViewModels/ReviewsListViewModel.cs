﻿using Savills.Core.DataModels;
using System.Collections.Generic;

namespace Savills.Core.ViewModels
{
    public class ReviewsListViewModel
    {
        public List<AwaitingReview> PendingReviews { get; set; }

        public List<PendingReview> ReviewsAwaitingApproval { get; set; }

        public List<PendingReview> LiveReviews { get; set; }

        public ReviewsListViewModel()
        {
            PendingReviews = new List<AwaitingReview>();
            ReviewsAwaitingApproval = new List<PendingReview>();
            LiveReviews = new List<PendingReview>();
        }
    }
}