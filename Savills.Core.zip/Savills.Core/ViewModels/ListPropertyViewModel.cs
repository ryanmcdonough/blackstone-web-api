﻿using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using Savills.Core.DataAnnotations;
using Savills.Core.PropertyEditors.Facilties;
using Savills.Core.PropertyEditors.SpaceEditor;

namespace Savills.Core.ViewModels
{
    public class ListPropertyViewModel
    {
        public int Id { get; set; }

        [UmbracoLocalisedDisplay("Forms.Property.Name.Display")]
        public List<Title> Name { get; set; } = new List<Title>();
        public List<Space> Spaces { get; set; } = new List<Space>();
        public List<Description> Descriptions { get; set; } = new List<Description>();
        [UmbracoLocalisedDisplay("Forms.Property.AddressLine1.Display")]
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public string AddressLine1 { get; set; }
        [UmbracoLocalisedDisplay("Forms.Property.AddressLine2.Display")]
        public string AddressLine2 { get; set; }
        [UmbracoLocalisedDisplay("Forms.Property.AddressLine3.Display")]
        public string AddressLine3 { get; set; }
        [UmbracoLocalisedDisplay("Forms.Property.AddressCity.Display")]
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public string AddressCity { get; set; }
        [UmbracoLocalisedDisplay("Forms.Property.AddressPostcode.Display")]
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public string AddressCounty { get; set; }
        [UmbracoLocalisedDisplay("Forms.Property.AddressCounty.Display")]
        public string AddressCountry { get; set; }
        [UmbracoLocalisedDisplay("Forms.Property.AddressCoutnry.Display")]
        public string AddressPostcode { get; set; }
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public string AddressLatitude { get; set; }
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public string AddressLongitude { get; set; }
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public Facilities Facilties { get; set; } = new Facilities();

        public HttpPostedFileWrapper Photo1 { get; set; }
        public HttpPostedFileWrapper Photo2 { get; set; }
        public HttpPostedFileWrapper Photo3 { get; set; }
        public HttpPostedFileWrapper Photo4 { get; set; }
        public HttpPostedFileWrapper Photo5 { get; set; }
        public HttpPostedFileWrapper Photo6 { get; set; }
        public List<string> CurrentPhotos { get; set; } = new List<string>();
        public ProviderDetailsViewModel Provider { get; set; }
        public string RelativeLink { get; set; }
        public string Currency { get; set; }
    }

    public class Description
    {
        [UmbracoLocalisedDisplay("Forms.Property.Language.Display")]
        public string LanguageCode { get; set; }
        [AllowHtml]
        [UmbracoLocalisedDisplay("Forms.Property.Description.Display")]
        public string Content { get; set; }

    }

    public class Title
    {
        [UmbracoLocalisedDisplay("Forms.Property.Language.Display")]
        public string LanguageCode { get; set; }
        [UmbracoLocalisedDisplay("Forms.Property.Title.Display")]
        public string Content { get; set; }

    }

}