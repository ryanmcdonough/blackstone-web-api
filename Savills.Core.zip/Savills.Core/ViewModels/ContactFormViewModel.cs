﻿using Savills.Core.DataAnnotations;

namespace Savills.Core.ViewModels
{
    public class ContactFormViewModel
    {
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public string Enquiry { get; set; }
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public string EmailAddress { get; set; }
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public string FirstName { get; set; }
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public string LastName { get; set; }
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public string PhoneNumber { get; set; }
        public string Company { get; set; }
    }
}