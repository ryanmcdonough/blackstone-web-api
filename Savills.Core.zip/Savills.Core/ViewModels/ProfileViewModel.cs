﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Web;
using System.Web.Mvc;
using Savills.Core.DataAnnotations;

namespace Savills.Core.ViewModels
{
    public class ProfileViewModel
    {
        [UmbracoLocalisedDisplay("Forms.Profile.FirstName.Display")]
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public string FirstName { get; set; }
        [UmbracoLocalisedDisplay("Forms.Profile.LastName.Display")]
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public string LastName { get; set; }

        [UmbracoLocalisedDisplay("Forms.Profile.Email.Display")]
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        [UmbracoLocalisedEmail("Forms.Profile.Email.Required")]
        public string EmailAddress { get; set; }

        [DataType(DataType.Password)]
        [UmbracoLocalisedDisplay("Forms.Profile.Password.Old.Display")]
        public string OldPassword { get; set; }

        [DataType(DataType.Password)]
        [UmbracoLocalisedDisplay("Forms.Profile.Password.New.Display")]
        public string NewPassword { get; set; }

        [UmbracoLocalisedDisplay("Forms.Profile.Telphone.Display")]
        public string Telephone { get; set; }

        [UmbracoLocalisedDisplay("Forms.Profile.Company.Display")]
        public string Company { get; set; }

        [UmbracoLocalisedDisplay("Forms.Profile.CommunicationLanguage.Display")]
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public string CommunicationsLanguage { get; set; }

        [UmbracoLocalisedDisplay("Forms.Profile.Currency.Display")]
        [UmbracoLocalisedRequired("Forms.Generic.Required")]
        public string Currency { get; set; }

        [UmbracoLocalisedDisplay("Forms.Profile.RecieveMarketingEmails.Display")]
        public bool RecieveMarketingEmails { get; set; }

        [UmbracoLocalisedDisplay("Forms.Profile.ReceiveEmails.Display")]
        public bool ReceiveEmails { get; set; }

        [UmbracoLocalisedDisplay("Forms.Profile.Photo.Display")]
        public string CurrentPhoto { get; set; }

        public HttpPostedFileWrapper Photo { get; set; }

        public ProviderDetailsViewModel Provider { get; set; }
    }

    public class ViewProfileViewModel
    {
        [HiddenInput(DisplayValue = false)]
        public int MemberId { get; set; }

        [UmbracoLocalisedDisplay("Forms.Register.Name.Display")]
        [UmbracoLocalisedRequired("Forms.Register.Name.Required")]
        public string Name { get; set; }

        [UmbracoLocalisedDisplay("Forms.Login.Email.Display")]
        [DataType(DataType.EmailAddress)]
        [UmbracoLocalisedRequired("Forms.Login.Email.Required")]
        [UmbracoLocalisedEmail("Forms.Login.Email.Format")]
        public string EmailAddress { get; set; }

        [HiddenInput(DisplayValue = false)]
        public string MemberType { get; set; }

        public DateTime LastLoginDate { get; set; }

        public int NumberOfLogins { get; set; }

        public int NumberOfProfileViews { get; set; }
    }
}