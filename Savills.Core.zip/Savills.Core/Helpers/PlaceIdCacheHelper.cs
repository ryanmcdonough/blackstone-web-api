﻿using System.Collections.Generic;
using System.Linq;
using Savills.Core.Models;
using Umbraco.Web;
using Umbraco.Web.Cache;

namespace Savills.Core.Helpers
{
    public class PlaceIdCacheHelper : ResettableLazy<PlaceIdCacheHelper>
    {
        static PlaceIdCacheHelper()
        {
            PageCacheRefresher.CacheUpdated += (sender, e) => Lazy.ResetValue();
        }

        public PlaceIdCacheHelper()
        {
            GeoShapeIdToPlaceId = GetGeoShapeIdToPlaceId();
        }

        public Dictionary<string, List<string>> GeoShapeIdToPlaceId { get; set; }

        private static Dictionary<string, List<string>> GetGeoShapeIdToPlaceId()
        {
            var pagePlaces = UmbracoContext.Current.ContentCache
                .GetByXPath($"//{PagePlace.ModelTypeAlias}")
                .Cast<PagePlace>();
            var geoShapeIdToPlaceId = pagePlaces
                .ToDictionary(k => k.GeoLocationID, v => v.GoogleMapsPlaceIds.ToList());

            return geoShapeIdToPlaceId;
        }
    }
}