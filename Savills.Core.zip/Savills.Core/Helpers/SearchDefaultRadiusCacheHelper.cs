﻿using System.Collections.Generic;
using System.Linq;
using Savills.Core.Models;
using Umbraco.Web;
using Umbraco.Web.Cache;

namespace Savills.Core.Helpers
{
    public class SearchDefaultRadiusCacheHelper : ResettableLazy<SearchDefaultRadiusCacheHelper>
    {
        static SearchDefaultRadiusCacheHelper()
        {
            PageCacheRefresher.CacheUpdated += (sender, e) => Lazy.ResetValue();
        }

        public SearchDefaultRadiusCacheHelper()
        {
            PlaceTypeDefaultRadiuses = GetPlaceTypeDefaultRadius();
        }

        public Dictionary<string, float?> PlaceTypeDefaultRadiuses { get; set; }

        private static Dictionary<string, float?> GetPlaceTypeDefaultRadius()
        {
            var configurationSearch = UmbracoContext.Current.ContentCache
                .GetSingleByXPath($"//{ConfigurationSearch.ModelTypeAlias}") as ConfigurationSearch;
            var placeTypeDefaultRadiuses = configurationSearch?
                .PlaceTypeDefaultRadiuses
                .ToDictionary(k => k.PlaceType, v => v.Radius);

            return placeTypeDefaultRadiuses;
        }
    }
}