﻿using System.Net.Mail;
using System.Net.Mime;
using System.Web;

namespace Savills.Core.Helpers
{
    public class EmailHelper
    {
        //private const string SendGridUsername   = "sendGridUsername";
        //private const string SendGridPassword   = "sendGridPassword";
        private const string EmailFromAddress = "you@yoursite.com";

        public void SendResetPasswordEmail(string memberEmail, string resetGuid)
        {
            //Send a reset email to member
            // Create the email object first, then add the properties.
            var myMessage = new MailMessage(EmailFromAddress, memberEmail);

            //Subject
            myMessage.Subject = "Reset your password";

            myMessage.IsBodyHtml = true;

            //Reset link
            string baseUrl = HttpContext.Current.Request.Url.AbsoluteUri.Replace(HttpContext.Current.Request.Url.AbsolutePath, string.Empty);
            var resetUrl = baseUrl + "/dashboard/reset-password?resetGUID=" + resetGuid;

            //HTML Message
            string body = string.Format(
                                "<h3>Reset Your Password</h3>" +
                                "<p>You have requested to reset your password<br/>" +
                                "If you have not requested to reste your password, simply ignore this email and delete it</p>" +
                                "<p><a href='{0}'>Reset your password</a></p>",
                                resetUrl);

            myMessage.Body = body;

            //PlainText Message
            ContentType mimeType = new ContentType("text/html");
            // Add the alternate body to the message.

            AlternateView alternate = AlternateView.CreateAlternateViewFromString(body, mimeType);
            myMessage.AlternateViews.Add(alternate);

            // Create an SMTP transport for sending email.
            var transportSmtp = new SmtpClient();

            // Send the email.
            transportSmtp.Send(myMessage);
        }

        public void SendVerifyEmail(string memberEmail, string verifyGuid)
        {
            //Send a reset email to member
            // Create the email object first, then add the properties.
            var myMessage = new MailMessage(EmailFromAddress, memberEmail);

            //Subject
            myMessage.Subject = "Verify Your Email";

            myMessage.IsBodyHtml = true;

            //Verify link
            string baseUrl = HttpContext.Current.Request.Url.AbsoluteUri.Replace(HttpContext.Current.Request.Url.AbsolutePath, string.Empty);
            var verifyUrl = baseUrl + "/dashboard/verify-email?verifyGUID=" + verifyGuid;

            //HTML Message
            string body = string.Format(
                                "<h3>Verify Your Email</h3>" +
                                "<p>Click here to verify your email address and active your account today</p>" +
                                "<p><a href='{0}'>Verify your email & active your account</a></p>",
                                verifyUrl);

            myMessage.Body = body;

            //PlainText Message
            ContentType mimeType = new ContentType("text/html");
            // Add the alternate body to the message.

            AlternateView alternate = AlternateView.CreateAlternateViewFromString(body, mimeType);
            myMessage.AlternateViews.Add(alternate);

            // Create an SMTP transport for sending email.
            var transportSmtp = new SmtpClient();

            // Send the email.
            transportSmtp.Send(myMessage);
        }
    }
}
