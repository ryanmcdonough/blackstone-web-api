﻿using Savills.Core.Models;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using Umbraco.Core;
using Umbraco.Web;

namespace Savills.Core.Helpers
{
    public static class ModelsHelper
    {
        //get the model for the language switcher
        public static List<SwitcherLanguage> GetLanguageSwitcherModel()
        {
            var model = new List<SwitcherLanguage>();

            var supportedLanguages = LanguageHelper.GetSupportedLanguageCodes();

            var currentCultureCode = UmbracoContext.Current.PublishedContentRequest.Culture.Name;

            var currentUrl = UmbracoContext.Current.PublishedContentRequest.PublishedContent.UrlWithDomain();

            //special case for the SEO Landing pages, as they can have different URLS
            if (UmbracoContext.Current.PublishedContentRequest.PublishedContent is PageSeolanding)
            {
                var page = UmbracoContext.Current.PublishedContentRequest.PublishedContent as PageSeolanding;

                if (page.IsVirtualLandingPage)
                {
                    currentUrl = currentUrl + LanguageHelper.GetAlternateUrl(page.Place.Url, LanguageHelper.DefaultLanguage).Substring(1);
                }
            }

            foreach (var language in supportedLanguages)
            {
                var culture = new CultureInfo(language);

                var item = new SwitcherLanguage() {
                    LanguageCode = culture.Name.ToLowerInvariant(),
                    LanguageName = culture.NativeName,
                    IsCurrentLanguage = culture.Name.Equals(currentCultureCode, StringComparison.OrdinalIgnoreCase),
                    RedirectUrl = LanguageHelper.GetAlternateUrl(currentUrl, culture.Name)
                };

                model.Add(item);
            }

            return model;
        }

        public static List<SwitcherCurrency> GetCurrencySwitcherModel()
        {
            var model = new List<SwitcherCurrency>();

            var supportedLanguages = CurrencyHelper.GetSupportedCurrencyCodes();

            var currentCultureCode = UmbracoContext.Current.PublishedContentRequest.Culture.Name;

            var currentUrl = UmbracoContext.Current.PublishedContentRequest.PublishedContent.UrlWithDomain();

            foreach (var language in supportedLanguages)
            {
                var item = new SwitcherCurrency()
                {
                    CurrencyCode = language.ToUpper(),
                    CurrencyName = CurrencyCodeHelper.GetSymbol(language.ToUpper()) + " (" + language.ToUpper() + ")",
                    RedirectUrl = LanguageHelper.GetAlternateUrl(currentUrl, currentCultureCode)
                };

                if (item.CurrencyCode == LanguageHelper.GetCurrentCurrency())
                {
                    item.IsCurrentCurrency = true;
                }

                model.Add(item);
            }

            return model;
        }


        //get the model for the language warning
        public static LanguageWarning GetLanguageWarningModel()
        {
            var languageCodes = LanguageHelper.GetSupportedLanguageCodes().ToImmutableArray();

            var model = new LanguageWarning
            {
                AvailableLanguages   = GetLanguageWarningLanguages(languageCodes),
                ShouldDisplayWarning = LanguageHelper.ShouldDisplayWarning()
            };


            //only populate the dictionary text if we need to diplay it, keeps method efficient
            if (model.ShouldDisplayWarning)
            {
                var userLanguage = LanguageHelper.GetUserBrowserLanguageCode();

                var dictionary = LanguageHelper.GetAlternateCultureDictionary(userLanguage);

                model.WarningMessage = dictionary["Languages.WarningMessage"];
                model.YesButtonText = dictionary["Languages.YesButton"];
                model.NoButtonText = dictionary["Languages.NoButton"];

                model.NativeLanguageUrl = LanguageHelper.GetAlternateUrl(UmbracoContext.Current.PublishedContentRequest.PublishedContent.Url, userLanguage);
            }

            return model;
        }

        public static IList<LanguageWarningLanguage> GetLanguageWarningLanguages(ImmutableArray<string> languageCodes)
        {
            // E.g. turns "English (United States)" into "United States (English)".
            // If no culture part, just returns language.
            // Pure.
            Func<string, string> swapLanguageAndCultureStrings = languageString =>
            {
                // Returns value of the first grouping, or string.Empty if there isn't one.
                // Pure.
                Func<string, string, string> firstMatchOrEmpty = (input, pattern) =>
                {
                    var cultureRegexMatch = Regex.Match(input, pattern);

                    if (cultureRegexMatch.Success && cultureRegexMatch.Groups.Count >= 2)
                    {
                        return cultureRegexMatch.Groups[1].Value.Trim();
                    }

                    return string.Empty;
                };

                // Anything before an open parenthesis.
                var language = firstMatchOrEmpty(languageString, @"(.*)\(");

                // Anything in parentheses.
                var culture  = firstMatchOrEmpty(languageString, @"\((.*)\)");

                var swappedString = culture.IsNullOrWhiteSpace()
                    ? language
                    : $"{culture} ({language})";

                return swappedString;
            };

            Func<string, string> getFlagUrl = twoLetterIsoRegionName =>
            {
                var flagUrl = "https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/2.8.0/flags/4x3/" +
                              $"{twoLetterIsoRegionName.ToLower()}.svg";

                return flagUrl;
            };


            var availableLanguages = languageCodes
                .Select(languageCode =>
                {
                    var culture = new CultureInfo(languageCode);
                    var region  = new RegionInfo(languageCode);

                    var currentUrl = UmbracoContext.Current.PublishedContentRequest.PublishedContent.Url;

                    var languageWarningLanguage = new LanguageWarningLanguage(
                        code:        culture.Name,
                        displayName: swapLanguageAndCultureStrings(culture.NativeName),
                        flagUrl:     getFlagUrl(region.TwoLetterISORegionName),
                        currentUrl:  LanguageHelper.GetAlternateUrl(currentUrl, culture.Name)
                    );

                    return languageWarningLanguage;

                })
                .ToList();

            return availableLanguages;
        }

        /// <summary>
        /// Gets all of the alternate language links for a specified page 
        /// </summary>
        /// <param name="currentUrl"></param>
        /// <param name="currentLanguage"></param>
        /// <returns></returns>
        public static List<AlternateLink> GetAlternateUrls(string currentUrl, string currentLanguage)
        {
            var model = new List<AlternateLink>();

            foreach (var language in LanguageHelper.GetSupportedLanguageCodes())
            {
                if (language != currentLanguage)
                {
                    model.Add(new AlternateLink() {
                        Language = language,
                        Link = LanguageHelper.GetAlternateUrl(currentUrl, language)
                    });
                }
            }

            return model;
        }
    }
}
