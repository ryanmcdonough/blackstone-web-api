﻿using System;
using System.Web;
using Umbraco.Web;
using Umbraco.Web.Security;

namespace Savills.Core.Helpers
{
    public static class BasketHelper
    {
        /// <summary>
        /// gets the user id for the current user's basket (either the member's ID or the cookie GUID for anonymous users)
        /// </summary>
        /// <returns></returns>
        public static string GetBasketUserId()
        {
            var memberId = GetMemberId();

            if (memberId == -1)
            {
                return GetAnonymousUserId();
            }

            return memberId.ToString();
        }

        /// <summary>
        /// Get the current member Id
        /// </summary>
        /// <returns></returns>
        public static int GetMemberId()
        {
            var memberHelper = new MembershipHelper(UmbracoContext.Current);

            return memberHelper.GetCurrentMemberId();
        }

        /// <summary>
        /// Get the anonymous user id
        /// </summary>
        /// <returns></returns>
        public static string GetAnonymousUserId()
        {
            var cookieKey = "basketId";

            var cookie = HttpContext.Current.Request.Cookies[cookieKey];

            if (!string.IsNullOrEmpty(cookie?.Value))
            {
                return cookie.Value;
            }
            else
            {
                var userId = Guid.NewGuid();

                var basketCookie = new HttpCookie(cookieKey, userId.ToString());

                basketCookie.HttpOnly = false;
                basketCookie.Expires = DateTime.Now.AddDays(90);

                HttpContext.Current.Response.Cookies.Add(basketCookie);

                return userId.ToString();
            }
        }
    }
}
