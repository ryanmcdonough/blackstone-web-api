﻿using Savills.Core.CacheProvider;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Umbraco.Core;
using Umbraco.Core.Cache;
using Umbraco.Web;
using Umbraco.Web.Dictionary;
using Umbraco.Web.Security;

namespace Savills.Core.Helpers
{
    public class LanguageHelper
    {
        private const string AllowedLanguageCodesKey = "allowedLanguageCodes";
        private const string AllowedLanguagesConfigKey = "Savills.AllowedLanguages";
        private const string SupportedLanguageCodesKey = "supportedLanguageCodes";
        public const string LanguageCookieKey = "languageConfirmed";
        private const string DefaultLanguageConfigKey = "Savills.DefaultLanguage";

        private const string AllowedCurrencyConfigKey = "Savills.AllowedCurrency";
        private const string SupportedCurrencyCodesKey = "supportedCurrencyCodes";
        private const string DefaultCurrencyConfigKey = "Savills.DefaultCurrency";
        private const string CurrencyCookieKey = "siteCurrency";

        public const string LanguageUrlsCache = "languageUrls";

        /// <summary>
        /// gets the default language that's set for the website
        /// </summary>
        public static string DefaultLanguage => ConfigurationManager.AppSettings[DefaultLanguageConfigKey];

        /// <summary>
        /// gets the default language that's set for the website
        /// </summary>
        public static string DefaultCurrency => ConfigurationManager.AppSettings[DefaultCurrencyConfigKey];


        /// <summary>
        /// Gets a list of the locale names of the alternate languages that are supported by the site
        /// </summary>
        /// <returns></returns>
        public static string[] GetAllowedLanguageCodes()
        {
            return
                ApplicationContext.Current.ApplicationCache.RequestCache.GetCacheItem<string[]>(
                    AllowedLanguageCodesKey,
                    () => ConfigurationManager.AppSettings[AllowedLanguagesConfigKey]
                        .Split(',')
                        .Select(l => l.Trim())
                        .ToArray());
        }

        /// <summary>
        /// Gets all of the supported language codes (basically the same as allowed, plus default)
        /// </summary>
        /// <returns></returns>
        public static string[] GetSupportedLanguageCodes()
        {
            return
                ApplicationContext.Current.ApplicationCache.RequestCache.GetCacheItem<string[]>(
                    SupportedLanguageCodesKey,
                    () =>
                        (DefaultLanguage
                            + ","
                            + ConfigurationManager.AppSettings[AllowedLanguagesConfigKey])
                                .Split(',')
                                .Select(l => l.Trim())
                                .ToArray());
        }


        /// <summary>
        /// Get the full CultureInfo object from a language code
        /// </summary>
        /// <param name="languageCode"></param>
        /// <returns></returns>
        public static CultureInfo GetLocaleFromCode(string languageCode)
        {
            return CultureInfo.CreateSpecificCulture(languageCode.ToLower().Trim());
        }

        /// <summary>
        /// Gets the preferred language code of the user's browser
        /// </summary>
        /// <returns></returns>
        public static string GetUserBrowserLanguageCode()
        {
            var browserLanguages = HttpContext.Current.Request.UserLanguages;

            if (browserLanguages == null) return string.Empty;

            var language = browserLanguages[0].ToLower().Trim();

            //if just set to English, assume they're the default english language
            if (language == "en") language = DefaultLanguage;

            //if single digit code, make it use the same format as Umbraco
            if (language.Length == 2) language = string.Format("{0}-{0}", language);

            return language;
        }

        /// <summary>
        /// Checks if a language code is allowed on the website
        /// </summary>
        /// <param name="languageCode"></param>
        /// <returns></returns>
        public static bool IsAllowedLanguage(string languageCode)
        {
            var allowedLanguages = GetAllowedLanguageCodes();

            return allowedLanguages.Any(a => a.Equals(languageCode, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// Checks for SUPPORTED languages, same as allowed languages, but with british english as well
        /// </summary>
        /// <param name="languageCode"></param>
        /// <returns></returns>
        public static bool IsSupportedLanguage(string languageCode)
        {
            return GetSupportedLanguageCodes().Any(a => a.Equals(languageCode, StringComparison.OrdinalIgnoreCase) || a.StartsWith(languageCode + "-", StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// check to see if the language confirmation cookie is already set, and that we're on the default language site
        /// </summary>
        /// <returns></returns>
        public static bool ShouldCheckForDifferentLanguages()
        {
            return HttpContext.Current.Request.Cookies[LanguageCookieKey] == null && UmbracoContext.Current.PublishedContentRequest.Culture.Name.Equals(DefaultLanguage, StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Check to see if the language warniong should be displayed or not
        /// </summary>
        /// <returns></returns>
        public static bool ShouldDisplayWarning()
        {
            //if cookie is already set, we assume they know what they're doing
            if (ShouldCheckForDifferentLanguages())
            {
                if (!UrlHasSupportedCulture())
                {
                    //now we need to get the current user's language and if it's supported,and if so, see if there's a mismatch
                    var userLanguage = GetUserBrowserLanguageCode();

                    if (IsSupportedLanguage(userLanguage) &&
                        !userLanguage.Equals(UmbracoContext.Current.PublishedContentRequest.Culture.Name,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private static bool UrlHasSupportedCulture()
        {
            var culturePartOfUrl = HttpContext.Current.Request.Path
                    .Where(c => char.IsLetterOrDigit(c) || char.IsWhiteSpace(c) || c == '-')
                    .ToArray();

            string urlCulture = new string(culturePartOfUrl);

            return IsSupportedLanguage(urlCulture);
        }

        /// <summary>
        /// sets the cookie to say that a language has been confirmed (used when there is a language mismatch)
        /// </summary>
        public static void SetLanguageCheckCookie()
        {
            var cookie = new HttpCookie(LanguageCookieKey, "1");

            HttpContext.Current.Response.Cookies.Add(cookie);
        }

        /// <summary>
        /// Gets the value of an Umbraco dictionary item for a specific locale
        /// </summary>
        /// <param name="key"></param>
        /// <param name="cultureName"></param>
        /// <remarks>Use with care, hits the database! Normal Umbraco dictionary methods should suffice for most instances</remarks>
        /// <returns></returns>
        public static string GetDictionaryValueForSpecificLocale(string key, string cultureName)
        {
            //create a new culture dictionary for the selected culture (this should be cached and faster than direct DB)
            var cultureDictionary = GetAlternateCultureDictionary(cultureName);

            var translation = cultureDictionary[key];

            if (!string.IsNullOrEmpty(translation)) return translation;

            return key;
        }

        /// <summary>
        /// Gets the value of an Umbraco dictionary item for a current locale
        /// </summary>
        /// <param name="key"></param>
        /// <remarks>Use with care, hits the database! Normal Umbraco dictionary methods should suffice for most instances</remarks>
        /// <returns></returns>
        public static string GetDictionaryValueForCurrentLocale(string key)
        {
            //create a new culture dictionary for the selected culture (this should be cached and faster than direct DB)
            var cultureDictionary = GetAlternateCultureDictionary(CultureInfo.CurrentCulture.Name);

            var translation = cultureDictionary[key];

            if (translation == key || string.IsNullOrEmpty(translation))
            {
                //not found in current language, fall back to default one
                return GetDictionaryValueForSpecificLocale(key, DefaultLanguage);
            }

            return translation;
        }


        /// <summary>
        /// Get a culture dictionary for a language other than the current one
        /// </summary>
        /// <param name="cultureName"></param>
        /// <returns></returns>
        public static DefaultCultureDictionary GetAlternateCultureDictionary(string cultureName)
        {
            return new DefaultCultureDictionary(new CultureInfo(cultureName),
                ApplicationContext.Current.Services.LocalizationService, new LanguageCacheProvider(cultureName));
        }

        /// <summary>
        /// Works out the alternate URL for a page, for a given language code
        /// </summary>
        /// <param name="url"></param>
        /// <param name="cultureName"></param>
        /// <returns></returns>
        public static string GetAlternateUrl(string url, string cultureName)
        {
            cultureName = cultureName.ToLower();

            var isDefaultLanguage = cultureName.Equals(DefaultLanguage, StringComparison.OrdinalIgnoreCase);

            var mustStripLanguage = true;

            //if not in the front end, assume the language is english
            var currentCultureName = UmbracoContext.Current.PublishedContentRequest != null
                ? UmbracoContext.Current.PublishedContentRequest.Culture.Name
                : DefaultLanguage;

            if (currentCultureName.Equals(DefaultLanguage, StringComparison.OrdinalIgnoreCase))
            {
                if (isDefaultLanguage) return url;

                mustStripLanguage = false;
            }

            if (!url.StartsWith("http"))
            {
                var path = url;

                if (mustStripLanguage)
                {
                    path = path.Substring(6);
                }

                if (!isDefaultLanguage)
                {
                    path = string.Concat("/", cultureName, path);
                }

                return path;
            }
            else
            {
                var builder = new UriBuilder(url);

                if (mustStripLanguage)
                {
                    builder.Path = builder.Path.Substring(builder.Path.Length == 6 ? 5 : 6);
                }

                if (!isDefaultLanguage)
                {
                    builder.Path = string.Concat("/", cultureName, builder.Path);
                }

                return builder.ToString();
            }
        }

        /// <summary>
        /// Get a list of all of the supported languages in a format suitable for using in MVC forms
        /// </summary>
        /// <returns></returns>
        public static List<SelectListItem> GetSupportedLanguagesDropdownItems()
        {
            var list = new List<SelectListItem>();

            var supportedLanguges = GetSupportedLanguageCodes();

            foreach (var language in supportedLanguges)
            {
                var culture = new CultureInfo(language);

                list.Add(new SelectListItem()
                {
                    Text = culture.NativeName,
                    Value = culture.Name
                });
            }

            return list;
        }


        /// <summary>
        /// Get a list of all of the supported languages in a format suitable for using in MVC forms
        /// </summary>
        /// <returns></returns>
        public static List<SelectListItem> GetSupportedCurrencyDropdownItems()
        {
            var list = new List<SelectListItem>();

            var supportedLanguges = CurrencyHelper.GetSupportedCurrencyCodes();

            foreach (var language in supportedLanguges)
            {
                //var culture = new CultureInfo(language);

                list.Add(new SelectListItem()
                {
                    Text = language,
                    Value = language
                });
            }

            return list;
        }


        /// <summary>
        ///     Gets the display currency wanted by the user
        /// </summary>
        /// <returns></returns>
        public static string GetCurrentCurrency()
        {
            return new Savills.Core.Helpers.CurrencyHelper(UmbracoContext.Current, UmbracoContext.Current.HttpContext, SettingsHelper.Instance).GetCurrentCurrency(DefaultLanguage);
        }


        public static string GetCurrencyForCode(string code)
        {
            var currencyMap =
                       SettingsHelper.Instance.Currency.DefaultCurrencies
                           .FirstOrDefault(
                               a =>
                                   a.Language.InvariantEquals(code));

            return currencyMap.Currency;
        }
        
        /// <summary>
        /// returns the url to the langugage cookie api call for setting the cookie
        /// </summary>
        public static string LanguageCookieApiUrl => "/umbraco/api/language/setlanguage";

        /// <summary>
        /// returns the url to the langugage cookie api call for setting the cookie
        /// </summary>
        public static string CurrencyCookieApiUrl => "/umbraco/api/language/setcurrency";

        public CurrencyHelper CurrencyHelper => currencyHelper;

        public static List<SelectListItem> Countries = new List<SelectListItem>()
         {
                new SelectListItem()  {Text="United States",Value="US"},
                new SelectListItem()  {Text="United Kingdom",Value="GB"},
                new SelectListItem()  {Text="Germany",Value="DE"},
                new SelectListItem()  {Text="Singapore",Value="SG"},
                new SelectListItem()  {Text="Andorra",Value="AD"},
                new SelectListItem()  {Text="United Arab Emirates",Value="AE"},
                new SelectListItem()  {Text="Afghanistan",Value="AF"},
                new SelectListItem()  {Text="Antigua and Barbuda",Value="AG"},
                new SelectListItem()  {Text="Anguilla",Value="AI"},
                new SelectListItem()  {Text="Albania",Value="AL"},
                new SelectListItem()  {Text="Armenia",Value="AM"},
                new SelectListItem()  {Text="Angola",Value="AO"},
                new SelectListItem()  {Text="Antarctica",Value="AQ"},
                new SelectListItem()  {Text="Argentina",Value="AR"},
                new SelectListItem()  {Text="American Samoa",Value="AS"},
                new SelectListItem()  {Text="Austria",Value="AT"},
                new SelectListItem()  {Text="Australia",Value="AU"},
                new SelectListItem()  {Text="Aruba",Value="AW"},
                new SelectListItem()  {Text="Åland",Value="AX"},
                new SelectListItem()  {Text="Azerbaijan",Value="AZ"},
                new SelectListItem()  {Text="Bosnia and Herzegovina",Value="BA"},
                new SelectListItem()  {Text="Barbados",Value="BB"},
                new SelectListItem()  {Text="Bangladesh",Value="BD"},
                new SelectListItem()  {Text="Belgium",Value="BE"},
                new SelectListItem()  {Text="Burkina Faso",Value="BF"},
                new SelectListItem()  {Text="Bulgaria",Value="BG"},
                new SelectListItem()  {Text="Bahrain",Value="BH"},
                new SelectListItem()  {Text="Burundi",Value="BI"},
                new SelectListItem()  {Text="Benin",Value="BJ"},
                new SelectListItem()  {Text="Saint Barthélemy",Value="BL"},
                new SelectListItem()  {Text="Bermuda",Value="BM"},
                new SelectListItem()  {Text="Brunei",Value="BN"},
                new SelectListItem()  {Text="Bolivia",Value="BO"},
                new SelectListItem()  {Text="Bonaire",Value="BQ"},
                new SelectListItem()  {Text="Brazil",Value="BR"},
                new SelectListItem()  {Text="Bahamas",Value="BS"},
                new SelectListItem()  {Text="Bhutan",Value="BT"},
                new SelectListItem()  {Text="Bouvet Island",Value="BV"},
                new SelectListItem()  {Text="Botswana",Value="BW"},
                new SelectListItem()  {Text="Belarus",Value="BY"},
                new SelectListItem()  {Text="Belize",Value="BZ"},
                new SelectListItem()  {Text="Canada",Value="CA"},
                new SelectListItem()  {Text="Cocos [Keeling] Islands",Value="CC"},
                new SelectListItem()  {Text="Democratic Republic of the Congo",Value="CD"},
                new SelectListItem()  {Text="Central African Republic",Value="CF"},
                new SelectListItem()  {Text="Republic of the Congo",Value="CG"},
                new SelectListItem()  {Text="Switzerland",Value="CH"},
                new SelectListItem()  {Text="Ivory Coast",Value="CI"},
                new SelectListItem()  {Text="Cook Islands",Value="CK"},
                new SelectListItem()  {Text="Chile",Value="CL"},
                new SelectListItem()  {Text="Cameroon",Value="CM"},
                new SelectListItem()  {Text="China",Value="CN"},
                new SelectListItem()  {Text="Colombia",Value="CO"},
                new SelectListItem()  {Text="Costa Rica",Value="CR"},
                new SelectListItem()  {Text="Cuba",Value="CU"},
                new SelectListItem()  {Text="Cape Verde",Value="CV"},
                new SelectListItem()  {Text="Curacao",Value="CW"},
                new SelectListItem()  {Text="Christmas Island",Value="CX"},
                new SelectListItem()  {Text="Cyprus",Value="CY"},
                new SelectListItem()  {Text="Czechia",Value="CZ"},

                new SelectListItem()  {Text="Djibouti",Value="DJ"},
                new SelectListItem()  {Text="Denmark",Value="DK"},
                new SelectListItem()  {Text="Dominica",Value="DM"},
                new SelectListItem()  {Text="Dominican Republic",Value="DO"},
                new SelectListItem()  {Text="Algeria",Value="DZ"},
                new SelectListItem()  {Text="Ecuador",Value="EC"},
                new SelectListItem()  {Text="Estonia",Value="EE"},
                new SelectListItem()  {Text="Egypt",Value="EG"},
                new SelectListItem()  {Text="Western Sahara",Value="EH"},
                new SelectListItem()  {Text="Eritrea",Value="ER"},
                new SelectListItem()  {Text="Spain",Value="ES"},
                new SelectListItem()  {Text="Ethiopia",Value="ET"},
                new SelectListItem()  {Text="Finland",Value="FI"},
                new SelectListItem()  {Text="Fiji",Value="FJ"},
                new SelectListItem()  {Text="Falkland Islands",Value="FK"},
                new SelectListItem()  {Text="Micronesia",Value="FM"},
                new SelectListItem()  {Text="Faroe Islands",Value="FO"},
                new SelectListItem()  {Text="France",Value="FR"},
                new SelectListItem()  {Text="Gabon",Value="GA"},
                new SelectListItem()  {Text="Grenada",Value="GD"},
                new SelectListItem()  {Text="Georgia",Value="GE"},
                new SelectListItem()  {Text="French Guiana",Value="GF"},
                new SelectListItem()  {Text="Guernsey",Value="GG"},
                new SelectListItem()  {Text="Ghana",Value="GH"},
                new SelectListItem()  {Text="Gibraltar",Value="GI"},
                new SelectListItem()  {Text="Greenland",Value="GL"},
                new SelectListItem()  {Text="Gambia",Value="GM"},
                new SelectListItem()  {Text="Guinea",Value="GN"},
                new SelectListItem()  {Text="Guadeloupe",Value="GP"},
                new SelectListItem()  {Text="Equatorial Guinea",Value="GQ"},
                new SelectListItem()  {Text="Greece",Value="GR"},
                new SelectListItem()  {Text="South Georgia and the South Sandwich Islands",Value="GS"},
                new SelectListItem()  {Text="Guatemala",Value="GT"},
                new SelectListItem()  {Text="Guam",Value="GU"},
                new SelectListItem()  {Text="Guinea-Bissau",Value="GW"},
                new SelectListItem()  {Text="Guyana",Value="GY"},
                new SelectListItem()  {Text="Hong Kong",Value="HK"},
                new SelectListItem()  {Text="Heard Island and McDonald Islands",Value="HM"},
                new SelectListItem()  {Text="Honduras",Value="HN"},
                new SelectListItem()  {Text="Croatia",Value="HR"},
                new SelectListItem()  {Text="Haiti",Value="HT"},
                new SelectListItem()  {Text="Hungary",Value="HU"},
                new SelectListItem()  {Text="Indonesia",Value="ID"},
                new SelectListItem()  {Text="Ireland",Value="IE"},
                new SelectListItem()  {Text="Israel",Value="IL"},
                new SelectListItem()  {Text="Isle of Man",Value="IM"},
                new SelectListItem()  {Text="India",Value="IN"},
                new SelectListItem()  {Text="British Indian Ocean Territory",Value="IO"},
                new SelectListItem()  {Text="Iraq",Value="IQ"},
                new SelectListItem()  {Text="Iran",Value="IR"},
                new SelectListItem()  {Text="Iceland",Value="IS"},
                new SelectListItem()  {Text="Italy",Value="IT"},
                new SelectListItem()  {Text="Jersey",Value="JE"},
                new SelectListItem()  {Text="Jamaica",Value="JM"},
                new SelectListItem()  {Text="Jordan",Value="JO"},
                new SelectListItem()  {Text="Japan",Value="JP"},
                new SelectListItem()  {Text="Kenya",Value="KE"},
                new SelectListItem()  {Text="Kyrgyzstan",Value="KG"},
                new SelectListItem()  {Text="Cambodia",Value="KH"},
                new SelectListItem()  {Text="Kiribati",Value="KI"},
                new SelectListItem()  {Text="Comoros",Value="KM"},
                new SelectListItem()  {Text="Saint Kitts and Nevis",Value="KN"},
                new SelectListItem()  {Text="North Korea",Value="KP"},
                new SelectListItem()  {Text="South Korea",Value="KR"},
                new SelectListItem()  {Text="Kuwait",Value="KW"},
                new SelectListItem()  {Text="Cayman Islands",Value="KY"},
                new SelectListItem()  {Text="Kazakhstan",Value="KZ"},
                new SelectListItem()  {Text="Laos",Value="LA"},
                new SelectListItem()  {Text="Lebanon",Value="LB"},
                new SelectListItem()  {Text="Saint Lucia",Value="LC"},
                new SelectListItem()  {Text="Liechtenstein",Value="LI"},
                new SelectListItem()  {Text="Sri Lanka",Value="LK"},
                new SelectListItem()  {Text="Liberia",Value="LR"},
                new SelectListItem()  {Text="Lesotho",Value="LS"},
                new SelectListItem()  {Text="Lithuania",Value="LT"},
                new SelectListItem()  {Text="Luxembourg",Value="LU"},
                new SelectListItem()  {Text="Latvia",Value="LV"},
                new SelectListItem()  {Text="Libya",Value="LY"},
                new SelectListItem()  {Text="Morocco",Value="MA"},
                new SelectListItem()  {Text="Monaco",Value="MC"},
                new SelectListItem()  {Text="Moldova",Value="MD"},
                new SelectListItem()  {Text="Montenegro",Value="ME"},
                new SelectListItem()  {Text="Saint Martin",Value="MF"},
                new SelectListItem()  {Text="Madagascar",Value="MG"},
                new SelectListItem()  {Text="Marshall Islands",Value="MH"},
                new SelectListItem()  {Text="Macedonia",Value="MK"},
                new SelectListItem()  {Text="Mali",Value="ML"},
                new SelectListItem()  {Text="Myanmar [Burma]",Value="MM"},
                new SelectListItem()  {Text="Mongolia",Value="MN"},
                new SelectListItem()  {Text="Macao",Value="MO"},
                new SelectListItem()  {Text="Northern Mariana Islands",Value="MP"},
                new SelectListItem()  {Text="Martinique",Value="MQ"},
                new SelectListItem()  {Text="Mauritania",Value="MR"},
                new SelectListItem()  {Text="Montserrat",Value="MS"},
                new SelectListItem()  {Text="Malta",Value="MT"},
                new SelectListItem()  {Text="Mauritius",Value="MU"},
                new SelectListItem()  {Text="Maldives",Value="MV"},
                new SelectListItem()  {Text="Malawi",Value="MW"},
                new SelectListItem()  {Text="Mexico",Value="MX"},
                new SelectListItem()  {Text="Malaysia",Value="MY"},
                new SelectListItem()  {Text="Mozambique",Value="MZ"},
                new SelectListItem()  {Text="Namibia",Value="NA"},
                new SelectListItem()  {Text="New Caledonia",Value="NC"},
                new SelectListItem()  {Text="Niger",Value="NE"},
                new SelectListItem()  {Text="Norfolk Island",Value="NF"},
                new SelectListItem()  {Text="Nigeria",Value="NG"},
                new SelectListItem()  {Text="Nicaragua",Value="NI"},
                new SelectListItem()  {Text="Netherlands",Value="NL"},
                new SelectListItem()  {Text="Norway",Value="NO"},
                new SelectListItem()  {Text="Nepal",Value="NP"},
                new SelectListItem()  {Text="Nauru",Value="NR"},
                new SelectListItem()  {Text="Niue",Value="NU"},
                new SelectListItem()  {Text="New Zealand",Value="NZ"},
                new SelectListItem()  {Text="Oman",Value="OM"},
                new SelectListItem()  {Text="Panama",Value="PA"},
                new SelectListItem()  {Text="Peru",Value="PE"},
                new SelectListItem()  {Text="French Polynesia",Value="PF"},
                new SelectListItem()  {Text="Papua New Guinea",Value="PG"},
                new SelectListItem()  {Text="Philippines",Value="PH"},
                new SelectListItem()  {Text="Pakistan",Value="PK"},
                new SelectListItem()  {Text="Poland",Value="PL"},
                new SelectListItem()  {Text="Saint Pierre and Miquelon",Value="PM"},
                new SelectListItem()  {Text="Pitcairn Islands",Value="PN"},
                new SelectListItem()  {Text="Puerto Rico",Value="PR"},
                new SelectListItem()  {Text="Palestine",Value="PS"},
                new SelectListItem()  {Text="Portugal",Value="PT"},
                new SelectListItem()  {Text="Palau",Value="PW"},
                new SelectListItem()  {Text="Paraguay",Value="PY"},
                new SelectListItem()  {Text="Qatar",Value="QA"},
                new SelectListItem()  {Text="Réunion",Value="RE"},
                new SelectListItem()  {Text="Romania",Value="RO"},
                new SelectListItem()  {Text="Serbia",Value="RS"},
                new SelectListItem()  {Text="Russia",Value="RU"},
                new SelectListItem()  {Text="Rwanda",Value="RW"},
                new SelectListItem()  {Text="Saudi Arabia",Value="SA"},
                new SelectListItem()  {Text="Solomon Islands",Value="SB"},
                new SelectListItem()  {Text="Seychelles",Value="SC"},
                new SelectListItem()  {Text="Sudan",Value="SD"},
                new SelectListItem()  {Text="Sweden",Value="SE"},

                new SelectListItem()  {Text="Saint Helena",Value="SH"},
                new SelectListItem()  {Text="Slovenia",Value="SI"},
                new SelectListItem()  {Text="Svalbard and Jan Mayen",Value="SJ"},
                new SelectListItem()  {Text="Slovakia",Value="SK"},
                new SelectListItem()  {Text="Sierra Leone",Value="SL"},
                new SelectListItem()  {Text="San Marino",Value="SM"},
                new SelectListItem()  {Text="Senegal",Value="SN"},
                new SelectListItem()  {Text="Somalia",Value="SO"},
                new SelectListItem()  {Text="Suriname",Value="SR"},
                new SelectListItem()  {Text="South Sudan",Value="SS"},
                new SelectListItem()  {Text="São Tomé and Príncipe",Value="ST"},
                new SelectListItem()  {Text="El Salvador",Value="SV"},
                new SelectListItem()  {Text="Sint Maarten",Value="SX"},
                new SelectListItem()  {Text="Syria",Value="SY"},
                new SelectListItem()  {Text="Swaziland",Value="SZ"},
                new SelectListItem()  {Text="Turks and Caicos Islands",Value="TC"},
                new SelectListItem()  {Text="Chad",Value="TD"},
                new SelectListItem()  {Text="French Southern Territories",Value="TF"},
                new SelectListItem()  {Text="Togo",Value="TG"},
                new SelectListItem()  {Text="Thailand",Value="TH"},
                new SelectListItem()  {Text="Tajikistan",Value="TJ"},
                new SelectListItem()  {Text="Tokelau",Value="TK"},
                new SelectListItem()  {Text="East Timor",Value="TL"},
                new SelectListItem()  {Text="Turkmenistan",Value="TM"},
                new SelectListItem()  {Text="Tunisia",Value="TN"},
                new SelectListItem()  {Text="Tonga",Value="TO"},
                new SelectListItem()  {Text="Turkey",Value="TR"},
                new SelectListItem()  {Text="Trinidad and Tobago",Value="TT"},
                new SelectListItem()  {Text="Tuvalu",Value="TV"},
                new SelectListItem()  {Text="Taiwan",Value="TW"},
                new SelectListItem()  {Text="Tanzania",Value="TZ"},
                new SelectListItem()  {Text="Ukraine",Value="UA"},
                new SelectListItem()  {Text="Uganda",Value="UG"},
                new SelectListItem()  {Text="U.S. Minor Outlying Islands",Value="UM"},
                new SelectListItem()  {Text="Uruguay",Value="UY"},
                new SelectListItem()  {Text="Uzbekistan",Value="UZ"},
                new SelectListItem()  {Text="Vatican City",Value="VA"},
                new SelectListItem()  {Text="Saint Vincent and the Grenadines",Value="VC"},
                new SelectListItem()  {Text="Venezuela",Value="VE"},
                new SelectListItem()  {Text="British Virgin Islands",Value="VG"},
                new SelectListItem()  {Text="U.S. Virgin Islands",Value="VI"},
                new SelectListItem()  {Text="Vietnam",Value="VN"},
                new SelectListItem()  {Text="Vanuatu",Value="VU"},
                new SelectListItem()  {Text="Wallis and Futuna",Value="WF"},
                new SelectListItem()  {Text="Samoa",Value="WS"},
                new SelectListItem()  {Text="Kosovo",Value="XK"},
                new SelectListItem()  {Text="Yemen",Value="YE"},
                new SelectListItem()  {Text="Mayotte",Value="YT"},
                new SelectListItem()  {Text="South Africa",Value="ZA"},
                new SelectListItem()  {Text="Zambia",Value="ZM"},
                new SelectListItem()  {Text="Zimbabwe",Value="ZW"},
        };

        private readonly CurrencyHelper currencyHelper;

        public LanguageHelper(CurrencyHelper currencyHelper)
        {
            this.currencyHelper = currencyHelper;
        }

        /// <summary>
        /// Provide relative urls for all allowed languages (includes default).
        /// </summary>
        /// <param name="relativeDefaultUrl">The relative URL for the default language.
        /// Should start with a "/" </param>
        public static string[] GetAllAllowedLanguagesUrl(string relativeDefaultUrl)
        {
            var allAllowedLanguagesUrl = new List<string>() { relativeDefaultUrl };

            var nonDefaultLanguagesUrl = GetAllowedLanguageCodes()
                .Select(l => $"/{l}{relativeDefaultUrl}");
            allAllowedLanguagesUrl.AddRange(nonDefaultLanguagesUrl);

            return allAllowedLanguagesUrl.ToArray();
        }

        /// <summary>
        /// Provide relative urls for all allowed languages (includes default).
        /// </summary>
        /// <param name="relativeDefaultUrl">The relative URL for the default language.
        /// Should start with a "/" </param>
        public static string GetMultilingualPlaceUrl(Models.Page relativeDefaultUrl)
        {
            string returnUrl;

            if (relativeDefaultUrl.DocumentTypeAlias == "pagePlace")
            {
                var url = relativeDefaultUrl.Url;

                var codes = GetAllowedLanguageCodes();
                codes = codes.Select(s => s.ToLowerInvariant()).ToArray();


                if (codes.Any(url.Contains))
                {
                    var urlSegments = url.Split('/');

                    var linkToUse = "/" + urlSegments[1];
                    linkToUse += "/all";

                    foreach (var item in urlSegments.Skip(2))
                    {
                        linkToUse += "/" + item;
                    }

                    returnUrl = linkToUse;
                }
                else
                {
                    returnUrl = "/all" + url;

                }

            }
            else
            {
                returnUrl = relativeDefaultUrl.Url;
            }

            return returnUrl;
        }
    }
}
