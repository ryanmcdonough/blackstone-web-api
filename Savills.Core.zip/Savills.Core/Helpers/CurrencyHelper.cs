﻿using System;
using System.Configuration;
using System.Linq;
using System.Web;
using Umbraco.Core;
using Umbraco.Core.Cache;
using Umbraco.Web;
using Umbraco.Web.Security;

namespace Savills.Core.Helpers
{
    public class CurrencyHelper
    {

        protected internal CurrencyHelper(UmbracoContext umbracoContext, HttpContextBase httpContext, SettingsHelper settingsHelper)
        {
            this.umbracoContext = umbracoContext;
            this.httpContext = httpContext;
            this.settingsHelper = settingsHelper;
        }

        public string GetCurrentCurrency(string defaultLanguage = "en-US")
        {
            this.defaultLanguage = defaultLanguage;
            if (HasTheUserSetACurrencyUsingTheSwitcherInstance(out var value)) return value;

            if (IsTheUserLoggedInAndHasSetACurrencyInstance(out var currency)) return currency;

            if (IsThereADefaultCurrencySetForTheCurrentSiteInstance(out var currentCurrency)) return currentCurrency;

            return DefaultCurrencyInstance();
        }

        protected virtual bool HasTheUserSetACurrencyUsingTheSwitcherInstance(out string value)
        {
            return HasTheUserSetACurrencyUsingTheSwitcher(out value);
        }

        protected virtual bool IsTheUserLoggedInAndHasSetACurrencyInstance(out string currentCurrency1)
        {
            return IsTheUserLoggedInAndHasSetACurrency(out currentCurrency1);
        }

        protected virtual bool IsThereADefaultCurrencySetForTheCurrentSiteInstance(out string currentCurrency)
        {
            //is there a default currency set for the current site language?
            if (umbracoContext.PublishedContentRequest != null)
            {
                if (!umbracoContext.PublishedContentRequest.Culture.Name.InvariantEquals(defaultLanguage) && settingsHelper.DefaultCurrencies != null)

                {
                    var currencyMap =
                        settingsHelper.DefaultCurrencies
                            .FirstOrDefault(
                                a =>
                                    a.Language.InvariantEquals(
                                        umbracoContext.PublishedContentRequest.Culture.Name));

                    if (currencyMap != null)
                    {
                        currentCurrency = currencyMap.Currency;
                        return true;
                    }
                }
            }
            currentCurrency = String.Empty;
            return false;
        }

        private const string DefaultCurrencyConfigKey = "Savills.DefaultCurrency";

        /// <summary>
        ///     gets the default language that's set for the website
        /// </summary>
        public static string DefaultCurrency => ConfigurationManager.AppSettings[DefaultCurrencyConfigKey];

        protected virtual string DefaultCurrencyInstance()
        {
            return DefaultCurrency;
        }

        public const string AllowedCurrencyConfigKey = "Savills.AllowedCurrency";
        public const string SupportedCurrencyCodesKey = "supportedCurrencyCodes";
        public const string CurrencyCookieKey = "siteCurrency";
        private readonly UmbracoContext umbracoContext;
        private readonly HttpContextBase httpContext;
        private readonly SettingsHelper settingsHelper;
        private string defaultLanguage;

        /// <summary>
        /// Gets all of the supported language codes (basically the same as allowed, plus default)
        /// </summary>
        /// <returns></returns>
        public static string[] GetSupportedCurrencyCodes()
        {
            var umbracoContext = ContextHelper.EnsureUmbracoContext();

            return new CurrencyHelper(umbracoContext, umbracoContext.HttpContext, SettingsHelper.Instance).GetSupportedCurrencyCodesInstance(ConfigurationManager.AppSettings[AllowedCurrencyConfigKey]);
        }

        protected virtual string[] GetSupportedCurrencyCodesInstance(string allowedCurrencyConfigKey)
        {
            return
                umbracoContext.Application.ApplicationCache.RequestCache.GetCacheItem<string[]>(
                    SupportedCurrencyCodesKey,
                    () =>
                        (CurrencyHelper.DefaultCurrency
                         + ","
                         + allowedCurrencyConfigKey)
                        .Split(',')
                        .Select(l => l.Trim())
                        .ToArray());
        }

        public static bool HasTheUserSetACurrencyUsingTheSwitcher(out string value)
        {
            //has the user set a currency using the switcher?
            if (HttpContext.Current.Request.Cookies[CurrencyHelper.CurrencyCookieKey] != null && CurrencyHelper
                    .GetSupportedCurrencyCodes()
                    .InvariantContains(HttpContext.Current.Request.Cookies[CurrencyHelper.CurrencyCookieKey].Value))
            {
                value = HttpContext.Current.Request.Cookies[CurrencyHelper.CurrencyCookieKey].Value;
                return true;
            }
            value = String.Empty;
            return false;
        }

        public static bool IsTheUserLoggedInAndHasSetACurrency(out string currentCurrency1)
        {
            // is the user logged in and has set a currency?
            if (HttpContext.Current.User.Identity.IsAuthenticated)
            {
                var membershipHelper = new MembershipHelper(UmbracoContext.Current);

                var member = membershipHelper.GetCurrentMember();

                var currency = member?.GetPropertyValue<string>("currency", "");

                if (!String.IsNullOrEmpty(currency) &&
                    CurrencyHelper.GetSupportedCurrencyCodes().InvariantContains(currency))
                {
                    currentCurrency1 = currency;
                    return true;
                }
            }
            currentCurrency1 = String.Empty;
            return false;
        }

        /// <summary>
        /// sets the cookie to say which currency has been selected
        /// </summary>
        public static void SetCurrencyCookie(string currency)
        {
            if (CurrencyHelper.GetSupportedCurrencyCodes().InvariantContains(currency))
            {
                var cookie = new HttpCookie(CurrencyHelper.CurrencyCookieKey, currency);

                HttpContext.Current.Response.Cookies.Add(cookie);
            }
        }
    }
}