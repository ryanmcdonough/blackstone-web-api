﻿using System;
using System.Configuration;

namespace Savills.Core.Helpers
{
    public static class TaskHelper
    {
        private static string _taskUserConfigKey = "Savills.TaskUser";
        private static string _providerLogoFolderKey = "Savills.ProviderLogos.Folder";
        private static string _providersFolderKey = "Savills.Nodes.Providers";
        private static string _membersFolderKey = "Savills.MemberPhotos.Folder";

        /// <summary>
        /// The id of the user that should be used for site tasks
        /// </summary>
        public static int TaskUser => Convert.ToInt32(ConfigurationManager.AppSettings[_taskUserConfigKey]);

        /// <summary>
        /// The id of the folder for storing provider logos in
        /// </summary>
        public static int ProviderLogosFolderId => Convert.ToInt32(ConfigurationManager.AppSettings[_providerLogoFolderKey]);


        /// <summary>
        /// The id of the folder for storing member photos in
        /// </summary>
        public static int MemberPhotosFolderId => Convert.ToInt32(ConfigurationManager.AppSettings[_membersFolderKey]);

        /// <summary>
        /// The id of the folder that the provider details live underneath
        /// </summary>
        public static int ProvidersFolder => Convert.ToInt32(ConfigurationManager.AppSettings[_providersFolderKey]);
    }
}
