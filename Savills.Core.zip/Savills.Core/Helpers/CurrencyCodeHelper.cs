﻿using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Savills.Core.Helpers
{
    public static class CurrencyCodeHelper
    {
        private static readonly Dictionary<string, string> SymbolsByCode;

        public static string GetSymbol(string code) { return SymbolsByCode[code]; }

        static CurrencyCodeHelper()
        {
            SymbolsByCode = new Dictionary<string, string>();

            var regions = CultureInfo.GetCultures(CultureTypes.SpecificCultures)
                          .Select(x => new RegionInfo(x.LCID));

            foreach (var region in regions)
                if (!SymbolsByCode.ContainsKey(region.ISOCurrencySymbol))
                    SymbolsByCode.Add(region.ISOCurrencySymbol, region.CurrencySymbol);
        }
    }
}
