using System;

namespace Savills.Core.Helpers
{
    public sealed class MathHelper
    {
        public static double Wrap(double value, double min, double max)
        {
            // I totally came up with it myself.
            value = (((value - min) % (max - min)) + (max - min)) % (max - min) + min;

            return value;
        }

        public static double Clamp(double value, double min, double max)
        {
            value = Math.Max(min, value);
            value = Math.Min(max, value);

            return value;
        }
    }
}