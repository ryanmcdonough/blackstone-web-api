﻿using System;
using System.Collections.Generic;
using System.Web;
using Umbraco.Core.Models;
using Umbraco.Web;
using Savills.Core.Models;

namespace Savills.Core.Helpers
{
    public class SettingsHelper
    {
        private readonly Lazy<ConfigurationNavigation> _navigation = new Lazy<ConfigurationNavigation>(GetSettingsContent<ConfigurationNavigation>);

        private readonly Lazy<ConfigurationContact> _contact = new Lazy<ConfigurationContact>(GetSettingsContent<ConfigurationContact>);

        private readonly Lazy<ConfigurationTracking> _tracking = new Lazy<ConfigurationTracking>(GetSettingsContent<ConfigurationTracking>);

        private readonly Lazy<ConfigurationSocial> _social = new Lazy<ConfigurationSocial>(GetSettingsContent<ConfigurationSocial>);

        private readonly Lazy<ConfigurationCurrency> _currency = new Lazy<ConfigurationCurrency>(GetSettingsContent<ConfigurationCurrency>);

        private readonly Lazy<ConfigurationSearch> _search = new Lazy<ConfigurationSearch>(GetSettingsContent<ConfigurationSearch>);

        private readonly Lazy<ConfigurationLogging> _logging = new Lazy<ConfigurationLogging>(GetSettingsContent<ConfigurationLogging>);

        private const string Key = "Savills.Web.Helpers.SettingsHelper";


        private static T GetSettingsContent<T>() where T : class, IPublishedContent
        {
            var root = UmbracoContext.Current.ContentCache.GetById(1067) as ConfigurationRoot;

            return root?.Descendant<T>();
        }

        public static SettingsHelper Instance
        {
            get
            {
                if (HttpContext.Current.Items[Key] == null)
                {
                    var instance = new SettingsHelper();
                    HttpContext.Current.Items[Key] = instance;
                }

                return HttpContext.Current.Items[Key] as SettingsHelper;
            }
        }

        public static void ClearInstance()
        {
            HttpContext.Current.Items[Key] = null;
        }

        public ConfigurationNavigation Navigation => _navigation.Value;

        public ConfigurationContact Contact => _contact.Value;

        public ConfigurationTracking Tracking => _tracking.Value;

        public ConfigurationSocial Social => _social.Value;

        public ConfigurationCurrency Currency => _currency.Value;

        // TODO: resettable lazy cache.
        public ConfigurationSearch Search => _search.Value;

        public ConfigurationLogging Logging => _logging.Value;

        protected internal virtual IEnumerable<DataCurrencyMapping> DefaultCurrencies => Currency.DefaultCurrencies;
    }
}