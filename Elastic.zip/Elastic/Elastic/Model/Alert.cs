﻿using System;
using Nest;

namespace Savills.Core.Elastic.Elastic.Model
{
    public class Alert
    {
        public Guid Id { get; set; }
        public int MemberId { get; set; }
        [GeoShape]
        public PointGeoShape GeoLocation { get; set; }
        [Number]
        public int Distance { get; set; }
        [String]
        public string Description { get; set; }
        [String]
        public string CrmGuid { get; set; }
    }
}
