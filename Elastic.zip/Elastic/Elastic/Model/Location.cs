﻿using Nest;

namespace Savills.Core.Elastic.Elastic.Model
{
    public class Location
    {
        [String]
        public string AddressLine1 { get; set; }
        [String]
        public string AddressLine2 { get; set; }
        [String]
        public string AddressLine3 { get; set; }
        [String]
        public string AddressLineCity { get; set; }
        [String]
        public string AddressCounty { get; set; }
        [String]
        public string AddressCountry { get; set; }
        [String]
        public string AddressLinePostcode { get; set; }


    }
}
