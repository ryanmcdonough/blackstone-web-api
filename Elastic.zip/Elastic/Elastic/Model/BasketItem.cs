﻿using Nest;
using System;
using System.Collections.Generic;

namespace Savills.Core.Elastic.Elastic.Model
{
    public class BasketItem
    {
        public Guid Id { get; set; }

        [String(Analyzer = "keyword")]
        public string UserId { get; set; }

        [Number]
        public int PropertyId { get; set; }

        [Nested]
        public List<Space> SpacesInterestedIn { get; set; } = new List<Space>();

        public string DateInterestedIn { get; set; }

        public string TimeInterestedIn { get; set; }
    }
}
