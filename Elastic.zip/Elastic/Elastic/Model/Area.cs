﻿using GeoJSON.Net.Converters;
using GeoJSON.Net.Geometry;
using Nest;
using Newtonsoft.Json;

namespace Savills.Core.Elastic.Elastic.Model
{
    public class Area
    {
        [GeoShape]
        [JsonConverter(typeof(GeometryConverter))]
        public IGeometryObject Coordinates { get; set; }

        [String]
        public string Name { get; set; }
    }
}