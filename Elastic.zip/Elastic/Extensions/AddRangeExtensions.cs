﻿using System.Collections.Generic;

namespace Savills.Core.Elastic.Extensions
{
    public static class AddRangeExtensions
    {
        public static void AddRange<T>(this ICollection<T> collection, IEnumerable<T> enumerable)
        {
            foreach (var cur in enumerable)
            {
                collection.Add(cur);
            }
        }
    }
}
