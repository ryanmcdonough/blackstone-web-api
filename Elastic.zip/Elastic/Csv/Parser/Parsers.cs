﻿using Savills.Core.Elastic.Csv.Mapper;
using Savills.Core.Elastic.Csv.Model;
using TinyCsvParser;

namespace Savills.Core.Elastic.Csv.Parser
{
    public static class Parsers
    {
        public static CsvParser<PropertyImport> PropertyParser
        {
            get
            {
                CsvParserOptions csvParserOptions = new CsvParserOptions(true, new[] { ',' });

                return new CsvParser<PropertyImport>(csvParserOptions, new PropertyMapper());
            }
        }

        public static CsvParser<TransportImport> TransportParser
        {
            get
            {
                CsvParserOptions csvParserOptions = new CsvParserOptions(true, new[] { ',' });

                return new CsvParser<TransportImport>(csvParserOptions, new TransportMapper());
            }
        }

    }
}
