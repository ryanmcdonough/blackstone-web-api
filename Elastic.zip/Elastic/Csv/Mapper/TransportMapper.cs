﻿using Savills.Core.Elastic.Csv.Model;
using TinyCsvParser.Mapping;

namespace Savills.Core.Elastic.Csv.Mapper
{
    public class TransportMapper : CsvMapping<TransportImport>
    {
        public TransportMapper()
        {
            MapProperty(4, x => x.Name);
            MapProperty(30, x => x.Latitude);
            MapProperty(29, x => x.Longitude);
            MapProperty(31, x => x.Type);
        }
    }
}
