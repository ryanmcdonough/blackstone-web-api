﻿using Nest;
using Savills.Core.Elastic.Csv.Model;
using Savills.Core.Elastic.Elastic.Model;

namespace Savills.Core.Elastic.Converter
{
    public class PropertyConverter
    {

        public static Transport Convert(TransportImport property)
        {
            return new Transport
            {
                GeoLocation = new GeoLocation(property.Latitude, property.Longitude),
                Name = property.Name,
                Type = property.Type,
            };
        }
    }
}
