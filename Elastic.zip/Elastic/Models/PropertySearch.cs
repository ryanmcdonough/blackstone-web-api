﻿namespace Savills.Core.Elastic.Models
{
    public class PropertySearch
    {
        public double Latitude { get; set; }
        public double Longitude  { get; set; }
        public int Distance { get; set; }
        public string Area { get; set; }
    }
}
