﻿using System.Collections.Generic;
using Savills.Core.Elastic.Elastic.Model;

namespace Savills.Core.Elastic.Models
{
    public class TransportResult
    {

        public List<Transport> BusStops { get; set; } = new List<Transport>();
        public List<Transport> RailwayStations { get; set; } = new List<Transport>();
        public List<Transport> UndergroundStations { get; set; } = new List<Transport>();
        public List<Transport> Airports { get; set; } = new List<Transport>();
    }
}
